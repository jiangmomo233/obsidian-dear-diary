# Third-party notices · 第三方声明

The CC BY-NC 4.0 license in `LICENSE` covers the original work in this repository. The parts below were created by others and **remain under their own licenses**.

本仓库的 CC BY-NC 4.0 许可只适用于原创部分。以下第三方内容保留其原有许可。

## 1. Obsidian Media Library Template — MIT

The media library (`80 Library/媒体库/` — views, templates, navigation pages, docs and config — and `.obsidian/snippets/media-library.css`) is adapted from
[obsidian-media-library-template](https://github.com/JackyGaoym/obsidian-media-library-template).

媒体库部分基于该项目修改。

```
MIT License

Copyright (c) 2026 Obsidian Media Library Template contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 2. Chart.js v4.4.0 — MIT

`System & Attachments/Scripts/chart.umd.js` is [Chart.js](https://www.chartjs.org), (c) 2023 Chart.js Contributors, released under the MIT License (see the header of the file).

## 3. Not included · 未包含

Obsidian, the themes (Dayspring, Border), the community plugins listed in README, and the MCL snippets ([Modular CSS Layout](https://github.com/efemkay/obsidian-modular-css-layout) by Faiz Khuzaimah) belong to their own authors and are **not** bundled here. Install them from their official sources.

Obsidian、主题、插件和 MCL 片段均归原作者所有，本仓库不包含，请从官方渠道安装。
