---
cssclasses:
  - wide-page
---
```dataviewjs
// All journal entries (written from the Journal box on each daily page), newest first.
const FOLDER = "90 Journaling";
const pages = dv.pages(`"${FOLDER}"`).where(p => moment(p.file.name, "YYYY-MM-DD", true).isValid()).sort(p => p.file.name, "desc").array();
const root = dv.container.createDiv({ cls: "jx" });
root.createEl("style", { text: `
.jx{font-family:'Figtree',BlinkMacSystemFont,sans-serif;}
.jx-top{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:10px;}
.jx button{box-shadow:none !important;cursor:pointer;}
.jx-chip{height:26px !important;padding:0 11px !important;border-radius:13px !important;font-size:0.85em !important;background:#EBE4E2 !important;color:#4A5A62 !important;}
.jx-chip.on{background:#4384A3 !important;color:#fff !important;}
.jx-today{height:28px !important;padding:0 14px !important;border-radius:8px !important;background:#4384A3 !important;color:#fff !important;font-size:0.88em !important;}
.jx-search{flex:1;min-width:140px;height:28px !important;border-radius:8px !important;border:1px solid #4384A333 !important;padding:0 10px !important;background:#fffc !important;}
.jx-card{background:#F6F2EE;border-radius:12px;padding:12px 16px;margin-bottom:10px;}
.jx-date{color:#4384A3;font-weight:600;cursor:pointer;margin-bottom:6px;}
.jx-date span{color:#999;font-weight:400;font-size:0.85em;margin-left:6px;}
.jx-q{font-size:0.8em;color:#4384A3;font-weight:500;margin-top:6px;}
.jx-a{white-space:pre-wrap;font-size:0.93em;line-height:1.5;}
.jx-empty{color:#999;font-style:italic;}
` });
const top = root.createDiv({ cls: "jx-top" });
const todayBtn = top.createEl("button", { cls: "jx-today", text: "✍️ Write today" });
todayBtn.onclick = async () => {
    const path = `01 Daily/${moment().format("YYYY-MM-DD")}.md`;
    let f = app.vault.getAbstractFileByPath(path);
    if (!f) { const t = app.vault.getAbstractFileByPath("System & Attachments/Templates/Dear Diary.md"); f = await app.vault.create(path, t ? await app.vault.read(t) : ""); }
    app.workspace.getLeaf(false).openFile(f);
};
const months = [...new Set(pages.map(p => p.file.name.slice(0, 7)))];
let month = "all", q = "";
const chipBox = top.createDiv({ cls: "jx-top" });
const search = top.createEl("input", { cls: "jx-search", attr: { type: "text", placeholder: "search entries…" } });
search.addEventListener("keydown", e => e.stopPropagation());
const list = root.createDiv();
const parse = text => {
    const out = []; let cur = null;
    for (const line of text.replace(/^---\n[\s\S]*?\n---\n?/, "").split("\n")) {
        const m = line.match(/^###\s+(.+)/);
        if (m) { cur = { q: m[1], a: [] }; out.push(cur); } else if (cur) cur.a.push(line);
    }
    return out.map(x => ({ q: x.q, a: x.a.join("\n").trim() })).filter(x => x.a);
};
const texts = {};
for (const p of pages) texts[p.file.name] = parse(await dv.io.load(p.file.path));
const draw = () => {
    chipBox.empty();
    for (const m of ["all", ...months]) { const b = chipBox.createEl("button", { cls: "jx-chip" + (m === month ? " on" : ""), text: m === "all" ? "All" : moment(m).format("MMM YYYY") }); b.onclick = () => { month = m; draw(); }; }
    list.empty();
    let shown = 0;
    for (const p of pages) {
        if (month !== "all" && !p.file.name.startsWith(month)) continue;
        const items = texts[p.file.name];
        if (!items.length) continue;
        if (q && !items.some(x => (x.q + " " + x.a).toLowerCase().includes(q))) continue;
        shown++;
        const c = list.createDiv({ cls: "jx-card" });
        const d = c.createDiv({ cls: "jx-date", text: moment(p.file.name).format("dddd, MMMM D, YYYY") });
        d.createSpan({ text: "open daily page ↗" });
        d.onclick = () => app.workspace.openLinkText(`01 Daily/${p.file.name}.md`, "", false);
        for (const x of items) { c.createDiv({ cls: "jx-q", text: x.q }); c.createDiv({ cls: "jx-a", text: x.a }); }
    }
    if (!shown) list.createDiv({ cls: "jx-empty", text: pages.length ? "No entries match." : "No entries yet — write in the Journal box at the bottom of your daily page." });
};
search.addEventListener("input", () => { q = search.value.trim().toLowerCase(); draw(); });
draw();
```
