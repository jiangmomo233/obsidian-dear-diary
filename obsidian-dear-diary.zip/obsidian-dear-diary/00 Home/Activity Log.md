---
cssclasses:
  - daily-note
  - wide-page
---
```dataviewjs
await dv.view("System & Attachments/Scripts/activity-archive")
```
