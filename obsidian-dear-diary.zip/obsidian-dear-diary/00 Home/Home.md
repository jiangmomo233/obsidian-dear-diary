---
cssclasses:
  - wide-page
  - home-minimal
---
```dataviewjs
await dv.view("System & Attachments/Scripts/home-nav")
```
```dataviewjs
const allInsights = dv.pages("#insight-list")
  .flatMap(p => p.insights || [])
  .filter(i => i && i.text)
  .map(i => i.text);

if (allInsights.length === 0) {
  dv.paragraph("*No insights found*");
} else {
  const random = allInsights.sort(() => 0.5 - Math.random())[0];
  let q = String(random).trim(), ref = "";
  const m = q.match(/^(.*?)[\s—–-]*[(（]([^()（）]+)[)）]\s*$/) || q.match(/^(.*?)\s+[—–]+\s*(.+)$/);
  if (m) { q = m[1].trim(); ref = m[2].trim(); }
  q = q.replace(/^["“”]+|["“”]+$/g, "").trim();
  const F = `'Cormorant Garamond','EB Garamond',Garamond,'Hoefler Text','Songti SC',serif`;
  dv.paragraph(`<div style="margin:6px 10px;background:#FFF9FA;border:1px solid #F7E6E9;border-radius:14px;padding:18px 22px;text-align:center"><div style="font-family:Garamond,'EB Garamond',${F};font-size:3.6em;line-height:.6;height:.42em;color:#D9A3AD;opacity:.55">“</div><div style="font-family:${F};font-style:italic;font-size:1.45em;color:#D9A3AD;line-height:1.4">${q}</div>${ref ? `<div style="font-family:${F};font-variant:small-caps;font-size:0.85em;letter-spacing:3px;color:#D9A3AD;margin-top:4px">${ref}</div>` : ""}</div>`);
}
```
```dataviewjs
await dv.view("System & Attachments/Scripts/home-today")
```
```dataviewjs
dv.container.style.cssText = "display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px;margin:0 10px 32px";
await dv.view("System & Attachments/Scripts/home-money")
await dv.view("System & Attachments/Scripts/home-deadlines")
```
```dataviewjs
await dv.view("System & Attachments/Scripts/home-calendar")
```
```dataviewjs
await dv.view("System & Attachments/Scripts/home-habits")
await dv.view("System & Attachments/Scripts/home-reading")
```
