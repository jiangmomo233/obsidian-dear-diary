---
tags: [deadline-list]
---
# Deadlines
One deadline per line: `- YYYY-MM-DD HH:mm · what · #group`. The time and the [[link]] are optional.
The Home page shows the upcoming ones and hides past ones automatically. Groups: #travel #study #school #work #life.

## Work
- 2026-11-06 17:00 · Quarterly report draft · #work
- 2026-11-20 · Team offsite planning · #work

## Study
- 2026-11-15 · Online course final project · #study
- 2026-12-05 09:00 · Language exam · #study

## Life
- 2026-11-30 · Renew passport · #life
- 2026-12-20 · Book holiday flights · #travel
