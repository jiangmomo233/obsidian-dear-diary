---
tags: [important-dates]
---
# Important Dates
Birthdays, anniversaries and other days that come back every year. One per line:
`- MM-DD · what · #birthday` (or #anniversary, #holiday, #other).
Put a full date `YYYY-MM-DD` if you know the year — the calendar will show the age / how many years.
Deadlines from [[Deadlines]] show up next to these automatically.

## Birthdays
- 03-14 · Alex 生日 · #birthday
- 07-02 · Sam 生日 · #birthday
- 1990-11-08 · 示例：带年份的生日 · #birthday

## Anniversaries
- 2020-05-20 · 示例纪念日 · #anniversary

## Holidays
- 01-01 · New Year's Day · #holiday
- 12-25 · Christmas · #holiday

## Other
