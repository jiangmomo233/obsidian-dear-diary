---
kanban-plugin: board
---

## To-do

- [ ] 整理本周笔记 @{2026-10-23}
- [ ] Plan weekend trip #life
- [ ] 读完一本书 #study

## In Progress

- [ ] Quarterly report #work @{2026-11-06}

## Done

- [x] 示例：已完成的任务

%% kanban:settings
```
{"kanban-plugin":"board","list-collapse":[false,false,false]}
```
%%
