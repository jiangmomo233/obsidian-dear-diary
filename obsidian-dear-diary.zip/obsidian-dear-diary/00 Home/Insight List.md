---
tags: insight-list
insights:
  - text: 'Bloom where you are planted.'
  - text: 'Small steps are still steps.'
  - text: 'Trust the timing of your life.'
  - text: 'You''re not behind. You''re on your own path.'
  - text: 'Growth looks good on you.'
  - text: 'Becoming is better than being.'
  - text: 'One day or day one. You decide.'
  - text: 'Little by little, a little becomes a lot.'
  - text: 'Protect your peace.'
  - text: 'Everything is figureoutable.'
  - text: 'Good things take time.'
  - text: 'Be soft. Don''t let the world make you hard.'
  - text: 'Inhale courage, exhale fear.'
  - text: 'If it costs your peace, it''s too expensive.'
  - text: 'The best time to plant a tree was 20 years ago. The second best time is now. (Proverb)'
  - text: 'Well begun is half done. (Aristotle)'
  - text: '千里之行，始于足下。（老子）'
  - text: '知之者不如好之者，好之者不如乐之者。（孔子）'
---
#homepage

Edit the `insights` list above — Home shows one at random. Add a source in brackets at the end, e.g. `Text (Author)`.
