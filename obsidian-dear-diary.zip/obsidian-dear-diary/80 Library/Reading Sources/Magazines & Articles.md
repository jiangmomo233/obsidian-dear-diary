==**News:**==
[Reuters](https://www.reuters.com/)
[AP News](https://apnews.com/)
[BBC News](https://www.bbc.com/news)

==**Reading & Writing**==
[The Atlantic](https://www.theatlantic.com/)
[The New Yorker](https://www.newyorker.com/)

==**Learning:**==
[Wikipedia](https://www.wikipedia.org/)
