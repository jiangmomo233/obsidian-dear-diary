---
cssclasses:
  - wide-page
  - mny-page
---
```dataviewjs
await dv.view("System & Attachments/Scripts/money")
```
