---
tags:
  - dearDiary
mood:
energy:
mind: []
sleep_hours:
weight:
waist:
water: 0
workout:
workout_min:
workout_note:
breakfast:
lunch:
dinner:
snacks:
period:
supplements: []
medicine: []
media_log: []
articles: []
activities: []
cssclasses:
  - daily-note
  - wide-page
---
```dataviewjs
await dv.view("System & Attachments/Scripts/daily-app")
```

```dataviewjs
await dv.view("System & Attachments/Scripts/daily-habits")
```
> [!habits] Daily habits
> - [ ] Skim the news for 10 minutes #habit/news
> - [ ] Check the calendar each morning #habit/calendar
> - [ ] Check email at set times #habit/email
> - [ ] Study a language for 20 minutes #habit/language
> - [ ] Read a book for 20 to 30 minutes #habit/read
> - [ ] Write for 10 minutes #habit/write
> - [ ] Exercise 30 to 45 minutes, 4 to 5 days a week #habit/exercise
> - [ ] Get up and move every hour or two #habit/move
> - [ ] Take a walk outside #habit/walk
> - [ ] Eat regular meals and get enough sleep #habit/sleep

> [!habits] Weekly & monthly
> - [ ] Read one or two long-form articles #habit/longread
> - [ ] Consume something in an area you want to grow in #habit/grow
> - [ ] Review your notes #habit/notes
> - [ ] Reflect for 30 minutes #habit/reflect
> - [ ] Pick one new thing to try #habit/new

```dataviewjs
await dv.view("System & Attachments/Scripts/daily-media")
```

---
```dataviewjs
await dv.view("System & Attachments/Scripts/daily-journal")
```
