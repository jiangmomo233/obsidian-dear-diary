// Daily note dashboard: header + check-in, workout, food, health, quick-add tasks.
// keep the page from jumping to the top when Dataview re-renders this block after a save
{ const c = dv.container; const fix = () => { const sc = c.closest(".markdown-preview-view, .cm-scroller"); const top = sc ? sc.scrollTop : null; c.style.minHeight = ""; c.style.minHeight = c.offsetHeight + "px"; if (sc && top != null) sc.scrollTop = top; }; setTimeout(fix, 400); setTimeout(fix, 1500); }
// Everything here saves to this note's properties (or inserts task lines), so it works in Reading view.
const cur = dv.current();
const file = app.vault.getAbstractFileByPath(cur.file.path);
const dayM = moment(cur.file.name, "YYYY-MM-DD", true);
const isDaily = dayM.isValid();
const d = isDaily ? dayM : moment();
const FOLDER = "01 Daily";
const HEALTH = "40 Life/Health/Health.md";
const TEMPLATE = "System & Attachments/Templates/Dear Diary.md";

const setFM = async patch => {
    if (!isDaily) return;
    await app.fileManager.processFrontMatter(file, fm => {
        for (const [k, v] of Object.entries(patch)) fm[k] = (typeof v === "function") ? v(fm[k]) : v;
    });
};
const num = v => { const n = parseFloat(String(v ?? "").replace(/[^\d.\-]/g, "")); return isNaN(n) ? null : n; };
const arr = v => (Array.isArray(v) ? v : (v ? [v] : [])).filter(x => x !== null && x !== undefined && x !== "");
const stop = el => el.addEventListener("keydown", e => e.stopPropagation());
const openPath = p => app.workspace.openLinkText(p, cur.file.path, false);
const root = dv.container.createDiv({ cls: "da" });
// instant feedback: show the tap right away while the note saves and the page redraws
root.addEventListener("pointerdown", e => {
    const b = e.target.closest("button"); if (!b || !root.contains(b)) return;
    b.addClass("da-pending");
    if (b.hasClass("da-chip") || b.hasClass("da-dot")) b.toggleClass("on", !b.hasClass("on"));
    if (b.hasClass("da-cup")) { const cups = [...b.parentElement.querySelectorAll(".da-cup")]; const i = cups.indexOf(b); cups.forEach((x, j) => x.toggleClass("on", j <= i)); }
}, true);

// keep the cursor where it was when the page refreshes itself after a save
const FK = "_daFocus";
root.addEventListener("focusin", e => { const t = e.target; if (t.dataset && t.dataset.fid) window[FK] = { fid: t.dataset.fid, t: Date.now() }; });
root.addEventListener("focusout", e => { const t = e.target; setTimeout(() => { if (t.isConnected && window[FK] && window[FK].fid === t.dataset.fid) window[FK] = null; }, 0); });
const restoreFocus = () => {
    const f = window[FK];
    if (!f || Date.now() - f.t > 120000) return;
    const el = root.querySelector(`[data-fid="${f.fid}"]`);
    if (el) { el.focus(); try { const n = el.value.length; el.setSelectionRange(n, n); } catch (e) {} }
};

// ── Header ──
const nav = (m, label) => {
    const path = `${FOLDER}/${m.format("YYYY-MM-DD")}.md`;
    return app.vault.getAbstractFileByPath(path)
        ? `<a class="internal-link dn-nav" data-href="${path}">${label}</a>`
        : `<a class="dn-nav dn-new" data-new="${path}" title="Create this day's note">${label}</a>`;
};
const openOrCreate = async path => {
    let f = app.vault.getAbstractFileByPath(path);
    if (!f) {
        const t = app.vault.getAbstractFileByPath(TEMPLATE);
        f = await app.vault.create(path, t ? await app.vault.read(t) : "");
    }
    await app.workspace.getLeaf(false).openFile(f);
};
const head = root.createDiv();
head.innerHTML = `
<div class="dn-header">
  <div class="dn-left">
    <div class="dn-weekday">${d.format("dddd")}${d.isSame(moment(), "day") ? ' <span class="dn-today">today</span>' : ""}</div>
    <div class="dn-date">${d.format("MMMM D, YYYY")}</div>
    <div class="dn-meta">Week ${d.isoWeek()} · Day ${d.dayOfYear()} of ${d.isLeapYear() ? 366 : 365}</div>
  </div>
  <div class="dn-right">
    ${nav(d.clone().subtract(1, "day"), "← Yesterday")}
    <a class="internal-link dn-nav" data-href="00 Home/Home.md">Home</a>
    ${nav(d.clone().add(1, "day"), "Tomorrow →")}
  </div>
</div>`;
head.querySelectorAll("[data-new]").forEach(a => a.addEventListener("click", e => { e.preventDefault(); openOrCreate(a.dataset.new); }));

const grid = root.createDiv({ cls: "da-grid" });
const card = (cls, title, link) => {
    const c = grid.createDiv({ cls: "da-card " + cls });
    const t = c.createDiv({ cls: "da-title" });
    if (link) {
        const a = t.createEl("a", { cls: "da-titlelink", text: title + "  ↗" });
        a.title = "Open " + link;
        a.addEventListener("click", e => { e.preventDefault(); openPath(link); });
    } else t.setText(title);
    return c;
};
const row = (c, label) => { const r = c.createDiv({ cls: "da-row" }); r.createSpan({ cls: "da-label", text: label }); return r.createDiv({ cls: "da-val" }); };
const chips = (parent, options, value, onPick) => {
    for (const [v, label] of options) {
        const b = parent.createEl("button", { cls: "da-chip" + (String(value) === String(v) ? " on" : ""), text: label });
        b.addEventListener("click", () => onPick(String(value) === String(v) ? null : v));
    }
};
const textInput = (parent, key, placeholder, type = "text") => {
    const i = parent.createEl("input", { cls: "da-in", attr: { type, placeholder, "data-fid": "fm-" + key } });
    i.value = cur[key] ?? "";
    stop(i);
    i.addEventListener("change", () => setFM({ [key]: type === "number" ? num(i.value) : (i.value.trim() || null) }));
    i.addEventListener("keydown", e => { if (e.key === "Enter") i.blur(); });
    return i;
};

// ── Check-in ──
{
    const c = card("da-checkin", "Check-in");
    chips(row(c, "Mood"), [["great", "😄"], ["good", "🙂"], ["okay", "😐"], ["low", "😔"], ["rough", "😣"]], cur.mood, v => setFM({ mood: v }));
    const en = row(c, "Energy");
    const ev = num(cur.energy) || 0;
    for (let i = 1; i <= 5; i++) {
        const b = en.createEl("button", { cls: "da-dot" + (i <= ev ? " on" : "") });
        b.title = `${i} / 5`;
        b.addEventListener("click", () => setFM({ energy: ev === i ? null : i }));
    }
    // Mind: pick as many as fit today
    const MIND = [["peaceful", "😌 peaceful"], ["happy", "😊 happy"], ["motivated", "🔥 motivated"], ["anxious", "😰 anxious"], ["stressed", "😵‍💫 stressed"],
                  ["irritable", "😤 irritable"], ["sad", "😢 sad"], ["depressed", "🌧 depressed"], ["manic", "⚡ manic"], ["numb", "😶 numb"]];
    const mind = arr(cur.mind).map(String);
    const mv = row(c, "Mind");
    for (const [v, label] of MIND) {
        const on = mind.includes(v);
        const b = mv.createEl("button", { cls: "da-chip" + (on ? " on" : ""), text: label });
        b.addEventListener("click", () => setFM({ mind: old => { const o = arr(old).map(String); return on ? o.filter(x => x !== v) : [...o, v]; } }));
    }
    const sl = row(c, "Sleep");
    const si = textInput(sl, "sleep_hours", "hrs", "number"); si.step = "0.5"; si.addClass("da-short");
    sl.createSpan({ cls: "da-unit", text: "hours" });
    // Body: weight (kg) + waist (cm), with change since the last day you logged it
    const bd = row(c, "Body");
    const prevVal = key => {
        const ps = dv.pages(`"${FOLDER}"`).where(p => { const m = moment(p.file.name, "YYYY-MM-DD", true); return m.isValid() && m.isBefore(d, "day") && num(p[key]) !== null; })
            .sort(p => p.file.name, "desc").array();
        return ps.length ? { v: num(ps[0][key]), day: ps[0].file.name } : null;
    };
    for (const [key, ph, unit] of [["weight", "体重", "kg"], ["waist", "腰围", "cm"]]) {
        const g = bd.createDiv({ cls: "da-meas" });
        const i = textInput(g, key, ph, "number"); i.step = "0.1"; i.addClass("da-short");
        g.createSpan({ cls: "da-unit", text: unit });
        const pv = prevVal(key), now = num(cur[key]);
        if (pv && now !== null) {
            const df = Math.round((now - pv.v) * 10) / 10;
            g.createSpan({ cls: "da-delta" + (df < 0 ? " down" : df > 0 ? " up" : ""), text: `${df > 0 ? "+" : ""}${df}`, attr: { title: `vs ${pv.v}${unit} on ${moment(pv.day).format("MMM D")}` } });
        } else if (pv) g.createSpan({ cls: "da-unit", text: `last ${pv.v}` });
    }
    const wa = row(c, "Water");
    const wv = num(cur.water) || 0;
    for (let i = 1; i <= 8; i++) {
        const b = wa.createEl("button", { cls: "da-cup" + (i <= wv ? " on" : ""), text: "💧" });
        b.addEventListener("click", () => setFM({ water: wv === i ? i - 1 : i }));
    }
    wa.createSpan({ cls: "da-unit", text: `${wv}/8` });
}

// ── Workout ── (saved to workout: [types] and workout_log: {strength, incline, stretch, pilates, ball})
{
    const c = card("da-workout", "Workout");
    const W = (cur.workout_log && typeof cur.workout_log === "object") ? cur.workout_log : {};
    const on = arr(cur.workout).map(String);
    const clone = o => JSON.parse(JSON.stringify(o || {}));
    const setLog = (k, fn) => setFM({ workout_log: old => { const o = clone(old); o[k] = fn(clone(o[k])); return o; } });
    const nIn = (p, val, ph, fid, onSet, cls = "dw-n") => {
        const i = p.createEl("input", { cls: "da-in " + cls, attr: { type: "number", step: "any", placeholder: ph, "data-fid": fid } });
        i.value = val ?? ""; stop(i);
        i.addEventListener("change", () => onSet(num(i.value)));
        i.addEventListener("keydown", e => { if (e.key === "Enter") i.blur(); });
        return i;
    };
    const tIn = (p, val, ph, fid, onSet, cls = "") => {
        const i = p.createEl("input", { cls: "da-in " + cls, attr: { type: "text", placeholder: ph, "data-fid": fid } });
        i.value = val ?? ""; stop(i);
        i.addEventListener("change", () => onSet(i.value.trim() || null));
        i.addEventListener("keydown", e => { if (e.key === "Enter") i.blur(); });
        return i;
    };
    const adder = (p, ph, fid, onAdd) => {
        const i = p.createEl("input", { cls: "da-in dw-add", attr: { type: "text", placeholder: ph, "data-fid": fid } });
        stop(i);
        i.addEventListener("keydown", e => { if (e.key !== "Enter") return; const t = i.value.trim(); if (t) onAdd(t); });
        return i;
    };
    const sec = title => { const s = c.createDiv({ cls: "dw-sec" }); s.createDiv({ cls: "dw-h", text: title }); return s; };
    const fmtD = m => m.format("M月D日");

    // earlier days, newest first, for "last time" hints
    const prev = dv.pages(`"${FOLDER}"`)
        .where(p => { const m = moment(p.file.name, "YYYY-MM-DD", true); return m.isValid() && m.isBefore(d, "day") && p.workout_log; })
        .sort(p => p.file.name, "desc").array();

    // type picker (multi: e.g. gym + stretch)
    const TYPES = [["strength", "无氧"], ["incline", "爬坡"], ["stretch", "拉伸"], ["pilates", "普拉提"], ["ball", "球类"], ["rest", "休息"]];
    const tp = c.createDiv({ cls: "dw-types" });
    for (const [v, label] of TYPES) {
        const isOn = on.includes(v);
        tp.createEl("button", { cls: "da-chip dw-type" + (isOn ? " on" : ""), text: label }).onclick = () => setFM({ workout: old => {
            let o = arr(old).map(String).filter(x => TYPES.some(t => t[0] === x));
            if (v === "rest") return isOn ? null : ["rest"];
            o = o.filter(x => x !== "rest");
            o = isOn ? o.filter(x => x !== v) : [...o, v];
            return o.length ? o : null;
        } });
    }
    if (!on.length || on.includes("rest")) c.createDiv({ cls: "da-hint", text: on.includes("rest") ? "今天休息。" : "选今天做了什么，可以多选。" });

    // 1. 无氧
    if (on.includes("strength")) {
        const s = sec("无氧 · strength");
        const S = W.strength || {};
        const SPLITS = [["glutes", "臀腿"], ["shoulders", "肩"], ["back", "背"], ["core", "核心"]];
        const LIB = {
            glutes: ["臀推", "深蹲", "罗马尼亚硬拉", "保加利亚分腿蹲", "腿举", "髋外展", "腿弯举"],
            shoulders: ["哑铃推举", "侧平举", "俯身飞鸟", "面拉", "前平举", "器械推肩"],
            back: ["高位下拉", "坐姿划船", "单臂哑铃划船", "辅助引体向上", "直臂下压", "背伸"],
            core: ["平板支撑", "卷腹", "死虫", "悬垂举腿", "俄罗斯转体", "侧平板"]
        };
        const lastS = prev.find(p => p.workout_log.strength && p.workout_log.strength.split);
        const sp = s.createDiv({ cls: "dw-row" });
        sp.createSpan({ cls: "da-label", text: "部位" });
        const spv = sp.createDiv({ cls: "da-val" });
        for (const [v, label] of SPLITS)
            spv.createEl("button", { cls: "da-chip" + (S.split === v ? " on" : ""), text: label }).onclick = () => setLog("strength", o => { o.split = o.split === v ? null : v; return o; });
        if (lastS) {
            const li = SPLITS.findIndex(x => x[0] === lastS.workout_log.strength.split);
            const nx = SPLITS[(li + 1) % SPLITS.length];
            s.createDiv({ cls: "da-hint dw-cycle", text: `上次练 ${SPLITS[li] ? SPLITS[li][1] : "?"} · ${fmtD(moment(lastS.file.name))}　→　按周期今天轮到 ${nx[1]}` });
        }

        const ex = arr(S.ex).filter(e => e && e.name);
        const lastFor = name => {
            for (const p of prev) { const e = arr(p.workout_log.strength && p.workout_log.strength.ex).find(x => x && x.name === name); if (e && arr(e.sets).length) return { day: p.file.name, sets: arr(e.sets) }; }
            return null;
        };
        const setTxt = st => `${st.w ?? "–"}kg × ${st.r ?? "–"}`;
        const list = s.createDiv({ cls: "dw-exlist" });
        ex.forEach((e, ei) => {
            const b = list.createDiv({ cls: "dw-ex" });
            const h = b.createDiv({ cls: "dw-exh" });
            h.createSpan({ cls: "dw-exn", text: e.name });
            const L = lastFor(e.name);
            if (L) h.createSpan({ cls: "dw-last", text: `上次 ${fmtD(moment(L.day))}：${L.sets.map(setTxt).join(" · ")}` });
            h.createEl("button", { cls: "da-x", text: "×" }).onclick = () => setLog("strength", o => { o.ex = arr(o.ex).filter((_, j) => j !== ei); return o; });
            const sets = arr(e.sets);
            const tb = b.createDiv({ cls: "dw-sets" });
            sets.forEach((st, si) => {
                const r = tb.createDiv({ cls: "dw-set" });
                r.createSpan({ cls: "dw-si", text: String(si + 1) });
                const upd = (k, v) => setLog("strength", o => { o.ex[ei].sets[si][k] = v; return o; });
                nIn(r, st.w, "kg", `s-${ei}-${si}-w`, v => upd("w", v));
                r.createSpan({ cls: "dw-u", text: "kg  ×" });
                nIn(r, st.r, "次", `s-${ei}-${si}-r`, v => upd("r", v));
                r.createSpan({ cls: "dw-u", text: "次" });
                r.createEl("button", { cls: "da-x", text: "×" }).onclick = () => setLog("strength", o => { o.ex[ei].sets.splice(si, 1); return o; });
            });
            const plus = b.createEl("button", { cls: "dw-plus", text: "+ 一组" });
            plus.onclick = () => setLog("strength", o => {
                const ss = arr(o.ex[ei].sets);
                const base = ss.length ? ss[ss.length - 1] : (L ? L.sets[0] : { w: null, r: null });
                o.ex[ei].sets = [...ss, { w: base.w ?? null, r: base.r ?? null }]; return o;
            });
            tIn(b, e.note, "这个动作的备注（感觉、调整座椅…）", `s-${ei}-note`, v => setLog("strength", o => { o.ex[ei].note = v; return o; }), "dw-exnote");
        });

        const addEx = name => setLog("strength", o => {
            o.ex = arr(o.ex);
            if (!o.ex.some(x => x.name === name)) { const L = lastFor(name); o.ex.push({ name, sets: L ? L.sets.map(x => ({ w: x.w ?? null, r: x.r ?? null })) : [{ w: null, r: null }] }); }
            return o;
        });
        const used = new Set(ex.map(e => e.name));
        const hist = [];
        for (const p of prev) { const ps = p.workout_log.strength; if (ps && (!S.split || ps.split === S.split)) for (const e of arr(ps.ex)) if (e && e.name && !hist.includes(e.name)) hist.push(e.name); }
        const pool = [...new Set([...(S.split ? LIB[S.split] : []), ...hist])].filter(n => !used.has(n)).slice(0, 12);
        const q = s.createDiv({ cls: "dw-pool" });
        for (const n of pool) q.createEl("button", { cls: "da-chip", text: "+ " + n }).onclick = () => addEx(n);
        adder(q, S.split ? "+ 其他动作" : "先选部位，或直接输入动作", "s-add", addEx);

        let nSets = 0, vol = 0;
        for (const e of ex) for (const st of arr(e.sets)) { nSets++; vol += (num(st.w) || 0) * (num(st.r) || 0); }
        if (ex.length) s.createDiv({ cls: "dw-sum", text: `${ex.length} 个动作 · ${nSets} 组 · 总容量 ${Math.round(vol)} kg` });

        const fr = s.createDiv({ cls: "dw-row" });
        fr.createSpan({ cls: "da-label", text: "感受" });
        const fv = fr.createDiv({ cls: "da-val" });
        for (const f of ["轻松", "刚好", "吃力", "力竭"])
            fv.createEl("button", { cls: "da-chip" + (S.feel === f ? " on" : ""), text: f }).onclick = () => setLog("strength", o => { o.feel = o.feel === f ? null : f; return o; });
        tIn(s, S.note, "今天的感受、状态、哪里酸…", "s-note", v => setLog("strength", o => { o.note = v; return o; }), "dw-wide");
    }

    // 2. 爬坡
    if (on.includes("incline")) {
        const s = sec("爬坡 · incline walk");
        const I = W.incline || {};
        const r = s.createDiv({ cls: "dw-trio" });
        for (const [k, lab, ph] of [["min", "时长", "min"], ["incline", "坡度", "%"], ["speed", "速度", "km/h"]]) {
            const f = r.createDiv({ cls: "dw-field" });
            f.createDiv({ cls: "dw-fl", text: lab });
            const w = f.createDiv({ cls: "dw-fv" });
            nIn(w, I[k], ph, "i-" + k, v => setLog("incline", o => { o[k] = v; return o; }), "dw-big");
            w.createSpan({ cls: "dw-u", text: ph });
        }
        if (num(I.min) && num(I.speed)) s.createDiv({ cls: "dw-sum", text: `约 ${(num(I.min) * num(I.speed) / 60).toFixed(2)} km` });
        const L = prev.find(p => p.workout_log.incline && p.workout_log.incline.min);
        if (L) { const x = L.workout_log.incline; s.createDiv({ cls: "da-hint", text: `上次 ${fmtD(moment(L.file.name))}：${x.min ?? "–"} min · 坡度 ${x.incline ?? "–"}% · ${x.speed ?? "–"} km/h` }); }
    }

    // 3. 拉伸
    if (on.includes("stretch")) {
        const s = sec("拉伸 · stretch");
        const T = W.stretch || {};
        const parts = arr(T.parts).map(String);
        const pr = s.createDiv({ cls: "dw-row" });
        pr.createSpan({ cls: "da-label", text: "部位" });
        const pv = pr.createDiv({ cls: "da-val" });
        for (const p of ["颈肩", "胸背", "腰", "髋", "臀", "腿后侧", "大腿前侧", "小腿", "全身"])
            pv.createEl("button", { cls: "da-chip" + (parts.includes(p) ? " on" : ""), text: p }).onclick = () => setLog("stretch", o => { const a = arr(o.parts); o.parts = a.includes(p) ? a.filter(x => x !== p) : [...a, p]; return o; });
        const mr = s.createDiv({ cls: "dw-row" });
        mr.createSpan({ cls: "da-label", text: "动作" });
        const mv = mr.createDiv({ cls: "da-val" });
        arr(T.moves).forEach((m, i) => {
            const t = mv.createSpan({ cls: "dw-tag", text: String(m) });
            t.createEl("button", { cls: "dw-tx", text: "×" }).onclick = () => setLog("stretch", o => { o.moves = arr(o.moves).filter((_, j) => j !== i); return o; });
        });
        const recentMoves = [...new Set(prev.flatMap(p => arr(p.workout_log.stretch && p.workout_log.stretch.moves).map(String)))].filter(m => !arr(T.moves).includes(m)).slice(0, 8);
        for (const m of recentMoves) mv.createEl("button", { cls: "da-chip dw-ghost", text: "+ " + m }).onclick = () => setLog("stretch", o => { o.moves = [...arr(o.moves), m]; return o; });
        adder(mv, "+ 动作，回车", "st-add", t => setLog("stretch", o => { o.moves = [...arr(o.moves), t]; return o; }));
    }

    // 4. 普拉提
    if (on.includes("pilates")) {
        const s = sec("普拉提 · pilates");
        const P = W.pilates || {};
        const ms = arr(P.moves).filter(m => m && m.name);
        const tb = s.createDiv({ cls: "dw-sets" });
        ms.forEach((m, i) => {
            const r = tb.createDiv({ cls: "dw-set dw-pil" });
            r.createSpan({ cls: "dw-exn", text: m.name });
            nIn(r, m.sets, "组", `p-${i}`, v => setLog("pilates", o => { o.moves[i].sets = v; return o; }));
            r.createSpan({ cls: "dw-u", text: "组" });
            r.createEl("button", { cls: "da-x", text: "×" }).onclick = () => setLog("pilates", o => { o.moves = arr(o.moves).filter((_, j) => j !== i); return o; });
        });
        const recent = [...new Set(prev.flatMap(p => arr(p.workout_log.pilates && p.workout_log.pilates.moves).map(m => m && m.name).filter(Boolean)))].filter(n => !ms.some(m => m.name === n)).slice(0, 8);
        const q = s.createDiv({ cls: "dw-pool" });
        const addP = n => setLog("pilates", o => { o.moves = [...arr(o.moves), { name: n, sets: null }]; return o; });
        for (const n of recent) q.createEl("button", { cls: "da-chip", text: "+ " + n }).onclick = () => addP(n);
        adder(q, "+ 动作，回车", "p-add", addP);
        tIn(s, P.note, "备注", "p-note", v => setLog("pilates", o => { o.note = v; return o; }), "dw-wide");
    }

    // 5. 球类
    if (on.includes("ball")) {
        const s = sec("球类 · court");
        const B = W.ball || {};
        const sport = B.sport || "网球";
        const br = s.createDiv({ cls: "dw-row" });
        br.createSpan({ cls: "da-label", text: "项目" });
        const bv = br.createDiv({ cls: "da-val" });
        for (const sp of ["网球", "羽毛球", "匹克球", "其他"])
            bv.createEl("button", { cls: "da-chip" + (sport === sp ? " on" : ""), text: sp }).onclick = () => setLog("ball", o => { o.sport = sp; return o; });
        const tr = s.createDiv({ cls: "dw-row" });
        tr.createSpan({ cls: "da-label", text: "时长" });
        const tv = tr.createDiv({ cls: "da-val" });
        nIn(tv, B.min, "min", "b-min", v => setLog("ball", o => { o.sport = o.sport || sport; o.min = v; return o; }));
        tv.createSpan({ cls: "dw-u", text: "min" });
        tIn(s, B.note, "备注（和谁打、发球怎么样…）", "b-note", v => setLog("ball", o => { o.sport = o.sport || sport; o.note = v; return o; }), "dw-wide");
    }
}

// ── Food ──
{
    const c = card("da-food", "Food");
    textInput(row(c, "🍳 Breakfast"), "breakfast", "");
    textInput(row(c, "🍱 Lunch"), "lunch", "");
    textInput(row(c, "🍲 Dinner"), "dinner", "");
    textInput(row(c, "🍪 Snacks"), "snacks", "");
}

// ── Health ── (title opens the Health hub in 40 Life/Health)
{
    const c = card("da-health", "Health", HEALTH);
    const hub = dv.page(HEALTH) || {};
    const past = dv.pages(`"${FOLDER}"`)
        .where(p => { const m = moment(p.file.name, "YYYY-MM-DD", true); return m.isValid() && m.isSameOrBefore(d, "day"); })
        .sort(p => p.file.name, "asc").array();

    // Period
    const FLOW = [["spotting", "spotting"], ["light", "🩸 light"], ["medium", "🩸🩸 medium"], ["heavy", "🩸🩸🩸 heavy"]];
    chips(row(c, "Period"), FLOW, cur.period, v => setFM({ period: v }));
    if (cur.period) {
        const sy = arr(cur.period_symptoms);
        const sv = row(c, "Symptoms");
        for (const s of ["cramps", "headache", "bloating", "tired", "moody", "back pain"]) {
            const b = sv.createEl("button", { cls: "da-chip" + (sy.includes(s) ? " on" : ""), text: s });
            b.onclick = () => setFM({ period_symptoms: old => { const o = arr(old); const n = o.includes(s) ? o.filter(x => x !== s) : [...o, s]; return n.length ? n : null; } });
        }
    }
    const flowDays = new Set(past.filter(p => p.period && p.period !== "spotting").map(p => p.file.name));
    if (cur.period && cur.period !== "spotting") flowDays.add(d.format("YYYY-MM-DD"));
    const starts = [...flowDays].sort().filter(k => !flowDays.has(moment(k).subtract(1, "day").format("YYYY-MM-DD")));
    if (starts.length) {
        const last = moment(starts[starts.length - 1]);
        const gaps = starts.slice(1).map((k, i) => moment(k).diff(moment(starts[i]), "days")).filter(g => g >= 15 && g <= 60).slice(-6);
        const avg = gaps.length ? Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length) : 28;
        let txt = `Cycle day ${d.diff(last, "days") + 1} · started ${last.format("MMM D")} · next ~${last.clone().add(avg, "days").format("MMM D")}`;
        c.createDiv({ cls: "da-hint da-cycle", text: txt });
    }

    const recent = (key, getName) => {
        const seen = new Map();
        for (const p of past.filter(p => d.diff(moment(p.file.name), "days") <= 60))
            for (const e of arr(p[key])) { const n = getName(e); if (n) seen.set(String(n).toLowerCase(), String(n)); }
        return [...seen.values()];
    };

    // Supplements: everything in your supplement storage + anything taken lately
    const stock = arr(hub.supplement_stock).filter(s => s && s.name).map(s => String(s.name));
    const sup = arr(cur.supplements).map(String);
    const sv = row(c, "Supplements");
    const seen = new Set(); const supNames = [];
    for (const s of [...stock, ...recent("supplements", String), ...sup]) { const k = s.toLowerCase(); if (!seen.has(k)) { seen.add(k); supNames.push(s); } }
    for (const s of supNames) {
        const on = sup.some(x => x.toLowerCase() === s.toLowerCase());
        const b = sv.createEl("button", { cls: "da-chip" + (on ? " on" : ""), text: (on ? "✓ " : "") + s });
        b.onclick = () => setFM({ supplements: old => { const o = arr(old).map(String); return on ? o.filter(x => x.toLowerCase() !== s.toLowerCase()) : [...o, s]; } });
    }
    const si = sv.createEl("input", { cls: "da-in da-mini", attr: { type: "text", placeholder: "+ add", "data-fid": "sup-add" } });
    stop(si);
    si.addEventListener("keydown", e => {
        if (e.key !== "Enter") return;
        const t = si.value.trim(); if (!t) return;
        setFM({ supplements: old => { const o = arr(old).map(String); return o.some(x => x.toLowerCase() === t.toLowerCase()) ? o : [...o, t]; } });
    });

    // Medicine: log with time; one-tap buttons for active prescriptions + recent meds
    const meds = arr(cur.medicine).map(e => typeof e === "object" ? e : { name: String(e) });
    const mv = row(c, "Medicine");
    const mi = mv.createEl("input", { cls: "da-in", attr: { type: "text", placeholder: "e.g. ibuprofen 400mg", "data-fid": "med-add" } });
    const mb = mv.createEl("button", { cls: "da-btn", text: "Add" });
    stop(mi);
    const addMed = name => { name = (name || "").trim(); if (!name) return mi.focus();
        setFM({ medicine: old => [...arr(old), { name, time: moment().format("HH:mm") }] }); };
    mb.onclick = () => addMed(mi.value);
    mi.addEventListener("keydown", e => { if (e.key === "Enter") addMed(mi.value); });
    const rx = arr(hub.prescriptions).filter(p => p && p.name && p.active !== false).map(p => String(p.name));
    const qs = new Set(); const quick = [];
    for (const n of [...rx, ...recent("medicine", e => typeof e === "object" ? e.name : String(e))]) {
        const k = n.toLowerCase();
        if (qs.has(k) || meds.some(m => String(m.name || "").toLowerCase() === k)) continue;
        qs.add(k); quick.push(n);
    }
    if (quick.length) {
        const q = c.createDiv({ cls: "da-val da-quick" });
        for (const n of quick.slice(0, 8)) q.createEl("button", { cls: "da-chip" + (rx.includes(n) ? " da-rx" : ""), text: (rx.includes(n) ? "℞ " : "+ ") + n }).onclick = () => addMed(n);
    }
    if (meds.length) {
        const list = c.createDiv({ cls: "da-list" });
        meds.forEach((m, idx) => {
            const r = list.createDiv({ cls: "da-item" });
            r.createSpan({ cls: "da-time", text: m.time || "" });
            r.createSpan({ cls: "da-note", text: m.name || "" });
            r.createEl("button", { cls: "da-x", text: "×" }).onclick = () => setFM({ medicine: old => arr(old).filter((_, j) => j !== idx) });
        });
    }
}

// ── Activity log ── (saved to activities: [{time, text, tag}])
{
    const c = grid.createDiv({ cls: "da-card da-activity" });
    const hd = c.createDiv({ cls: "al-head" });
    hd.createDiv({ cls: "da-title", text: "Activity log" });
    const acts = arr(cur.activities).filter(a => a && typeof a === "object" && a.text);
    if (acts.length) hd.createSpan({ cls: "al-count", text: `${acts.length} ${acts.length === 1 ? "entry" : "entries"}` });
    const TAGS = ["study", "work", "errand", "social", "home", "out", "rest"];
    window._alTag = window._alTag ?? null;
    const now = () => moment().format("HH:mm");
    const form = c.createDiv({ cls: "al-form" });
    const tm = form.createEl("input", { cls: "da-in al-time", attr: { type: "text", inputmode: "numeric", "data-fid": "al-time" } });
    tm.value = isDaily && d.isSame(moment(), "day") ? now() : "";
    tm.placeholder = "HH:mm";
    const tx = form.createEl("input", { cls: "da-in", attr: { type: "text", placeholder: "What did you just do?", "data-fid": "al-text" } });
    const btn = form.createEl("button", { cls: "da-btn", text: "Add" });
    stop(tm); stop(tx);
    const tg = c.createDiv({ cls: "al-tags" });
    const tagBtns = TAGS.map(t => {
        const b = tg.createEl("button", { cls: "da-chip al-tag" + (window._alTag === t ? " on" : ""), text: t });
        b.onclick = () => { window._alTag = window._alTag === t ? null : t; tagBtns.forEach(x => x.toggleClass("on", x.textContent === window._alTag)); };
        return b;
    });
    const add = () => {
        const t = tx.value.trim(); if (!t) return tx.focus();
        const mm = tm.value.trim().match(/^(\d{1,2})[:：.]?(\d{2})$/);
        const time = mm && +mm[1] < 24 && +mm[2] < 60 ? `${mm[1].padStart(2, "0")}:${mm[2]}` : now();
        const e = { time, text: t }; if (window._alTag) e.tag = window._alTag;
        window[FK] = { fid: "al-text", t: Date.now() };
        setFM({ activities: old => [...arr(old).filter(a => a && typeof a === "object"), e].sort((a, b) => String(a.time || "").localeCompare(String(b.time || ""))) });
    };
    btn.onclick = add;
    tx.addEventListener("keydown", e => { if (e.key === "Enter") add(); });
    const list = c.createDiv({ cls: "al-list" });
    const sorted = acts.map((a, i) => ({ ...a, i })).sort((a, b) => String(a.time || "").localeCompare(String(b.time || "")));
    if (!sorted.length) list.createDiv({ cls: "al-empty", text: "Nothing yet — jot things down as the day goes." });
    sorted.forEach((a, k) => {
        const r = list.createDiv({ cls: "al-item" + (k === sorted.length - 1 ? " latest" : "") });
        r.createSpan({ cls: "al-t", text: a.time || "" });
        r.createSpan({ cls: "al-rail" });
        r.createSpan({ cls: "al-txt", text: String(a.text) });
        if (a.tag) r.createSpan({ cls: "al-tagl", text: String(a.tag) }); else r.createSpan();
        r.createEl("button", { cls: "da-x al-x", text: "×", attr: { title: "Delete" } }).onclick = () => {
            setFM({ activities: old => { const o = arr(old).filter(x => x && typeof x === "object" && x.text); const j = o.findIndex(x => x.time === a.time && x.text === a.text && (x.tag || null) === (a.tag || null)); if (j > -1) o.splice(j, 1); return o.length ? o : null; } });
        };
    });
}

restoreFocus();
