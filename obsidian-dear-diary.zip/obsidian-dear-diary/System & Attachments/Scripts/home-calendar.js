// Home calendar — UI inspired by macOS Calendar (not affiliated with Apple).
// Views: Day / Week / Month / Year. Events can span several days.
//   • click an event → edit popover (title, location, all-day, starts, ends, notes, delete)
//   • drag an event to move it (month: to another day; week/day: to another time or day); drag its bottom edge to resize
//   • drag on an empty part of the week/day grid to create an event; double-click a day/slot to create one
//   • + button = new event, 🔍 = search
// Sources: events saved as notes in 00 Home/Calendar (Full Calendar plugin format),
//          Apple / iCloud calendars via their public link (read only), and tasks with a 📅 due date.
const EV_FOLDER = "00 Home/Calendar";
const CONFIG = "System & Attachments/calendar-config.json";
const EXPORT = "System & Attachments/Calendar export";
const DEFAULT_COLOR = "#1BADF8";
const HOUR_H = 48, LANE_H = 20, LANE_TOP = 28;
// size everything so the whole calendar fits in the visible pane (no page scrolling)
const paneH = () => { const v = dv.container.closest && (dv.container.closest(".view-content") || dv.container.closest(".markdown-reading-view")); return Math.max(460, Math.min(window.innerHeight, (v && v.clientHeight) || window.innerHeight)); };
const CHROME_H = 132; // top bar + title row + weekday header + margins
const cellH = () => Math.max(62, Math.min(116, Math.floor((paneH() - CHROME_H - 14) / 6)));
const monthLanes = () => Math.max(2, Math.floor((cellH() - LANE_TOP - 2) / LANE_H));
const TODAY = moment().format("YYYY-MM-DD");
const ls = { get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} } };
const S = (window._hc2 = window._hc2 || { view: ls.get("hc2-view") || "month", date: TODAY, scroll: 7.5 * HOUR_H, pop: null });
const pad = n => String(n).padStart(2, "0");
const key = m => m.format("YYYY-MM-DD");
const sow = m => m.clone().startOf("day").subtract(m.day(), "days"); // Sunday-first like the Mac app
const snap = (min, step = 15) => Math.round(min / step) * step;
const hm = min => `${pad(Math.floor(min / 60))}:${pad(min % 60)}`;
const validHex = c => /^#[0-9a-f]{6}$/i.test(String(c || "")) ? c : DEFAULT_COLOR;
const tint = (hex, a) => hex + Math.round(a * 255).toString(16).padStart(2, "0");
const shade = (hex, f) => { const n = parseInt(hex.slice(1), 16); const c = x => Math.round(x * (1 - f)); return `rgb(${c(n >> 16)},${c((n >> 8) & 255)},${c(n & 255)})`; };
const stopKeys = el => { el.addEventListener("keydown", e => e.stopPropagation()); return el; };

let config = { feeds: [] };
try { config = JSON.parse(await app.vault.adapter.read(CONFIG)); } catch (e) {}
config.feeds = config.feeds || [];
const saveConfig = async () => { await app.vault.adapter.write(CONFIG, JSON.stringify(config, (k, v) => k === "_err" ? undefined : v, 2)); };

// ═════════ Apple Calendar (ICS) ═════════
const getReq = () => { try { return require("obsidian").requestUrl; } catch (e) { return window.requestUrl || null; } };
const FEEDS = (window._hcFeeds = window._hcFeeds || {});
const feedText = f => { const k = "hc-feed-" + f.url; return (FEEDS[k] && FEEDS[k].text) || ls.get(k) || ""; };
async function fetchFeed(f, force) {
    const k = "hc-feed-" + f.url;
    if (!force && FEEDS[k] && Date.now() - FEEDS[k].t < 15 * 60000) return false;
    const url = f.url.trim().replace(/^webcal:/i, "https:");
    try {
        const rq = getReq();
        const text = rq ? (await rq({ url, method: "GET" })).text : await (await fetch(url)).text();
        if (!/BEGIN:VCALENDAR/.test(text)) throw new Error("not a calendar link");
        const changed = !FEEDS[k] || FEEDS[k].text !== text;
        FEEDS[k] = { t: Date.now(), text }; ls.set(k, text); f._err = null;
        return changed;
    } catch (e) { f._err = String(e.message || e); FEEDS[k] = { t: Date.now(), text: feedText(f) }; return false; }
}
const tzOffsetMin = (date, tz) => {
    try { const a = new Date(date.toLocaleString("en-US", { timeZone: tz })), b = new Date(date.toLocaleString("en-US", { timeZone: "UTC" })); return (a - b) / 60000; } catch (e) { return null; }
};
function icsTime(v, params) {
    if (/VALUE=DATE(?!-)/.test(params) || /^\d{8}$/.test(v)) return { m: moment(v.slice(0, 8), "YYYYMMDD"), allDay: true };
    if (/Z$/.test(v)) return { m: moment.utc(v, "YYYYMMDDTHHmmss[Z]").local(), allDay: false };
    const tz = (params.match(/TZID=([^;:]+)/) || [])[1];
    if (tz) {
        const asUtc = moment.utc(v, "YYYYMMDDTHHmmss");
        const off = tzOffsetMin(asUtc.toDate(), tz.replace(/"/g, ""));
        if (off !== null) return { m: asUtc.clone().subtract(off, "minutes").local(), allDay: false };
    }
    return { m: moment(v, "YYYYMMDDTHHmmss"), allDay: false };
}
function parseICS(text, from, to, feed) {
    if (!text) return [];
    const lines = text.replace(/\r?\n[ \t]/g, "").split(/\r?\n/);
    const evs = []; let cur = null;
    const unesc = s => s.replace(/\\n/gi, "\n").replace(/\\([,;\\])/g, "$1");
    for (const line of lines) {
        if (line === "BEGIN:VEVENT") { cur = { ex: [] }; continue; }
        if (line === "END:VEVENT") { if (cur) evs.push(cur); cur = null; continue; }
        if (!cur) continue;
        const i = line.indexOf(":"); if (i < 0) continue;
        const left = line.slice(0, i), val = line.slice(i + 1);
        const [name, ...ps] = left.split(";"); const params = ps.join(";");
        if (name === "SUMMARY") cur.title = unesc(val);
        else if (name === "LOCATION") cur.location = unesc(val);
        else if (name === "DESCRIPTION") cur.notes = unesc(val);
        else if (name === "UID") cur.uid = val;
        else if (name === "STATUS") cur.status = val;
        else if (name === "DTSTART") cur.start = icsTime(val, params);
        else if (name === "DTEND") cur.end = icsTime(val, params);
        else if (name === "DURATION") cur.duration = val;
        else if (name === "RRULE") cur.rrule = Object.fromEntries(val.split(";").map(x => x.split("=")));
        else if (name === "EXDATE") val.split(",").forEach(x => cur.ex.push(icsTime(x, params).m.format("YYYY-MM-DDTHH:mm")));
        else if (name === "RECURRENCE-ID") cur.recId = icsTime(val, params).m.format("YYYY-MM-DDTHH:mm");
    }
    const overrides = new Set(evs.filter(e => e.recId).map(e => e.uid + "|" + e.recId));
    const out = [];
    const DOW = { SU: 0, MO: 1, TU: 2, WE: 3, TH: 4, FR: 5, SA: 6 };
    for (const e of evs) {
        if (!e.start || e.status === "CANCELLED") continue;
        const s0 = e.start.m;
        const len = e.end ? e.end.m.diff(s0) : (e.duration ? moment.duration(e.duration).asMilliseconds() : (e.start.allDay ? 864e5 : 36e5));
        const push = s => {
            const k = s.format("YYYY-MM-DDTHH:mm");
            if (e.ex.includes(k)) return;
            if (!e.recId && overrides.has(e.uid + "|" + k)) return;
            const en = s.clone().add(Math.max(len, 0), "ms");
            if (!en.isAfter(from) || !s.isBefore(to)) return;
            out.push({ id: `${feed.url}|${e.uid}|${k}`, title: e.title || "(no title)", start: s.clone(), end: en.isAfter(s) ? en : s.clone().add(e.start.allDay ? 1 : 0, e.start.allDay ? "day" : "ms"), allDay: e.start.allDay, location: e.location, notes: e.notes, src: "feed", color: validHex(feed.color), feed: feed.name, readonly: true });
        };
        const r = e.rrule;
        if (!r) { push(s0); continue; }
        const freq = r.FREQ, iv = parseInt(r.INTERVAL || "1"), count = r.COUNT ? parseInt(r.COUNT) : Infinity;
        const until = r.UNTIL ? icsTime(r.UNTIL, "").m : null;
        const unitOf = { DAILY: "days", WEEKLY: "weeks", MONTHLY: "months", YEARLY: "years" }[freq];
        if (!unitOf) { push(s0); continue; }
        const byday = r.BYDAY ? r.BYDAY.split(",") : null;
        let n = 0, stop = false;
        for (let step = 0; step < 5000 && !stop; step++) {
            const base = s0.clone().add(step * iv, unitOf);
            if (base.isAfter(to)) break;
            let cands = [base];
            if (freq === "WEEKLY" && byday) {
                const wk0 = base.clone().startOf("day").subtract(base.day(), "days");
                cands = byday.map(b => wk0.clone().add(DOW[b.slice(-2)], "days").hour(s0.hour()).minute(s0.minute()).second(0)).filter(c => !c.isBefore(s0)).sort((a, b) => a - b);
            } else if (freq === "MONTHLY" && byday) {
                cands = byday.map(b => {
                    const mm = b.match(/^(-?\d)?(\w\w)$/); if (!mm) return null;
                    const nth = parseInt(mm[1] || "1"), dw = DOW[mm[2]];
                    const m0 = base.clone().startOf("month"); let c;
                    if (nth > 0) { c = m0.clone().day(dw); if (c.isBefore(m0)) c.add(7, "days"); c.add((nth - 1) * 7, "days"); }
                    else { c = m0.clone().endOf("month").startOf("day").day(dw); if (c.month() !== m0.month()) c.subtract(7, "days"); }
                    return c.hour(s0.hour()).minute(s0.minute()).second(0);
                }).filter(c => c && c.month() === base.month() && !c.isBefore(s0));
            } else if (freq === "MONTHLY" && r.BYMONTHDAY) {
                cands = r.BYMONTHDAY.split(",").map(x => base.clone().date(parseInt(x)));
            }
            for (const c of cands) {
                if ((until && c.isAfter(until)) || n >= count) { stop = true; break; }
                n++; push(c);
            }
        }
    }
    return out;
}

// ═════════ vault events + tasks ═════════
const dstr = v => { if (!v) return null; if (v instanceof Date) return moment(v).format("YYYY-MM-DD"); const s = String(v).slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null; };
const tstr = v => typeof v === "number" ? hm(v) : (String(v || "").match(/^\d{1,2}:\d{2}/) || ["00:00"])[0].padStart(5, "0");
function vaultEvents() {
    const out = [];
    for (const f of app.vault.getMarkdownFiles()) {
        if (!f.path.startsWith(EV_FOLDER + "/")) continue;
        const fm = (app.metadataCache.getFileCache(f) || {}).frontmatter;
        const d0 = fm && dstr(fm.date); if (!d0) continue;
        const d1 = dstr(fm.endDate) || d0;
        const allDay = fm.allDay === true || fm.allDay === "true" || !fm.startTime;
        let start, end;
        if (allDay) { start = moment(d0); end = moment(d1).add(1, "day"); if (!end.isAfter(start)) end = start.clone().add(1, "day"); }
        else { start = moment(`${d0} ${tstr(fm.startTime)}`, "YYYY-MM-DD HH:mm"); end = moment(`${d1} ${tstr(fm.endTime || fm.startTime)}`, "YYYY-MM-DD HH:mm"); if (!end.isAfter(start)) end = start.clone().add(1, "hour"); }
        out.push({ id: f.path, title: fm.title || f.basename, start, end, allDay, location: fm.location || "", src: "vault", path: f.path, color: validHex(fm.color), apple: fm.apple });
    }
    return out;
}
function taskEvents() {
    const out = [];
    try {
        for (const t of dv.pages('-"80 Library" and -"System & Attachments"').file.tasks.where(t => !t.completed && t.due)) {
            const d = moment(t.due.toFormat ? t.due.toFormat("yyyy-MM-dd") : String(t.due).slice(0, 10), "YYYY-MM-DD");
            if (!d.isValid()) continue;
            const title = String(t.text).replace(/[📅⏳🛫✅➕]\s*\d{4}-\d{2}-\d{2}/gu, "").replace(/[⏫🔼🔽🔺⏬]/gu, "").replace(/#\S+/g, "").trim();
            out.push({ id: "task|" + t.path + "|" + t.line, title, start: d, end: d.clone().add(1, "day"), allDay: true, src: "task", path: t.path, line: t.line, raw: t.text, color: "#007AFF", readonly: true });
        }
    } catch (e) {}
    return out;
}
// deadlines (Kanban cards with a date + Home Deadlines.md) and yearly important dates, read once per render of the view
const XTRA = { lines: {} };
for (const pth of ["00 Home/Kanban.md", "00 Home/Deadlines.md", "00 Home/Important Dates.md"]) {
    const f = app.vault.getAbstractFileByPath(pth);
    try { XTRA.lines[pth] = f ? (await app.vault.cachedRead(f)).split("\n") : []; } catch (e) { XTRA.lines[pth] = []; }
}
const xClean = s => s.replace(/@@?\{[^}]*\}/g, "").replace(/#[^\s#\[]+/g, "").replace(/\[\[([^\]|]+\|)?([^\]]+)\]\]/g, "$2").replace(/\s*[(（][^)）]*[)）]/g, "").replace(/^[\s·|]+|[\s·|]+$/g, "").replace(/\s+/g, " ").trim();
function extraEvents(from, to) {
    const out = [], day = (d, title, color, kind, path, time) => {
        let s = moment(d, "YYYY-MM-DD"); if (!s.isValid()) return;
        if (time) { const st = moment(`${d} ${time}`, "YYYY-MM-DD HH:mm"); out.push({ id: `x|${kind}|${d}|${title}`, title, start: st, end: st.clone().add(1, "hour"), allDay: false, src: "imp", kind, path, color, readonly: true }); }
        else out.push({ id: `x|${kind}|${d}|${title}`, title, start: s, end: s.clone().add(1, "day"), allDay: true, src: "imp", kind, path, color, readonly: true });
    };
    for (const l of XTRA.lines["00 Home/Kanban.md"]) {
        const m = l.match(/^\s*- \[ \]\s+(.*)$/); if (!m) continue;
        const d = m[1].match(/@\{(\d{4}-\d{2}-\d{2})\}/); if (!d) continue;
        day(d[1], xClean(m[1]), "#E0868F", "deadline", "00 Home/Kanban.md");
    }
    for (const l of XTRA.lines["00 Home/Deadlines.md"]) {
        const m = l.match(/^\s*[-*]\s+(\d{4}-\d{2}-\d{2})(?:\s+(\d{1,2}:\d{2}))?\s*[·|]?\s*(.+)$/); if (!m) continue;
        day(m[1], xClean(m[3]), "#829EBE", "deadline", "00 Home/Deadlines.md", m[2]);
    }
    const COL = { birthday: "#D9A3AD", anniversary: "#C9A0C8", holiday: "#D7B26A" };
    for (const l of XTRA.lines["00 Home/Important Dates.md"]) {
        const m = l.match(/^\s*[-*]\s+(?:(\d{4})-)?(\d{2})-(\d{2})\s*[·|]?\s*(.+)$/); if (!m) continue;
        const tag = ((m[4].match(/#([^\s#\[]+)/) || [])[1] || "other").toLowerCase();
        for (let y = moment(from).year() - 1; y <= moment(to).year() + 1; y++) {
            if (m[1] && y < Number(m[1])) continue;
            day(`${y}-${m[2]}-${m[3]}`, xClean(m[4]), COL[tag] || "#A1A1A6", tag, "00 Home/Important Dates.md");
        }
    }
    return out;
}
// Send everything that lives only in Obsidian to Apple Calendar in one .ics (skips what Apple already has)
async function exportAllToApple(btn) {
    const now = moment(), from = now.clone().subtract(1, "year").startOf("year"), to = now.clone().add(2, "year").endOf("year");
    const core = s => String(s).toLowerCase().replace(/[’'`]s\b/g, "").replace(/生日|的|birthday|bday|anniversary|纪念日|deadline|[\s·\-–—:：!！()（）]/g, "");
    const inApple = new Set();
    for (const f of config.feeds.filter(f => f.url && f.on !== false)) for (const e of parseICS(feedText(f), from, to, f)) inApple.add(core(e.title) + "|" + e.start.format("MM-DD"));
    const has = (title, m) => { const c = core(title); for (const k of inApple) { const [fc, d] = k.split("|"); if (d === m.format("MM-DD") && fc && c && (fc.includes(c) || c.includes(fc))) return true; } return false; };
    const dt = (m, timed) => timed ? m.format("YYYYMMDD[T]HHmmss") : m.format("YYYYMMDD");
    const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Obsidian Home//EN"];
    let n = 0; const marked = [];
    const add = (title, s, e, allDay, rrule, notes) => {
        L.push("BEGIN:VEVENT", `UID:${core(title) || "x"}-${s.format("YYYYMMDDHHmm")}-${n}@obsidian`, `DTSTAMP:${moment.utc().format("YYYYMMDD[T]HHmmss[Z]")}`, `SUMMARY:${icsEsc(title)}`);
        if (allDay) L.push(`DTSTART;VALUE=DATE:${dt(s)}`, `DTEND;VALUE=DATE:${dt(e)}`); else L.push(`DTSTART:${dt(s, 1)}`, `DTEND:${dt(e, 1)}`);
        if (rrule) L.push(rrule);
        if (notes) L.push(`DESCRIPTION:${icsEsc(notes)}`);
        L.push("END:VEVENT"); n++;
    };
    for (const e of vaultEvents()) { if (e.apple || e.end.isBefore(now) || has(e.title, e.start)) continue; add(e.title, e.start, e.end, e.allDay); marked.push(e.path); }
    for (const e of extraEvents(now, to)) {
        if (e.kind !== "deadline" || e.start.isBefore(now, "day") || has(e.title, e.start)) continue;
        add(e.title, e.start, e.end, e.allDay);
    }
    for (const l of XTRA.lines["00 Home/Important Dates.md"]) {
        const m = l.match(/^\s*[-*]\s+(?:(\d{4})-)?(\d{2})-(\d{2})\s*[·|]?\s*(.+)$/); if (!m) continue;
        const raw = m[4], title = xClean(raw), note = (raw.match(/[(（]([^)）]*)[)）]/) || [])[1] || "";
        const s = moment(`${m[1] || now.year()}-${m[2]}-${m[3]}`, "YYYY-MM-DD"); if (!s.isValid() || has(title, s)) continue;
        add(title, s, s.clone().add(1, "day"), true, "RRULE:FREQ=YEARLY", note);
    }
    L.push("END:VCALENDAR");
    if (!n) { new Notice("Everything is already in Apple Calendar"); return; }
    if (!(await app.vault.adapter.exists(EXPORT))) await app.vault.adapter.mkdir(EXPORT);
    const p = `${EXPORT}/All from Obsidian ${now.format("YYYY-MM-DD HHmm")}.ics`;
    await app.vault.adapter.write(p, L.join("\r\n"));
    for (const path of marked) { const f = app.vault.getAbstractFileByPath(path); if (f) await app.fileManager.processFrontMatter(f, fm => { fm.apple = true; }); }
    try { await app.openWithDefaultApp(p); new Notice(`${n} events sent to Apple Calendar — choose a calendar and click OK`); }
    catch (e) { new Notice(`Saved ${n} events to ${p} — double-click it in Finder to add them to Apple Calendar`); }
}
function query(from, to) {
    let evs = [...vaultEvents(), ...taskEvents(), ...extraEvents(from, to)].filter(e => e.end.isAfter(from) && e.start.isBefore(to));
    for (const f of config.feeds.filter(f => f.url && f.on !== false)) evs.push(...parseICS(feedText(f), from, to, f));
    const feedKeys = new Set(evs.filter(e => e.src === "feed").map(e => e.title.trim().toLowerCase() + "|" + e.start.format("YYYY-MM-DD HH:mm")));
    // an Apple Calendar event on the same day with the same name wins over a birthday / deadline from the notes
    const core = s => String(s).toLowerCase().replace(/[’'`]s\b/g, "").replace(/生日|的|birthday|bday|anniversary|纪念日|deadline|[\s·\-–—:：!！()（）]/g, "");
    const feedDay = {};
    for (const e of evs) if (e.src === "feed") (feedDay[e.start.format("YYYY-MM-DD")] = feedDay[e.start.format("YYYY-MM-DD")] || []).push(core(e.title));
    evs = evs.filter(e => { if (e.src !== "imp") return true; const c = core(e.title); if (!c) return true;
        return !(feedDay[e.start.format("YYYY-MM-DD")] || []).some(f => f && (f.includes(c) || c.includes(f))); });
    return evs.filter(e => !(e.src === "vault" && e.apple && feedKeys.has(e.title.trim().toLowerCase() + "|" + e.start.format("YYYY-MM-DD HH:mm"))));
}
const lastDay = e => e.end.clone().subtract(1, "ms").startOf("day");
const isBar = e => e.src !== "task" && (e.allDay || lastDay(e).isAfter(e.start, "day"));
const sortEv = (a, b) => (b.allDay - a.allDay) || (a.start - b.start) || (b.end - a.end) || a.title.localeCompare(b.title);

// ═════════ writing ═════════
const safeName = t => t.replace(/[\\/:*?"<>|#^\[\]]/g, " ").replace(/\s+/g, " ").trim().slice(0, 60) || "Event";
const icsEsc = s => String(s || "").replace(/\\/g, "\\\\").replace(/([,;])/g, "\\$1").replace(/\n/g, "\\n");
function fmFrom(d) {
    const o = { title: d.title, allDay: d.allDay, date: d.sd };
    if (d.ed && d.ed !== d.sd) o.endDate = d.ed;
    if (!d.allDay) { o.startTime = d.st; o.endTime = d.et; }
    o.type = "single";
    if (d.location) o.location = d.location;
    return o;
}
async function createEvent(d) {
    if (!app.vault.getAbstractFileByPath(EV_FOLDER)) await app.vault.createFolder(EV_FOLDER).catch(() => {});
    let path = `${EV_FOLDER}/${d.sd} ${safeName(d.title)}.md`, i = 2;
    while (app.vault.getAbstractFileByPath(path)) path = `${EV_FOLDER}/${d.sd} ${safeName(d.title)} ${i++}.md`;
    const o = fmFrom(d); if (d.apple) o.apple = true;
    const y = Object.entries(o).map(([k, v]) => `${k}: ${typeof v === "boolean" ? v : JSON.stringify(v)}`).join("\n");
    await app.vault.create(path, `---\n${y}\n---\n${d.notes ? "\n" + d.notes + "\n" : ""}`);
    if (d.apple) await exportToApple(d);
}
async function updateEvent(path, d, notesChanged) {
    const f = app.vault.getAbstractFileByPath(path); if (!f) return;
    const o = fmFrom(d);
    await app.fileManager.processFrontMatter(f, fm => {
        for (const k of ["endDate", "startTime", "endTime", "location"]) delete fm[k];
        Object.assign(fm, o);
    });
    if (notesChanged) {
        const text = await app.vault.read(f);
        const m = text.match(/^---\n(?:[\s\S]*?\n)?---\n?/);
        await app.vault.modify(f, (m ? m[0] : "") + (d.notes ? "\n" + d.notes.trim() + "\n" : ""));
    }
}
async function moveEvent(e, dStartMin, dEndMin) {
    const ns = e.start.clone().add(dStartMin, "minutes"), ne = e.end.clone().add(dEndMin, "minutes");
    if (!ne.isAfter(ns)) return;
    const d = { title: e.title, allDay: e.allDay, location: e.location, sd: key(ns), ed: key(e.allDay ? ne.clone().subtract(1, "day") : ne.clone().subtract(1, "ms")), st: ns.format("HH:mm"), et: ne.format("HH:mm") };
    if (!e.allDay && ne.format("HH:mm") === "00:00" && ne.isAfter(ns, "day")) { d.ed = key(ne.clone().subtract(1, "day")); d.et = "23:59"; }
    await updateEvent(e.path, d, false);
    later();
}
async function exportToApple(d) {
    const dt = (day, t) => day.replace(/-/g, "") + (t ? "T" + t.replace(":", "") + "00" : "");
    const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Obsidian Home//EN", "BEGIN:VEVENT", `UID:${Date.now()}@obsidian`, `DTSTAMP:${moment.utc().format("YYYYMMDD[T]HHmmss[Z]")}`, `SUMMARY:${icsEsc(d.title)}`];
    if (d.allDay) L.push(`DTSTART;VALUE=DATE:${dt(d.sd)}`, `DTEND;VALUE=DATE:${dt(moment(d.ed || d.sd).add(1, "day").format("YYYY-MM-DD"))}`);
    else L.push(`DTSTART:${dt(d.sd, d.st)}`, `DTEND:${dt(d.ed || d.sd, d.et)}`);
    if (d.location) L.push(`LOCATION:${icsEsc(d.location)}`);
    if (d.notes) L.push(`DESCRIPTION:${icsEsc(d.notes)}`);
    L.push("END:VEVENT", "END:VCALENDAR");
    if (!(await app.vault.adapter.exists(EXPORT))) await app.vault.adapter.mkdir(EXPORT);
    const p = `${EXPORT}/${d.sd} ${safeName(d.title)}.ics`;
    await app.vault.adapter.write(p, L.join("\r\n"));
    try { await app.openWithDefaultApp(p); } catch (e) {}
}
async function completeTask(e) {
    const f = app.vault.getAbstractFileByPath(e.path); if (!f) return;
    await app.vault.process(f, text => {
        const lines = text.split("\n");
        let i = typeof e.line === "number" && lines[e.line] && lines[e.line].includes("[ ]") ? e.line : lines.findIndex(l => l.includes("[ ]") && l.includes(String(e.raw).slice(0, 20)));
        if (i >= 0) lines[i] = lines[i].replace("[ ]", "[x]") + ` ✅ ${TODAY}`;
        return lines.join("\n");
    });
}

// ═════════ shell ═════════
const host = dv.container;
const root = host.createDiv({ cls: "hc2" });
const later = (ms = 350) => setTimeout(() => { if (root.isConnected) render(); }, ms);
root.createEl("style", { text: CSS() });
const tlEl = root.createDiv({ cls: "hc2-tl" });
const mainEl = root.createDiv({ cls: "hc2-main" });
const bar = mainEl.createDiv({ cls: "hc2-bar" });
const titleRow = mainEl.createDiv({ cls: "hc2-titlerow" });
const searchBox = root.createDiv({ cls: "hc2-results" });
const bodyEl = mainEl.createDiv({ cls: "hc2-body" });
// keep the side list no taller than the calendar
try { new ResizeObserver(() => { tlEl.style.maxHeight = mainEl.offsetHeight + "px"; }).observe(mainEl); } catch (e) {}

// ═════════ task list (kanban cards with a deadline) ═════════
const KANBAN = "00 Home/Kanban.md";
async function kanbanTasks() {
    const f = app.vault.getAbstractFileByPath(KANBAN); if (!f) return [];
    const lines = (await app.vault.cachedRead(f)).split("\n"), out = [];
    let lane = "";
    lines.forEach((l, i) => {
        const h = l.match(/^##\s+(.*)/); if (h) { lane = h[1].trim(); return; }
        const m = l.match(/^\s*- \[( |x|X)\]\s+(.*)$/); if (!m || m[1] !== " ") return;
        const d = m[2].match(/@\{(\d{4}-\d{2}-\d{2})\}/); if (!d) return;
        const tags = (m[2].match(/#[^\s#]+/g) || []).map(t => t.slice(1));
        const title = m[2].replace(/@\{[^}]*\}/g, "").replace(/@@\{[^}]*\}/g, "").replace(/#[^\s#]+/g, "").replace(/\[\[([^\]|]+\|)?([^\]]+)\]\]/g, "$2").replace(/\s+/g, " ").trim();
        out.push({ line: i, raw: l, date: d[1], title, tags, lane });
    });
    return out.sort((a, b) => a.date.localeCompare(b.date) || a.line - b.line);
}
async function checkKanban(t) {
    const f = app.vault.getAbstractFileByPath(KANBAN); if (!f) return;
    await app.vault.process(f, text => {
        const L = text.split("\n");
        let i = L[t.line] === t.raw ? t.line : L.indexOf(t.raw);
        if (i >= 0) L[i] = L[i].replace("- [ ]", "- [x]");
        return L.join("\n");
    });
}
async function importantDates(ref) {
    const out = [], t0 = moment(ref || TODAY).startOf("month");
    const read = async p => { const f = app.vault.getAbstractFileByPath(p); return f ? (await app.vault.cachedRead(f)).split("\n") : []; };
    const clean = s => s.replace(/#[^\s#\[]+/g, "").replace(/\[\[([^\]|]+\|)?([^\]]+)\]\]/g, "$2").replace(/^[\s·|]+|[\s·|]+$/g, "").trim();
    for (const l of await read("00 Home/Deadlines.md")) {
        const m = l.match(/^\s*[-*]\s+(\d{4}-\d{2}-\d{2})(?:\s+\d{1,2}:\d{2})?\s*[·|]?\s*(.+)$/); if (!m) continue;
        if (m[1] < TODAY) continue;
        out.push({ date: m[1], title: clean(m[2]), kind: "deadline", src: "00 Home/Deadlines.md" });
    }
    for (const l of await read("00 Home/Important Dates.md")) {
        const m = l.match(/^\s*[-*]\s+(?:(\d{4})-)?(\d{2})-(\d{2})\s*[·|]?\s*(.+)$/); if (!m) continue;
        const tag = ((m[4].match(/#([^\s#\[]+)/) || [])[1] || "other").toLowerCase();
        let d = moment(`${t0.year()}-${m[2]}-${m[3]}`, "YYYY-MM-DD"); if (!d.isValid()) continue;
        let extra = "";
        if (m[1]) { const y = d.year() - Number(m[1]); extra = tag === "birthday" ? `turns ${y}` : `${y} year${y > 1 ? "s" : ""}`; }
        out.push({ date: d.format("YYYY-MM-DD"), title: clean(m[4]), kind: tag, extra, src: "00 Home/Important Dates.md" });
    }
    return out.filter(e => moment(e.date).isSame(t0, "month") && e.date >= TODAY).sort((a, b) => a.date.localeCompare(b.date));
}
async function renderTaskList() {
    const ts = await kanbanTasks();
    tlEl.empty();
    const hd = tlEl.createDiv({ cls: "hc2-tl-hd" });
    hd.createDiv({ cls: "hc2-tl-h", text: "Deadlines" });
    hd.createDiv({ cls: "hc2-tl-n", text: String(ts.length) });
    const tm = moment(TODAY).add(1, "day").format("YYYY-MM-DD");
    const groups = [];
    const grp = name => { let g = groups.find(x => x.name === name); if (!g) groups.push(g = { name, items: [] }); return g; };
    for (const t of ts) {
        const name = t.date < TODAY ? "Overdue" : t.date === TODAY ? "Today" : t.date === tm ? "Tomorrow"
            : moment(t.date).diff(moment(TODAY), "days") < 7 ? moment(t.date).format("dddd") : moment(t.date).format("MMM D");
        grp(name).items.push(t);
    }
    const list = tlEl.createDiv({ cls: "hc2-tl-list" });
    if (!ts.length) list.createDiv({ cls: "hc2-tl-empty", text: "No upcoming deadlines" });
    for (const g of groups) {
        list.createDiv({ cls: "hc2-tl-g" + (g.name === "Overdue" ? " late" : g.name === "Today" ? " today" : ""), text: g.name });
        for (const t of g.items) {
            const r = list.createDiv({ cls: "hc2-tl-row" + (t.date === S.date ? " sel" : "") });
            const c = r.createDiv({ cls: "hc2-tl-ck" });
            c.onclick = async ev => { ev.stopPropagation(); r.addClass("done"); await checkKanban(t); setTimeout(() => { if (root.isConnected) renderTaskList(); }, 450); };
            const b = r.createDiv({ cls: "hc2-tl-b" });
            b.createDiv({ cls: "hc2-tl-t", text: t.title || "(untitled)" });
            const meta = b.createDiv({ cls: "hc2-tl-m" });
            meta.createSpan({ cls: t.date < TODAY ? "late" : "", text: moment(t.date).format("ddd, MMM D") });
            if (t.lane && t.lane !== "To-do") meta.createSpan({ text: t.lane });
            if (t.tags.length) meta.createSpan({ text: t.tags.map(x => "#" + x).join(" ") });
            r.onclick = () => { S.date = t.date; closePop(true); render(); };
            r.oncontextmenu = ev => { ev.preventDefault(); app.workspace.openLinkText(KANBAN, "", false); };
        }
    }
    // ── Important dates: Home deadlines + yearly days (birthdays, anniversaries) ──
    const refM = moment(S.date || TODAY);
    const imp = await importantDates(refM);
    const ih = tlEl.createDiv({ cls: "hc2-tl-hd hc2-imp-hd" });
    ih.createDiv({ cls: "hc2-tl-h", text: refM.isSame(moment(TODAY), "month") ? "This Month" : refM.format("MMMM") });
    ih.createDiv({ cls: "hc2-tl-n", text: String(imp.length) });
    const il = tlEl.createDiv({ cls: "hc2-tl-list hc2-imp" });
    if (!imp.length) il.createDiv({ cls: "hc2-tl-empty", text: "Nothing else this month" });
    for (const e of imp) {
        const r = il.createDiv({ cls: "hc2-tl-row hc2-imp-row" + (e.date === S.date ? " sel" : "") });
        r.createDiv({ cls: "hc2-imp-dot k-" + e.kind });
        const b = r.createDiv({ cls: "hc2-tl-b" });
        b.createDiv({ cls: "hc2-tl-t", text: e.title.replace(/\s*[(（][^)）]*[)）]/g, "").trim() });
        if (e.extra) b.createDiv({ cls: "hc2-tl-m" }).createSpan({ text: e.extra });
        r.createDiv({ cls: "hc2-imp-in", text: moment(e.date).format("MMM D") });
        r.onclick = () => { S.date = e.date; closePop(true); render(); };
        r.oncontextmenu = ev => { ev.preventDefault(); app.workspace.openLinkText(e.src, "", false); };
    }
    const ft = tlEl.createDiv({ cls: "hc2-tl-ft" });
    ft.createEl("button", { text: "Open Kanban" }).onclick = () => app.workspace.openLinkText(KANBAN, "", false);
}
let popEl = null;

function render() {
    ls.set("hc2-view", S.view);
    bar.empty(); titleRow.empty(); bodyEl.empty();
    // top bar: + | Day Week Month Year | 🔍
    const left = bar.createDiv({ cls: "hc2-left" });
    const plus = left.createEl("button", { cls: "hc2-round", text: "+", attr: { title: "New Event" } });
    plus.onclick = () => { const d = moment(S.date); newEvent(key(d), 9 * 60, 10 * 60, false, plus); };
    const gear = left.createEl("button", { cls: "hc2-round hc2-small", text: "⚙︎", attr: { title: "Apple Calendar links" } });
    gear.onclick = () => openSettings(gear);
    if (!app.isMobile) { const ex = left.createEl("button", { cls: "hc2-round hc2-small hc2-export", text: "", attr: { title: "Send everything from Obsidian to Apple Calendar" } }); ex.setText("→ Apple"); ex.onclick = () => exportAllToApple(ex); }
    const seg = bar.createDiv({ cls: "hc2-seg" });
    for (const [v, label] of [["day", "Day"], ["week", "Week"], ["month", "Month"], ["year", "Year"]]) {
        const b = seg.createEl("button", { cls: v === S.view ? "on" : "", text: label });
        b.onclick = () => { S.view = v; closePop(true); render(); };
    }
    const right = bar.createDiv({ cls: "hc2-right" });
    const sIn = right.createEl("input", { cls: "hc2-search", attr: { type: "search", placeholder: "Search" } });
    stopKeys(sIn); sIn.value = S.q || "";
    sIn.addEventListener("input", () => { S.q = sIn.value; renderSearch(); });
    sIn.addEventListener("keydown", e => { if (e.key === "Escape") { sIn.value = ""; S.q = ""; renderSearch(); } });

    // title + nav
    const d = moment(S.date);
    const t = titleRow.createDiv({ cls: "hc2-title" });
    if (S.view === "year") t.createEl("b", { text: d.format("YYYY") });
    else if (S.view === "day") { t.createEl("b", { text: d.format("MMMM D,") }); t.appendText(" " + d.format("YYYY")); titleRow.createDiv({ cls: "hc2-sub", text: d.format("dddd") }); }
    else if (S.view === "week") { const a = sow(d), z = a.clone().add(6, "days"); t.createEl("b", { text: a.month() === z.month() ? a.format("MMMM") : `${a.format("MMM")} – ${z.format("MMM")}` }); t.appendText(" " + z.format("YYYY")); }
    else { t.createEl("b", { text: d.format("MMMM") }); t.appendText(" " + d.format("YYYY")); }
    const nav = titleRow.createDiv({ cls: "hc2-nav" });
    const unit = { day: "day", week: "week", month: "month", year: "year" }[S.view];
    const go = n => { S.date = key(moment(S.date).add(n, unit)); closePop(true); render(); };
    nav.createEl("button", { cls: "hc2-arrow", text: "‹" }).onclick = () => go(-1);
    nav.createEl("button", { cls: "hc2-today", text: "Today" }).onclick = () => { S.date = TODAY; S.scroll = Math.max(0, (moment().hour() - 2) * HOUR_H); closePop(true); render(); };
    nav.createEl("button", { cls: "hc2-arrow", text: "›" }).onclick = () => go(1);

    if (S.view === "month") renderMonth();
    else if (S.view === "week") renderTimeGrid(7);
    else if (S.view === "day") renderDay();
    else renderYear();
    renderSearch();
    renderTaskList();
    if (S.pop) drawPop();
}

// ═════════ month ═════════
function placeRow(evs, d0, n, singlesAllowed) {
    const d1 = d0.clone().add(n, "days");
    const inRow = evs.filter(e => e.end.isAfter(d0) && e.start.isBefore(d1));
    const lanes = []; const placed = [];
    const free = (l, a, b) => { for (let c = a; c <= b; c++) if (lanes[l] && lanes[l][c]) return false; return true; };
    const take = (l, a, b) => { lanes[l] = lanes[l] || []; for (let c = a; c <= b; c++) lanes[l][c] = true; };
    for (const e of inRow.filter(isBar).sort((a, b) => (a.start - b.start) || ((b.end - b.start) - (a.end - a.start)))) {
        const c0 = Math.max(0, e.start.clone().startOf("day").diff(d0, "days")), c1 = Math.min(n - 1, lastDay(e).diff(d0, "days"));
        let l = 0; while (!free(l, c0, c1)) l++;
        take(l, c0, c1);
        placed.push({ e, c0, c1, lane: l, bar: true, contL: e.start.isBefore(d0, "day"), contR: lastDay(e).isAfter(d1.clone().subtract(1, "day"), "day") });
    }
    if (singlesAllowed) for (const e of inRow.filter(e => !isBar(e)).sort(sortEv)) {
        const c = e.start.clone().startOf("day").diff(d0, "days"); if (c < 0 || c >= n) continue;
        let l = 0; while (!free(l, c, c)) l++;
        take(l, c, c); placed.push({ e, c0: c, c1: c, lane: l, bar: false });
    }
    return placed;
}
function drawItems(layer, placed, n, maxL, top, onMore) {
    const over = []; for (let c = 0; c < n; c++) over[c] = placed.some(p => p.c0 <= c && c <= p.c1 && p.lane >= maxL);
    const vis = p => p.lane < maxL - 1 || (p.lane === maxL - 1 && ![...Array(p.c1 - p.c0 + 1)].some((_, i) => over[p.c0 + i]));
    for (const p of placed) if (vis(p)) itemEl(layer, p, n, top);
    for (let c = 0; c < n; c++) if (over[c]) {
        const hidden = placed.filter(p => p.c0 <= c && c <= p.c1 && !vis(p)).length;
        const m = layer.createDiv({ cls: "hc2-more", text: `${hidden} more` });
        m.style.left = `calc(${c * 100 / n}% + 4px)`; m.style.width = `calc(${100 / n}% - 8px)`; m.style.top = `${top + (maxL - 1) * LANE_H}px`;
        m.onclick = ev => { ev.stopPropagation(); onMore(c); };
    }
}
function itemEl(layer, p, n, top) {
    const e = p.e;
    const el = layer.createDiv({ cls: "hc2-item " + (p.bar ? "bar" : "line") + (e.readonly ? " ro" : "") + (e.src === "task" ? " task" : "") });
    el.style.left = `calc(${p.c0 * 100 / n}% + ${p.contL ? 0 : 3}px)`;
    el.style.width = `calc(${(p.c1 - p.c0 + 1) * 100 / n}% - ${(p.contL ? 0 : 3) + (p.contR ? 0 : 3)}px)`;
    el.style.top = `${top + p.lane * LANE_H}px`;
    el.dataset.id = e.id;
    if (p.bar) {
        el.style.background = tint(e.color, .28); el.style.color = shade(e.color, .45);
        if (p.contL) { el.style.borderTopLeftRadius = 0; el.style.borderBottomLeftRadius = 0; }
        if (p.contR) { el.style.borderTopRightRadius = 0; el.style.borderBottomRightRadius = 0; }
        el.createSpan({ cls: "t", text: e.title });
        if (!e.allDay && !p.contL) el.createSpan({ cls: "tm", text: e.start.format("HH:mm") });
    } else {
        if (e.src === "task") el.createSpan({ cls: "circle" });
        else el.createSpan({ cls: "stripe", attr: { style: `background:${e.color}` } });
        el.createSpan({ cls: "t", text: e.title });
        if (!e.allDay) el.createSpan({ cls: "tm", text: e.start.format("HH:mm") });
    }
    if (S.pop && S.pop.id === e.id) el.addClass("selected");
    el.addEventListener("click", ev => { ev.stopPropagation(); if (el._dragged) { el._dragged = false; return; } openEvent(e, el); });
    el.addEventListener("dblclick", ev => ev.stopPropagation());
    if (!e.readonly) el.addEventListener("pointerdown", ev => dragDays(el, e, ev));
    return el;
}
function renderMonth() {
    const m0 = moment(S.date).startOf("month"), g0 = sow(m0);
    const evs = query(g0, g0.clone().add(42, "days"));
    const head = bodyEl.createDiv({ cls: "hc2-mhead" });
    for (let i = 0; i < 7; i++) head.createDiv({ text: moment().day(i).format("ddd") });
    const grid = bodyEl.createDiv({ cls: "hc2-mgrid" });
    for (let w = 0; w < 6; w++) {
        const ws = g0.clone().add(w * 7, "days");
        const row = grid.createDiv({ cls: "hc2-week" }); row.style.height = cellH() + "px";
        for (let i = 0; i < 7; i++) {
            const d = ws.clone().add(i, "days"), k = key(d);
            const cell = row.createDiv({ cls: "hc2-cell" + (d.month() !== m0.month() ? " out" : "") + (i === 0 || i === 6 ? " wkend" : "") + (k === S.date ? " sel" : ""), attr: { "data-date": k } });
            cell.style.left = `${i * 100 / 7}%`;
            const num = cell.createDiv({ cls: "hc2-num" });
            const span = num.createSpan({ cls: k === TODAY ? "today" : "", text: d.date() === 1 ? d.format("MMM D") : String(d.date()) });
            if (k === TODAY && d.date() === 1) span.addClass("wide");
            cell.onclick = () => { S.date = k; grid.querySelectorAll(".hc2-cell.sel").forEach(x => x.removeClass("sel")); cell.addClass("sel"); };
            cell.ondblclick = () => newEvent(k, 9 * 60, 10 * 60, false, cell);
        }
        drawItems(row, placeRow(evs, ws, 7, true), 7, monthLanes(), LANE_TOP, c => { S.date = key(ws.clone().add(c, "days")); S.view = "day"; render(); });
    }
}
// drag an item to another day (month view & all-day lane)
function dragDays(el, e, down) {
    if (down.button !== 0) return;
    const x0 = down.clientX, y0 = down.clientY;
    const cellAt = (x, y) => [...root.querySelectorAll(".hc2-cell[data-date], .hc2-adc[data-date]")].find(c => { const r = c.getBoundingClientRect(); return x >= r.left && x < r.right && y >= r.top && y < r.bottom; });
    const origin = cellAt(x0, y0);
    let ghost = null, target = null;
    const move = ev => {
        if (!ghost && Math.hypot(ev.clientX - x0, ev.clientY - y0) < 5) return;
        if (!ghost) { ghost = el.cloneNode(true); ghost.addClass("hc2-ghost"); ghost.style.width = Math.min(el.offsetWidth, 180) + "px"; document.body.appendChild(ghost); el.style.opacity = .35; }
        ghost.style.left = ev.clientX - 20 + "px"; ghost.style.top = ev.clientY - 10 + "px";
        const t = cellAt(ev.clientX, ev.clientY);
        if (t !== target) { if (target) target.removeClass("drop"); target = t; if (target) target.addClass("drop"); }
    };
    const up = async () => {
        document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up);
        if (!ghost) return;
        el._dragged = true; ghost.remove(); el.style.opacity = "";
        if (target) target.removeClass("drop");
        if (target && origin) {
            const diff = moment(target.dataset.date).diff(moment(origin.dataset.date), "days");
            if (diff) await moveEvent(e, diff * 1440, diff * 1440);
        }
    };
    document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
}

// ═════════ week / day grid ═════════
function layoutDay(segs) {
    segs.sort((a, b) => (a.s - b.s) || (b.e - a.e));
    const out = []; let cluster = [], end = -1;
    const flush = () => {
        const cols = [];
        for (const s of cluster) { let c = cols.findIndex(x => x <= s.s); if (c < 0) { c = cols.length; cols.push(0); } cols[c] = s.e; s.col = c; }
        for (const s of cluster) s.ncol = cols.length;
        out.push(...cluster); cluster = [];
    };
    for (const s of segs) { if (cluster.length && s.s >= end) { flush(); end = -1; } cluster.push(s); end = Math.max(end, s.e); }
    if (cluster.length) flush();
    return out;
}
function renderTimeGrid(n, parent = bodyEl) {
    const d0 = n === 7 ? sow(moment(S.date)) : moment(S.date).startOf("day");
    const days = [...Array(n)].map((_, i) => d0.clone().add(i, "days"));
    const evs = query(d0, d0.clone().add(n, "days"));
    const wrap = parent.createDiv({ cls: "hc2-tg" + (n === 1 ? " one" : "") });
    // header
    const head = wrap.createDiv({ cls: "hc2-th" }); head.createDiv({ cls: "hc2-gut" });
    for (const d of days) {
        const h = head.createDiv({ cls: "hc2-thd" + (key(d) === TODAY ? " today" : "") + (d.day() === 0 || d.day() === 6 ? " wkend" : "") });
        h.createSpan({ cls: "wd", text: d.format("ddd") });
        h.createSpan({ cls: "dn", text: String(d.date()) });
        h.onclick = () => { S.date = key(d); S.view = "day"; render(); };
    }
    // all-day lane
    const ad = wrap.createDiv({ cls: "hc2-ad" });
    ad.createDiv({ cls: "hc2-gut", text: "all-day" });
    const lane = ad.createDiv({ cls: "hc2-adl" });
    days.forEach((d, i) => { const c = lane.createDiv({ cls: "hc2-adc", attr: { "data-date": key(d) } }); c.style.left = `${i * 100 / n}%`; c.style.width = `${100 / n}%`; c.ondblclick = () => newEvent(key(d), 0, 0, true, c); });
    const adEvs = evs.filter(e => e.allDay);
    const placed = placeRow(adEvs, d0, n, true);
    const lanesUsed = placed.length ? Math.max(...placed.map(p => p.lane)) + 1 : 0;
    const maxL = 4;
    lane.style.height = Math.max(1, Math.min(lanesUsed, maxL)) * LANE_H + 6 + "px";
    drawItems(lane, placed, n, maxL, 3, c => { S.date = key(d0.clone().add(c, "days")); S.view = "day"; render(); });
    // time grid
    const sc = wrap.createDiv({ cls: "hc2-scroll" });
    const inner = sc.createDiv({ cls: "hc2-inner" }); inner.style.height = 24 * HOUR_H + "px";
    const gut = inner.createDiv({ cls: "hc2-hours" });
    const now = moment(), nowMin = now.hour() * 60 + now.minute();
    const showNow = days.some(d => key(d) === TODAY);
    for (let h = 1; h < 24; h++) {
        if (showNow && Math.abs(h * 60 - nowMin) < 14) continue;
        const l = gut.createDiv({ cls: "hc2-hl", text: `${pad(h)}:00` }); l.style.top = h * HOUR_H + "px";
    }
    if (showNow) { const l = gut.createDiv({ cls: "hc2-hl now", text: now.format("HH:mm") }); l.style.top = nowMin / 60 * HOUR_H + "px"; }
    const cols = inner.createDiv({ cls: "hc2-cols" });
    days.forEach(d => {
        const k = key(d);
        const col = cols.createDiv({ cls: "hc2-col" + (d.day() === 0 || d.day() === 6 ? " wkend" : ""), attr: { "data-date": k } });
        const segs = [];
        for (const e of evs.filter(e => !e.allDay)) {
            const ds = d.clone(), de = d.clone().add(1, "day");
            if (!e.end.isAfter(ds) || !e.start.isBefore(de)) continue;
            const s = Math.max(0, e.start.diff(ds, "minutes")), en = Math.min(1440, e.end.diff(ds, "minutes"));
            segs.push({ ev: e, s, e: Math.max(en, s + 15), day: k });
        }
        for (const sg of layoutDay(segs)) blockEl(col, sg);
        if (k === TODAY) { const nl = col.createDiv({ cls: "hc2-now" }); nl.style.top = nowMin / 60 * HOUR_H + "px"; }
        col.addEventListener("pointerdown", ev => { if (ev.target === col) dragCreate(col, ev); });
        col.addEventListener("dblclick", ev => { if (ev.target !== col) return; const r = col.getBoundingClientRect(); const m = Math.floor((ev.clientY - r.top) / HOUR_H) * 60; newEvent(k, m, Math.min(m + 60, 1439), false, col, m); });
    });
    sc.style.height = Math.max(260, paneH() - CHROME_H - 44 - lane.offsetHeight - (n === 1 ? 4 : 18)) + "px";
    setTimeout(() => { sc.style.height = Math.max(260, paneH() - CHROME_H - 44 - lane.offsetHeight - (n === 1 ? 4 : 18)) + "px"; }, 0);
    sc.addEventListener("scroll", () => { S.scroll = sc.scrollTop; });
    setTimeout(() => { sc.scrollTop = S.scroll; }, 0);
}
function blockEl(col, s) {
    const e = s.ev;
    const el = col.createDiv({ cls: "hc2-blk" + (e.readonly ? " ro" : "") });
    el.dataset.id = e.id;
    const place = (a, b) => { el.style.top = a / 60 * HOUR_H + 1 + "px"; el.style.height = Math.max(16, (b - a) / 60 * HOUR_H - 2) + "px"; el.toggleClass("short", (b - a) < 45); };
    place(s.s, s.e);
    el.style.left = `calc(${s.col / s.ncol * 100}% + 1px)`; el.style.width = `calc(${100 / s.ncol}% - 3px)`;
    el.style.background = tint(e.color, .22); el.style.borderLeftColor = e.color; el.style.color = shade(e.color, .5);
    const tt = el.createDiv({ cls: "t", text: e.title });
    const tm = el.createDiv({ cls: "tm", text: e.start.isBefore(moment(s.day)) ? `from ${e.start.format("MMM D HH:mm")}` : e.start.format("HH:mm") + (e.location ? " · " + e.location : "") });
    if (S.pop && S.pop.id === e.id) el.addClass("selected");
    el.addEventListener("click", ev => { ev.stopPropagation(); if (el._dragged) { el._dragged = false; return; } openEvent(e, el); });
    el.addEventListener("dblclick", ev => ev.stopPropagation());
    if (e.readonly) return;
    const handle = el.createDiv({ cls: "hc2-resize" });
    el.addEventListener("pointerdown", down => {
        if (down.button !== 0) return;
        down.stopPropagation();
        const resizing = down.target === handle;
        const y0 = down.clientY, x0 = down.clientX;
        let moved = false, dMin = 0, targetCol = col;
        const colAt = x => [...root.querySelectorAll(".hc2-col")].find(c => { const r = c.getBoundingClientRect(); return x >= r.left && x < r.right; });
        const move = ev => {
            const dy = ev.clientY - y0;
            if (!moved && Math.hypot(ev.clientX - x0, dy) < 4) return;
            moved = true; el.addClass("dragging");
            dMin = snap(dy / HOUR_H * 60);
            if (resizing) { const ne = Math.max(s.s + 15, Math.min(1440, s.e + dMin)); place(s.s, ne); tm.setText(`${hm(s.s)} – ${hm(ne)}`); }
            else {
                const ns = Math.max(-s.s, dMin) + s.s; dMin = ns - s.s;
                const c = colAt(ev.clientX); if (c && c !== targetCol) { targetCol = c; c.appendChild(el); }
                place(ns, ns + (s.e - s.s)); tm.setText(hm(((ns % 1440) + 1440) % 1440));
            }
        };
        const up = async () => {
            document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up);
            if (!moved) return;
            el._dragged = true;
            if (resizing) { if (dMin) await moveEvent(e, 0, dMin); }
            else {
                const dd = moment(targetCol.dataset.date).diff(moment(s.day), "days") * 1440 + dMin;
                if (dd) await moveEvent(e, dd, dd);
            }
            later(400);
        };
        document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
    });
}
function dragCreate(col, down) {
    if (down.button !== 0) return;
    const r = col.getBoundingClientRect();
    const at = y => Math.max(0, Math.min(1440, snap((y - r.top) / HOUR_H * 60)));
    const m0 = at(down.clientY); let m1 = m0, draft = null;
    const move = ev => {
        m1 = at(ev.clientY);
        if (Math.abs(m1 - m0) < 15) return;
        if (!draft) { draft = col.createDiv({ cls: "hc2-blk draft" }); draft.createDiv({ cls: "t", text: "New Event" }); draft.createDiv({ cls: "tm" }); }
        const a = Math.min(m0, m1), b = Math.max(m0, m1);
        draft.style.top = a / 60 * HOUR_H + "px"; draft.style.height = (b - a) / 60 * HOUR_H + "px"; draft.style.left = "1px"; draft.style.width = "calc(100% - 3px)";
        draft.lastChild.setText(`${hm(a)} – ${hm(b)}`);
    };
    const up = () => {
        document.removeEventListener("pointermove", move); document.removeEventListener("pointerup", up);
        if (!draft) return;
        const a = Math.min(m0, m1), b = Math.max(m0, m1);
        newEvent(col.dataset.date, a, Math.min(b, 1439), false, draft);
    };
    document.addEventListener("pointermove", move); document.addEventListener("pointerup", up);
}

// ═════════ day (grid + side panel) ═════════
function renderDay() {
    const wrap = bodyEl.createDiv({ cls: "hc2-dayview" });
    const main = wrap.createDiv({ cls: "hc2-daymain" });
    renderTimeGrid(1, main);
    const side = wrap.createDiv({ cls: "hc2-side" });
    if (!S.mini || !moment(S.mini).isSame(moment(S.date), "month")) S.mini = key(moment(S.date).startOf("month"));
    renderDaySide(side);
}
function renderDaySide(side) {
    const mm = moment(S.mini);
    const mh = side.createDiv({ cls: "hc2-minihead" });
    mh.createEl("button", { cls: "hc2-arrow", text: "‹" }).onclick = () => { S.mini = key(mm.clone().subtract(1, "month")); side.empty(); renderDaySide(side); };
    mh.createSpan({ text: mm.format("MMMM YYYY") });
    mh.createEl("button", { cls: "hc2-arrow", text: "›" }).onclick = () => { S.mini = key(mm.clone().add(1, "month")); side.empty(); renderDaySide(side); };
    miniMonth(side, mm, null, d => { S.date = d; S.mini = key(moment(d).startOf("month")); render(); });
    const d = moment(S.date);
    const list = side.createDiv({ cls: "hc2-agenda" });
    list.createDiv({ cls: "hc2-aghead", text: d.format("dddd, MMMM D") });
    const evs = query(d, d.clone().add(1, "day")).sort(sortEv);
    if (!evs.length) list.createDiv({ cls: "hc2-agempty", text: "No events" });
    for (const e of evs) {
        const r = list.createDiv({ cls: "hc2-agrow" });
        r.createSpan({ cls: e.src === "task" ? "circle" : "dot", attr: { style: e.src === "task" ? "" : `background:${e.color}` } });
        const tx = r.createDiv({ cls: "hc2-agtx" });
        tx.createDiv({ cls: "t", text: e.title });
        tx.createDiv({ cls: "tm", text: timeText(e) + (e.location ? " · " + e.location : "") });
        r.onclick = () => openEvent(e, r);
    }
}
function miniMonth(parent, mm, dotDays, onPick, selKey) {
    const g = parent.createDiv({ cls: "hc2-mini" });
    for (let i = 0; i < 7; i++) g.createDiv({ cls: "wd", text: moment().day(i).format("dd")[0] });
    const g0 = sow(mm.clone().startOf("month"));
    const weeks = Math.ceil((mm.clone().startOf("month").day() + mm.daysInMonth()) / 7);
    for (let i = 0; i < weeks * 7; i++) {
        const d = g0.clone().add(i, "days"), k = key(d);
        const c = g.createDiv({ cls: "d" + (d.month() !== mm.month() ? " out" : "") + (k === TODAY ? " today" : "") + (k === (selKey !== undefined ? selKey : (S.view === "day" ? S.date : null)) ? " sel" : "") });
        c.createSpan({ text: String(d.date()) });
        if (dotDays && d.month() === mm.month() && dotDays.has(k)) c.createSpan({ cls: "has" });
        c.onclick = ev => { ev.stopPropagation(); onPick(k); };
    }
    return g;
}

// ═════════ year ═════════
function renderYear() {
    const y = moment(S.date).year();
    const from = moment(`${y}-01-01`), to = moment(`${y + 1}-01-01`);
    const busy = new Set();
    for (const e of query(from, to)) for (let d = e.start.clone().startOf("day"), i = 0; d.isBefore(e.end) && i < 62; d.add(1, "day"), i++) busy.add(key(d));
    const g = bodyEl.createDiv({ cls: "hc2-year" });
    for (let m = 0; m < 12; m++) {
        const mm = moment(`${y}-${pad(m + 1)}-01`);
        const box = g.createDiv({ cls: "hc2-ym" });
        const h = box.createDiv({ cls: "hc2-ymh" + (mm.isSame(moment(), "month") ? " cur" : ""), text: mm.format("MMMM") });
        h.onclick = () => { S.date = key(mm); S.view = "month"; render(); };
        miniMonth(box, mm, busy, k => { S.date = k; S.view = "day"; render(); });
    }
}

// ═════════ search ═════════
function renderSearch() {
    searchBox.empty();
    const q = (S.q || "").trim().toLowerCase();
    if (!q) { searchBox.style.display = "none"; return; }
    searchBox.style.display = "";
    const evs = query(moment().subtract(1, "year"), moment().add(1, "year"))
        .filter(e => (e.title + " " + (e.location || "") + " " + (e.notes || "")).toLowerCase().includes(q)).sort((a, b) => a.start - b.start);
    if (!evs.length) { searchBox.createDiv({ cls: "hc2-agempty", text: "No results" }); return; }
    let last = null;
    for (const e of evs.slice(0, 80)) {
        const dk = key(e.start);
        if (dk !== last) { searchBox.createDiv({ cls: "hc2-aghead", text: e.start.format("ddd, MMM D, YYYY") }); last = dk; }
        const r = searchBox.createDiv({ cls: "hc2-agrow" });
        r.createSpan({ cls: e.src === "task" ? "circle" : "dot", attr: { style: e.src === "task" ? "" : `background:${e.color}` } });
        const tx = r.createDiv({ cls: "hc2-agtx" }); tx.createDiv({ cls: "t", text: e.title }); tx.createDiv({ cls: "tm", text: timeText(e) });
        r.onclick = () => { S.date = dk; S.view = "day"; S.scroll = Math.max(0, (e.start.hour() - 1) * HOUR_H); render(); };
    }
}
function timeText(e) {
    const ld = lastDay(e);
    if (e.allDay) return ld.isAfter(e.start, "day") ? `${e.start.format("MMM D")} – ${ld.format("MMM D")} · all-day` : "all-day";
    if (e.end.clone().subtract(1, "ms").isAfter(e.start, "day")) return `${e.start.format("MMM D HH:mm")} – ${e.end.format("MMM D HH:mm")}`;
    return `${e.start.format("HH:mm")} – ${e.end.format("HH:mm")}`;
}

// ═════════ popover (inspector) ═════════
function anchorRect(el) {
    const a = el.getBoundingClientRect(), r = root.getBoundingClientRect();
    return { x: a.left - r.left, y: a.top - r.top, w: a.width, h: a.height };
}
function newEvent(dateKey, sMin, eMin, allDay, anchor) {
    const rect = anchor ? anchorRect(anchor) : null;
    const isDraft = anchor && anchor.hasClass && anchor.hasClass("draft"), parent = isDraft && anchor.parentElement;
    commitPop();
    if (isDraft && parent && !anchor.isConnected) parent.appendChild(anchor);
    S.pop = { mode: "new", id: "__new", rect,
        draft: { title: "", location: "", allDay: !!allDay, sd: dateKey, ed: dateKey, st: hm(sMin), et: hm(eMin > sMin ? eMin : Math.min(sMin + 60, 1439)), notes: "", apple: typeof app.openWithDefaultApp === "function" && !app.isMobile && ls.get("hc-apple") === "1" } };
    drawPop();
}
async function openEvent(e, anchor) {
    commitPop();
    const rect = anchorRect(anchor);
    if (e.src === "vault") {
        let notes = "";
        try { const t = await app.vault.read(app.vault.getAbstractFileByPath(e.path)); notes = t.replace(/^---\n(?:[\s\S]*?\n)?---\n?/, "").trim(); } catch (x) {}
        const ed = e.allDay ? key(e.end.clone().subtract(1, "day")) : key(e.end.clone().subtract(1, "ms"));
        const draft = { title: e.title, location: e.location || "", allDay: e.allDay, sd: key(e.start), ed, st: e.start.format("HH:mm"), et: e.end.format("HH:mm") === "00:00" && !e.allDay ? "23:59" : e.end.format("HH:mm"), notes };
        S.pop = { mode: "edit", id: e.id, path: e.path, rect, draft, orig: JSON.stringify(draft) };
    } else S.pop = { mode: e.src, id: e.id, rect, ev: e };
    root.querySelectorAll(".selected").forEach(x => x.removeClass("selected"));
    anchor.addClass && anchor.addClass("selected");
    drawPop();
}
function closePop(discard) {
    if (popEl) { popEl.remove(); popEl = null; }
    if (discard) S.pop = null;
    root.querySelectorAll(".hc2-blk.draft").forEach(x => x.remove());
}
let committing = false;
async function commitPop() {
    const p = S.pop; if (!p || committing) { closePop(true); return; }
    committing = true;
    closePop(true);
    try {
        if (p.mode === "new" || p.mode === "edit") {
            const d = { ...p.draft };
            d.title = d.title.trim();
            if (p.mode === "new" && !d.title) return;
            if (!d.title) d.title = "New Event";
            if (!d.ed || d.ed < d.sd) d.ed = d.sd;
            if (!d.allDay) {
                const s = moment(`${d.sd} ${d.st}`, "YYYY-MM-DD HH:mm"), e = moment(`${d.ed} ${d.et}`, "YYYY-MM-DD HH:mm");
                if (!e.isAfter(s)) { const ne = s.clone().add(1, "hour"); d.ed = key(ne); d.et = ne.format("HH:mm"); }
            }
            if (p.mode === "new") { ls.set("hc-apple", d.apple ? "1" : "0"); await createEvent(d); }
            else if (JSON.stringify(p.draft) !== p.orig) await updateEvent(p.path, d, d.notes !== JSON.parse(p.orig).notes);
        }
    } finally { committing = false; later(); }
}
function drawPop() {
    if (popEl) popEl.remove();
    const p = S.pop; if (!p) return;
    popEl = root.createDiv({ cls: "hc2-pop" });
    popEl.addEventListener("pointerdown", e => e.stopPropagation());
    popEl.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Escape") { if (p.mode === "new") closePop(true); else commitPop(); } });
    if (p.mode === "new" || p.mode === "edit") {
        const d = p.draft;
        const ti = popEl.createEl("input", { cls: "hc2-ptitle", attr: { type: "text", placeholder: "New Event" } }); ti.value = d.title;
        ti.oninput = () => { d.title = ti.value; const dr = root.querySelector(".hc2-blk.draft .t"); if (dr) dr.setText(ti.value || "New Event"); };
        ti.onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); commitPop(); } };
        const lo = popEl.createEl("input", { cls: "hc2-ploc", attr: { type: "text", placeholder: "Add Location" } }); lo.value = d.location;
        lo.oninput = () => d.location = lo.value;
        popEl.createDiv({ cls: "hc2-sep" });
        const row = label => { const r = popEl.createDiv({ cls: "hc2-prow" }); r.createSpan({ cls: "lbl", text: label }); return r.createDiv({ cls: "val" }); };
        const ad = row("all-day:").createEl("input", { attr: { type: "checkbox" } }); ad.checked = d.allDay;
        const sr = row("starts:"), er = row("ends:");
        const fmtD = k => moment(k).format("YYYY/MM/DD");
        const normT = (v, fb) => { const m = String(v).trim().match(/^(\d{1,2})(?:[:：.]?(\d{2}))?$/); if (!m) return fb; const h = +m[1], mi = +(m[2] || 0); return h > 23 || mi > 59 ? fb : `${pad(h)}:${pad(mi)}`; };
        const sdB = sr.createEl("button", { cls: "hc2-dbtn", text: fmtD(d.sd) });
        const st = sr.createEl("input", { cls: "hc2-tin", attr: { type: "text", maxlength: 5 } }); st.value = d.st;
        const edB = er.createEl("button", { cls: "hc2-dbtn", text: fmtD(d.ed) });
        const et = er.createEl("input", { cls: "hc2-tin", attr: { type: "text", maxlength: 5 } }); et.value = d.et;
        const picker = popEl.createDiv({ cls: "hc2-picker" }); picker.style.display = "none";
        let pickFor = null, pickMonth = null;
        const refresh = () => { sdB.setText(fmtD(d.sd)); edB.setText(fmtD(d.ed)); st.value = d.st; et.value = d.et; sdB.toggleClass("on", pickFor === "s"); edB.toggleClass("on", pickFor === "e"); };
        const drawPicker = () => {
            picker.empty();
            if (!pickFor) { picker.style.display = "none"; refresh(); return; }
            picker.style.display = "";
            const h = picker.createDiv({ cls: "hc2-minihead" });
            h.createEl("button", { cls: "hc2-arrow", text: "‹" }).onclick = () => { pickMonth.subtract(1, "month"); drawPicker(); };
            h.createSpan({ text: pickMonth.format("MMMM YYYY") });
            h.createEl("button", { cls: "hc2-arrow", text: "›" }).onclick = () => { pickMonth.add(1, "month"); drawPicker(); };
            miniMonth(picker, pickMonth, null, k => {
                if (pickFor === "s") { const diff = moment(k).diff(moment(d.sd), "days"); d.sd = k; d.ed = key(moment(d.ed).add(diff, "days")); }
                else d.ed = k < d.sd ? d.sd : k;
                pickFor = null; drawPicker();
            }, pickFor === "s" ? d.sd : d.ed);
            refresh();
        };
        const openPick = w => { pickFor = pickFor === w ? null : w; pickMonth = moment(w === "s" ? d.sd : d.ed).startOf("month"); drawPicker(); };
        sdB.onclick = () => openPick("s"); edB.onclick = () => openPick("e");
        const timeInput = (inp, which) => {
            const apply = v => {
                if (which === "s") {
                    const len = moment(`${d.ed} ${d.et}`, "YYYY-MM-DD HH:mm").diff(moment(`${d.sd} ${d.st}`, "YYYY-MM-DD HH:mm"), "minutes");
                    d.st = v;
                    if (len > 0) { const ne = moment(`${d.sd} ${d.st}`, "YYYY-MM-DD HH:mm").add(len, "minutes"); d.ed = key(ne); d.et = ne.format("HH:mm"); }
                } else d.et = v;
                refresh();
            };
            inp.addEventListener("focus", () => inp.select());
            inp.addEventListener("change", () => apply(normT(inp.value, which === "s" ? d.st : d.et)));
            inp.addEventListener("keydown", e => {
                if (e.key === "Enter") { e.preventDefault(); inp.blur(); }
                if (e.key === "ArrowUp" || e.key === "ArrowDown") {
                    e.preventDefault();
                    const cur = moment(normT(inp.value, which === "s" ? d.st : d.et), "HH:mm").add(e.key === "ArrowUp" ? 15 : -15, "minutes");
                    apply(cur.format("HH:mm")); inp.select();
                }
            });
        };
        timeInput(st, "s"); timeInput(et, "e");
        const sync = () => { st.style.display = et.style.display = ad.checked ? "none" : ""; };
        sync();
        ad.onchange = () => { d.allDay = ad.checked; sync(); };
        popEl.createDiv({ cls: "hc2-sep" });
        const no = popEl.createEl("textarea", { cls: "hc2-pnotes", attr: { placeholder: "Add Notes", rows: 2 } }); no.value = d.notes;
        no.oninput = () => d.notes = no.value;
        const foot = popEl.createDiv({ cls: "hc2-pfoot" });
        if (p.mode === "new") {
            const mac = typeof app.openWithDefaultApp === "function" && !app.isMobile;
            if (mac) { const lb = foot.createEl("label", { cls: "hc2-apple" }); const cb = lb.createEl("input", { attr: { type: "checkbox" } }); cb.checked = !!d.apple; cb.onchange = () => d.apple = cb.checked; lb.appendText(" also add to Apple Calendar"); }
            const add = foot.createEl("button", { cls: "hc2-pbtn", text: "Add" }); add.onclick = () => commitPop();
        } else {
            const open = foot.createEl("button", { cls: "hc2-plink", text: "Open note" });
            open.onclick = () => { const path = p.path; commitPop(); app.workspace.openLinkText(path, "", false); };
            const del = foot.createEl("button", { cls: "hc2-pdel", text: "Delete Event" });
            del.onclick = async () => { const f = app.vault.getAbstractFileByPath(p.path); closePop(true); if (f) { if (app.fileManager.trashFile) await app.fileManager.trashFile(f); else await app.vault.trash(f, true); } later(); };
        }
        if (p.mode === "new") setTimeout(() => ti.focus(), 30);
    } else {
        const e = p.ev;
        popEl.createDiv({ cls: "hc2-ptitle ro", text: e.title });
        if (e.location) popEl.createDiv({ cls: "hc2-ploc ro", text: e.location });
        popEl.createDiv({ cls: "hc2-sep" });
        popEl.createDiv({ cls: "hc2-pinfo", text: e.allDay ? (lastDay(e).isAfter(e.start, "day") ? `${e.start.format("ddd, MMM D")} – ${lastDay(e).format("ddd, MMM D, YYYY")}` : e.start.format("dddd, MMMM D, YYYY") + " · all-day") : (e.end.clone().subtract(1, "ms").isAfter(e.start, "day") ? `${e.start.format("ddd, MMM D HH:mm")} – ${e.end.format("ddd, MMM D HH:mm")}` : `${e.start.format("dddd, MMMM D, YYYY")}\n${e.start.format("HH:mm")} – ${e.end.format("HH:mm")}`) });
        if (e.src === "feed") {
            popEl.createDiv({ cls: "hc2-pcal" }).innerHTML = `<span class="dot" style="background:${e.color}"></span>`;
            popEl.lastChild.appendText(e.feed + " · from Apple Calendar (edit it there)");
            if (e.notes) popEl.createDiv({ cls: "hc2-pinfo notes", text: e.notes });
        } else {
            popEl.createDiv({ cls: "hc2-pcal", text: "Task due date" });
            const foot = popEl.createDiv({ cls: "hc2-pfoot" });
            foot.createEl("button", { cls: "hc2-plink", text: "Open note" }).onclick = () => { closePop(true); app.workspace.openLinkText(e.path, "", false); };
            foot.createEl("button", { cls: "hc2-pbtn", text: "Mark done" }).onclick = async () => { closePop(true); await completeTask(e); later(500); };
        }
    }
    // position next to the anchor, like the Mac's popover
    const W = 320, R = root.getBoundingClientRect();
    const narrow = R.width < 640;
    popEl.style.width = (narrow ? Math.min(W, R.width - 24) : W) + "px";
    const rect = p.rect || { x: R.width / 2 - 10, y: 120, w: 20, h: 20 };
    let x = rect.x + rect.w + 10, side = "left";
    if (narrow) x = (R.width - popEl.offsetWidth) / 2;
    else if (x + W > R.width - 8) { x = rect.x - W - 10; side = "right"; }
    if (x < 8) x = 8;
    const h = popEl.offsetHeight || 260;
    let y = Math.max(8, Math.min(rect.y + rect.h / 2 - 40, root.offsetHeight - h - 8));
    if (narrow) y = rect.y + rect.h + 8;
    popEl.style.left = x + "px"; popEl.style.top = y + "px";
    if (!narrow) { popEl.addClass("arrow-" + side); popEl.style.setProperty("--ay", Math.max(16, Math.min(h - 16, rect.y + rect.h / 2 - y)) + "px"); }
}
// click anywhere outside the popover = done (saves), like the Mac app
if (window._hc2Outside) document.removeEventListener("pointerdown", window._hc2Outside, true);
window._hc2Outside = ev => {
    if (!root.isConnected) { document.removeEventListener("pointerdown", window._hc2Outside, true); return; }
    if (!S.pop || !popEl) return;
    if (popEl.contains(ev.target)) return;
    if (ev.target.closest && (ev.target.closest(".hc2-item") || ev.target.closest(".hc2-blk") || ev.target.closest(".hc2-agrow"))) return; // opening another event commits first
    commitPop();
};
document.addEventListener("pointerdown", window._hc2Outside, true);

// ═════════ Apple Calendar links ═════════
function openSettings(anchor) {
    commitPop();
    popEl = root.createDiv({ cls: "hc2-pop wide" });
    popEl.addEventListener("pointerdown", e => e.stopPropagation());
    S.pop = { mode: "settings" };
    popEl.createDiv({ cls: "hc2-ptitle ro", text: "Apple Calendar" });
    popEl.createDiv({ cls: "hc2-pinfo", text: "Show your iCloud calendars here (read-only). On Mac: Calendar → right-click a calendar → Share Calendar… → tick Public Calendar → copy the link. iPhone: Calendar → Calendars → ⓘ → Public Calendar → Share Link." });
    for (const fd of config.feeds) {
        const r = popEl.createDiv({ cls: "hc2-agrow" });
        r.createSpan({ cls: "dot", attr: { style: `background:${validHex(fd.color)}` } });
        const tx = r.createDiv({ cls: "hc2-agtx" }); tx.createDiv({ cls: "t", text: fd.name }); tx.createDiv({ cls: "tm", text: fd._err ? "couldn't load: " + fd._err : fd.url.slice(0, 46) + "…" });
        const x = r.createEl("button", { cls: "hc2-plink", text: "Remove" });
        x.onclick = async () => { config.feeds = config.feeds.filter(z => z !== fd); await saveConfig(); closePop(true); render(); };
    }
    const nm = stopKeys(popEl.createEl("input", { cls: "hc2-ploc", attr: { type: "text", placeholder: "Name (e.g. Home)" } }));
    const url = stopKeys(popEl.createEl("input", { cls: "hc2-ploc", attr: { type: "text", placeholder: "webcal://p…-caldav.icloud.com/published/2/…" } }));
    const row = popEl.createDiv({ cls: "hc2-pfoot" });
    const col = row.createEl("input", { attr: { type: "color" } }); col.value = ["#1BADF8", "#CC73E1", "#63DA38", "#FF9500", "#FF2968"][config.feeds.length % 5];
    row.createEl("button", { cls: "hc2-plink", text: "↻ Refresh" }).onclick = async () => { for (const f of config.feeds) await fetchFeed(f, true); closePop(true); render(); };
    row.createEl("button", { cls: "hc2-pbtn", text: "Add" }).onclick = async () => {
        if (!url.value.trim()) return url.focus();
        const f = { name: nm.value.trim() || "Apple", url: url.value.trim(), color: col.value, on: true };
        config.feeds.push(f); await saveConfig(); await fetchFeed(f, true); closePop(true); render();
    };
    const R = root.getBoundingClientRect(), a = anchorRect(anchor);
    popEl.style.width = Math.min(360, R.width - 24) + "px";
    popEl.style.left = Math.max(8, Math.min(a.x, R.width - popEl.offsetWidth - 8)) + "px"; popEl.style.top = a.y + a.h + 8 + "px";
}

function CSS() { return `
.hc2{--bg:var(--background-primary,#fff);--line:#E5E5EA;--txt:#1D1D1F;--mut:#8E8E93;--red:#FF3B30;--seg:#EFEFF4;--segon:#fff;--hover:#F2F2F7;--sel:#E8F2FD;--side:#F5F5F7;
  position:relative;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","PingFang SC","Helvetica Neue",sans-serif;color:var(--txt);margin:8px 10px 16px;background:var(--bg);border-radius:12px;padding:8px 4px 4px;user-select:none;}
.theme-dark .hc2{--line:#38383A;--txt:#F5F5F7;--mut:#98989D;--seg:#2C2C2E;--segon:#636366;--hover:#2C2C2E;--sel:#1C3A5A;--side:#232325;}
.hc2 button{box-shadow:none !important;border:none !important;cursor:pointer;font-family:inherit;outline:none;}
.hc2-bar{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:0 6px 6px;}
.hc2-left{display:flex;gap:6px;align-items:center;}
.hc2-round{width:30px;height:30px !important;border-radius:50% !important;padding:0 !important;background:var(--seg) !important;color:var(--txt) !important;font-size:20px !important;line-height:1;}
.hc2-round.hc2-small{font-size:14px !important;color:var(--mut) !important;background:transparent !important;}
.hc2-seg{display:flex;background:var(--seg);border-radius:9px;padding:2px;gap:2px;}
.hc2-seg button{height:26px !important;padding:0 16px !important;border-radius:7px !important;background:transparent !important;color:var(--txt) !important;font-size:13px !important;font-weight:500;}
.hc2-seg button.on{background:var(--segon) !important;box-shadow:0 1px 3px #0000001f !important;}
.hc2-right{display:flex;justify-content:flex-end;}
.hc2-search{width:170px;height:28px !important;border-radius:8px !important;border:none !important;background:var(--seg) !important;padding:0 10px !important;font-size:13px !important;}
.hc2-titlerow{display:flex;align-items:flex-end;gap:12px;padding:2px 10px 6px;position:relative;}
.hc2-title{font-size:26px;font-weight:300;letter-spacing:-.5px;line-height:1.1;}
.hc2-title b{font-weight:700;}
.hc2-sub{font-size:15px;color:var(--mut);padding-bottom:3px;}
.hc2-nav{margin-left:auto;display:flex;gap:4px;align-items:center;}
.hc2-arrow{width:28px;height:26px !important;padding:0 !important;border-radius:7px !important;background:var(--seg) !important;color:var(--txt) !important;font-size:18px !important;line-height:1;}
.hc2-today{height:26px !important;padding:0 14px !important;border-radius:7px !important;background:var(--seg) !important;color:var(--txt) !important;font-size:13px !important;}
/* month */
.hc2-mhead{display:grid;grid-template-columns:repeat(7,1fr);border-bottom:1px solid var(--line);}
.hc2-mhead div{text-align:right;padding:0 12px 6px;font-size:15px;color:var(--txt);}
.hc2-mhead div:first-child,.hc2-mhead div:last-child{color:var(--mut);}
.hc2-week{position:relative;border-bottom:1px solid var(--line);}
.hc2-cell{position:absolute;top:0;bottom:0;width:calc(100%/7);border-left:1px solid var(--line);box-sizing:border-box;}
.hc2-cell:first-child{border-left:none;}

.hc2-cell.sel{background:var(--hover);}
.hc2-cell.drop{background:var(--sel);box-shadow:inset 0 0 0 2px #D9A3AD;}
.hc2-num{text-align:right;padding:4px 6px 0;font-size:15px;height:26px;}
.hc2-num span{display:inline-block;min-width:24px;height:24px;line-height:24px;text-align:center;border-radius:12px;padding:0 2px;}
.hc2-num span.today{background:var(--red);color:#fff;font-weight:600;}
.hc2-num span.wide{padding:0 8px;}
.hc2-cell.out .hc2-num{color:var(--mut);}
.hc2-item{position:absolute;height:${LANE_H - 2}px;display:flex;align-items:center;gap:4px;font-size:12px;line-height:${LANE_H - 2}px;border-radius:4px;padding:0 5px;box-sizing:border-box;cursor:default;overflow:hidden;white-space:nowrap;z-index:1;}
.hc2-item .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;}
.hc2-item .tm{color:var(--mut);font-size:11px;flex-shrink:0;}
.hc2-item.bar .tm{color:inherit;opacity:.7;}
.hc2-item.bar{font-weight:500;}
.hc2-item.line:hover{background:var(--hover);}
.hc2-item .stripe{width:3px;height:13px;border-radius:2px;flex-shrink:0;}
.hc2-item .circle,.hc2-agrow .circle{width:10px;height:10px;border-radius:50%;border:1.5px solid #D9A3AD;flex-shrink:0;box-sizing:border-box;}
.hc2-item.selected{background:#FFF9FA !important;color:#B0707D !important;box-shadow:inset 0 0 0 1px #F3DDE1 !important;} .hc2-item.selected .tm{color:#B0707D;}
.hc2-more{position:absolute;font-size:11px;color:var(--mut);padding:0 6px;cursor:pointer;height:${LANE_H - 2}px;line-height:${LANE_H - 2}px;font-weight:500;}
.hc2-more:hover{color:var(--txt);}
.hc2-ghost{position:fixed;z-index:9999;pointer-events:none;opacity:.9;box-shadow:0 4px 14px #0003;}
/* week / day */
.hc2-tg{border-top:1px solid var(--line);}
.hc2-th,.hc2-ad{display:flex;border-bottom:1px solid var(--line);}
.hc2-gut{width:54px;flex-shrink:0;font-size:11px;color:var(--mut);text-align:right;padding:4px 8px 0 0;box-sizing:border-box;}
.hc2-thd{flex:1;display:flex;gap:5px;align-items:center;justify-content:center;padding:6px 0;font-size:13px;cursor:pointer;border-left:1px solid transparent;}
.hc2-tg.one .hc2-thd{justify-content:flex-start;padding-left:10px;}
.hc2-thd .wd{color:var(--mut);}
.hc2-thd .dn{font-size:18px;font-weight:400;min-width:28px;height:28px;line-height:28px;text-align:center;border-radius:14px;}
.hc2-thd.today .dn{background:var(--red);color:#fff;font-weight:600;}
.hc2-thd.today .wd{color:var(--red);}
.hc2-adl{flex:1;position:relative;}
.hc2-adc{position:absolute;top:0;bottom:0;border-left:1px solid var(--line);box-sizing:border-box;}
.hc2-adc.drop{background:var(--sel);}
.hc2-scroll{height:480px;overflow-y:auto;position:relative;}
.hc2-inner{display:flex;position:relative;}
.hc2-hours{width:54px;flex-shrink:0;position:relative;}
.hc2-hl{position:absolute;right:8px;transform:translateY(-50%);font-size:11px;color:var(--mut);}
.hc2-hl.now{color:var(--red);font-weight:600;}
.hc2-cols{flex:1;display:flex;position:relative;background-image:repeating-linear-gradient(to bottom,var(--line) 0,var(--line) 1px,transparent 1px,transparent ${HOUR_H}px);}
.hc2-col{flex:1;position:relative;border-left:1px solid var(--line);}
.hc2-col.wkend{background-color:#00000004;}
.hc2-blk{position:absolute;border-left:3px solid;border-radius:5px;padding:2px 5px;box-sizing:border-box;font-size:12px;overflow:hidden;cursor:default;z-index:1;}
.hc2-blk .t{font-weight:600;line-height:1.25;overflow:hidden;}
.hc2-blk .tm{font-size:11px;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.hc2-blk.short{display:flex;gap:6px;align-items:baseline;padding-top:0;}
.hc2-blk.short .t{white-space:nowrap;text-overflow:ellipsis;}
.hc2-blk.selected{background:#FFF9FA !important;color:#B0707D !important;box-shadow:inset 0 0 0 1px #F3DDE1 !important;}
.hc2-blk.dragging{opacity:.85;box-shadow:0 4px 14px #0003;z-index:5;}
.hc2-blk.draft{background:#1BADF833;border-left-color:#1BADF8;color:#0B6FA4;}
.hc2-resize{position:absolute;left:0;right:0;bottom:0;height:6px;cursor:ns-resize;}
.hc2-now{position:absolute;left:-1px;right:0;height:2px;background:var(--red);z-index:3;pointer-events:none;}
.hc2-now::before{content:"";position:absolute;left:-4px;top:-3px;width:8px;height:8px;border-radius:50%;background:var(--red);}
.hc2-dayview{display:flex;gap:12px;}
.hc2-daymain{flex:1;min-width:0;}
.hc2-side{width:240px;flex-shrink:0;padding:4px 8px;border-left:1px solid var(--line);}
.hc2-minihead{display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:13px;margin-bottom:4px;}
.hc2-minihead .hc2-arrow{background:transparent !important;}
.hc2-mini{display:grid;grid-template-columns:repeat(7,1fr);gap:1px;font-size:11.5px;text-align:center;}
.hc2-mini .wd{color:var(--mut);font-size:10.5px;padding-bottom:2px;}
.hc2-mini .d{position:relative;height:24px;line-height:22px;cursor:pointer;border-radius:12px;}
.hc2-mini .d span:first-child{display:inline-block;width:22px;height:22px;border-radius:11px;}
.hc2-mini .d:hover span:first-child{background:var(--hover);}
.hc2-mini .d.out{color:var(--mut);opacity:.6;}
.hc2-mini .d.sel span:first-child{background:var(--txt);color:var(--bg);}
.hc2-mini .d.today span:first-child{background:var(--red);color:#fff;font-weight:600;}
.hc2-mini .has{position:absolute;bottom:0;left:50%;width:4px;height:4px;margin-left:-2px;border-radius:2px;background:var(--mut);}
.hc2-agenda{margin-top:12px;}
.hc2-aghead{font-size:12px;font-weight:600;color:var(--mut);margin:10px 0 4px;}
.hc2-agrow{display:flex;gap:8px;align-items:flex-start;padding:5px 6px;border-radius:6px;cursor:pointer;}
.hc2-agrow:hover{background:var(--hover);}
.hc2-agrow .dot,.hc2-pcal .dot{width:9px;height:9px;border-radius:50%;flex-shrink:0;margin-top:4px;display:inline-block;}
.hc2-agtx .t{font-size:13px;font-weight:500;} .hc2-agtx .tm{font-size:11.5px;color:var(--mut);}
.hc2-agempty{font-size:12.5px;color:var(--mut);padding:6px;}
/* year */
.hc2-year{display:grid;grid-template-columns:repeat(4,1fr);gap:10px 26px;padding:4px 12px;}
.hc2-ymh{font-size:16px;font-weight:600;color:var(--red);margin-bottom:4px;cursor:pointer;}
.hc2-ymh:not(.cur){color:var(--txt);}
/* search results */
.hc2-results{position:absolute;right:10px;top:44px;width:300px;max-height:420px;overflow:auto;background:var(--bg);border-radius:10px;box-shadow:0 8px 30px #0003,0 0 0 1px #0000000f;padding:4px 8px 8px;z-index:20;}
/* popover */
.hc2-pop{position:absolute;z-index:30;background:var(--bg);border-radius:11px;box-shadow:0 10px 36px #00000038,0 0 0 1px #0000001a;padding:12px 14px;box-sizing:border-box;user-select:text;}
.hc2-pop.arrow-left::before,.hc2-pop.arrow-right::before{content:"";position:absolute;top:var(--ay);width:12px;height:12px;background:var(--bg);transform:translateY(-50%) rotate(45deg);box-shadow:-1px 1px 0 #0000001a;}
.hc2-pop.arrow-left::before{left:-6px;} .hc2-pop.arrow-right::before{right:-6px;box-shadow:1px -1px 0 #0000001a;}
.hc2-pop input[type=text],.hc2-pop input[type=date],.hc2-pop input[type=time],.hc2-pop textarea{border:none !important;background:transparent !important;box-shadow:none !important;padding:2px 0 !important;font-family:inherit;color:var(--txt);}
.hc2-pop input:focus,.hc2-pop textarea:focus{background:var(--hover) !important;border-radius:5px !important;outline:none !important;}
.hc2-pop .hc2-ptitle{width:100%;font-size:17px !important;height:28px !important;font-weight:600;margin-bottom:2px;}
.hc2-ptitle.ro{user-select:text;}
.hc2-pop .hc2-ploc{width:100%;font-size:13px !important;height:24px !important;color:var(--mut);}
.hc2-pop .hc2-pnotes{font-size:13px !important;}
.hc2-pop .hc2-prow{font-size:13px !important;}
.hc2-pop .hc2-ploc{margin-top:4px;}
.hc2-pop.wide .hc2-ploc{border:1px solid var(--line) !important;border-radius:6px !important;padding:4px 8px !important;margin-top:6px;}
.hc2-sep{height:1px;background:var(--line);margin:8px 0;}
.hc2-prow{display:flex;align-items:center;gap:8px;font-size:13px;margin:4px 0;}
.hc2-prow .lbl{width:52px;text-align:right;color:var(--mut);flex-shrink:0;}
.hc2-prow .val{display:flex;gap:2px;align-items:center;flex-wrap:nowrap;}
.hc2-dbtn{height:24px !important;padding:0 6px !important;border-radius:5px !important;background:transparent !important;color:var(--txt) !important;font-size:13px !important;font-variant-numeric:tabular-nums;font-weight:400 !important;}
.hc2-dbtn:hover,.hc2-dbtn.on{background:var(--hover) !important;}
.hc2-dbtn.on{color:#D9A3AD !important;}
.hc2-pop input.hc2-tin{width:52px !important;height:24px !important;font-size:13px !important;text-align:center;font-variant-numeric:tabular-nums;border-radius:5px !important;padding:0 !important;}
.hc2-pop input.hc2-tin:hover{background:var(--hover) !important;}
.hc2-picker{margin:4px 0 2px 60px;padding:6px;border-radius:8px;background:var(--hover);}
.hc2-pop input[type=checkbox]{width:14px;height:14px;margin:0;}
.hc2-pnotes{width:100%;font-size:13px !important;resize:none;min-height:38px;}
.hc2-pinfo{font-size:13px;white-space:pre-line;color:var(--txt);margin:2px 0;user-select:text;}
.hc2-pinfo.notes{color:var(--mut);margin-top:6px;}
.hc2-pcal{font-size:12px;color:var(--mut);margin-top:6px;display:flex;gap:6px;align-items:center;}
.hc2-pfoot{display:flex;align-items:center;gap:8px;margin-top:8px;}
.hc2-export{width:auto !important;padding:0 10px !important;font-size:11.5px !important;border-radius:14px !important;}
.hc2-apple{font-size:11.5px;color:var(--mut);flex:1;display:flex;align-items:center;gap:4px;}
.hc2-pbtn{margin-left:auto;height:26px !important;padding:0 14px !important;border-radius:7px !important;background:#FFF9FA !important;color:#B0707D !important;border:1px solid #F3DDE1 !important;font-size:13px !important;}
.hc2-plink{height:26px !important;padding:0 8px !important;background:transparent !important;color:#D9A3AD !important;font-size:13px !important;}
.hc2-pdel{margin-left:auto;height:26px !important;padding:0 8px !important;background:transparent !important;color:var(--red) !important;font-size:13px !important;}
.hc2{display:flex;align-items:stretch;gap:0;}
.hc2-main{flex:1;min-width:0;}
.hc2-tl{width:232px;flex-shrink:0;display:flex;flex-direction:column;border-right:1px solid var(--line);margin:-8px 6px -4px -4px;padding:14px 10px 10px 12px;background:var(--side);border-radius:12px 0 0 12px;}
.hc2-tl-hd{display:flex;align-items:baseline;justify-content:space-between;padding:2px 4px 10px;}
.hc2-tl-h{font-size:20px;font-weight:700;letter-spacing:-.3px;color:#D9A3AD;}
.hc2-tl-n{font-size:20px;font-weight:600;color:var(--mut);font-variant-numeric:tabular-nums;}
.hc2-tl-list{flex:1;overflow-y:auto;}
.hc2-tl-g{font-size:12px;font-weight:600;color:var(--mut);padding:12px 4px 4px;}
.hc2-tl-g:first-child{padding-top:2px;}
.hc2-tl-g.late{color:var(--red);} .hc2-tl-g.today{color:#D9A3AD;}
.hc2-tl-row{display:flex;gap:9px;padding:7px 6px;border-radius:8px;cursor:pointer;transition:background .12s,opacity .3s;}
.hc2-tl-row:hover{background:var(--hover);} .hc2-tl-row.sel{background:var(--sel);}
.hc2-tl-ck{flex:none;width:17px;height:17px;margin-top:1px;border-radius:50%;border:1.5px solid #C7C7CC;box-sizing:border-box;transition:all .15s;}
.hc2-tl-ck:hover{border-color:#D9A3AD;}
.hc2-tl-row.done{opacity:.4;} .hc2-tl-row.done .hc2-tl-ck{background:#D9A3AD;border-color:#D9A3AD;box-shadow:inset 0 0 0 2.5px var(--side);}
.hc2-tl-b{flex:1;min-width:0;border-bottom:.5px solid var(--line);padding-bottom:7px;margin-bottom:-7px;}
.hc2-tl-t{font-size:13.5px;line-height:1.35;color:var(--txt);word-break:break-word;}
.hc2-tl-m{display:flex;flex-wrap:wrap;gap:6px;font-size:11.5px;color:var(--mut);margin-top:2px;}
.hc2-tl-m .late{color:var(--red);}
.hc2-tl{overflow:hidden;box-sizing:border-box;} .hc2-tl>.hc2-tl-list{min-height:0;} .hc2-tl>.hc2-tl-list:not(.hc2-imp){flex:0 1 auto;}
.hc2-imp-hd{border-top:.5px solid var(--line);margin-top:10px;padding-top:14px;}
.hc2-imp{flex:0 1 auto;overflow-y:auto;} .hc2-tl>.hc2-tl-ft{margin-top:auto !important;flex:none;}
.hc2-imp-row{align-items:flex-start;}
.hc2-imp-dot{flex:none;width:8px;height:8px;border-radius:50%;margin:5px 4px 0 4px;background:#C7C7CC;}
.hc2-imp-dot.k-birthday{background:#D9A3AD;} .hc2-imp-dot.k-anniversary{background:#C9A0C8;} .hc2-imp-dot.k-deadline{background:#829EBE;} .hc2-imp-dot.k-holiday{background:#D7B26A;}
.hc2-imp-in{flex:none;font-size:11px;color:var(--mut);margin-top:2px;font-variant-numeric:tabular-nums;}
.hc2-imp-in.soon{color:#D9A3AD;font-weight:600;}
.hc2-tl-empty{font-size:13px;color:var(--mut);padding:20px 4px;text-align:center;}
.hc2-tl-ft{padding-top:8px;}
.hc2-tl-ft button{background:transparent !important;color:#D9A3AD !important;font-size:12.5px !important;padding:2px 4px !important;height:auto !important;}
@media (max-width:700px){.hc2{flex-direction:column;} .hc2-tl{width:auto;border-right:none;border-bottom:1px solid var(--line);margin:-8px -4px 8px;border-radius:12px 12px 0 0;max-height:260px;}}
@media (max-width:900px){.hc2-year{grid-template-columns:repeat(3,1fr);}}
@media (max-width:700px){.hc2-year{grid-template-columns:repeat(2,1fr);}
  .hc2-bar{grid-template-columns:auto 1fr;gap:6px;} .hc2-right{grid-column:1 / -1;} .hc2-search{width:100%;}
  .hc2-seg button{padding:0 9px !important;} .hc2-title{font-size:24px;}
  .hc2-item .tm{display:none;} .hc2-item{font-size:10.5px;padding:0 3px;}
  .hc2-num{font-size:12px;} .hc2-side{display:none;} .hc2-results{left:8px;right:8px;width:auto;}
}
`; }

render();
// fetch Apple calendars in the background; redraw if anything changed
(async () => {
    let changed = false;
    for (const f of config.feeds.filter(f => f.url && f.on !== false)) if (await fetchFeed(f)) changed = true;
    if (changed && root.isConnected && !S.pop) render();
})();
