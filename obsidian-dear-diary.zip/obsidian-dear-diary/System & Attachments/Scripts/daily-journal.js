// Daily journal box. Writes to 90 Journaling/YYYY-MM-DD.md, so every entry also lives in the journaling folder.
// keep the page from jumping to the top when Dataview re-renders this block after a save
{ const c = dv.container; const fix = () => { const sc = c.closest(".markdown-preview-view, .cm-scroller"); const top = sc ? sc.scrollTop : null; c.style.minHeight = ""; c.style.minHeight = c.offsetHeight + "px"; if (sc && top != null) sc.scrollTop = top; }; setTimeout(fix, 400); setTimeout(fix, 1500); }
// Type straight into it in Reading view; it saves as you go.
const JFOLDER = "90 Journaling";
const PROMPTS = [
    ["✨ One Moment Today", "A small thing worth remembering…"],
    ["🌗 What gave me energy today, and what drained it?", ""],
    ["🌱 What would I do differently tomorrow?", ""],
    ["🗒 Random Thoughts", ""]
];
const cur = dv.current();
const dayM = moment(cur.file.name, "YYYY-MM-DD", true);
const ds = (dayM.isValid() ? dayM : moment()).format("YYYY-MM-DD");
const path = `${JFOLDER}/${ds}.md`;
const DRAFT = (window._djDraft = window._djDraft || {});

const parse = text => {
    const out = {}; let key = null; const order = [];
    const body = text.replace(/^---\n[\s\S]*?\n---\n?/, "");
    for (const line of body.split("\n")) {
        const m = line.match(/^###\s+(.+?)\s*$/);
        if (m) { key = m[1]; out[key] = []; order.push(key); continue; }
        if (key) out[key].push(line);
    }
    for (const k of order) out[k] = out[k].join("\n").trim();
    return { out, order };
};
const build = (vals, extraOrder) => {
    const keys = [...PROMPTS.map(p => p[0]), ...extraOrder.filter(k => !PROMPTS.some(p => p[0] === k))];
    let s = `---\ntags:\n  - journal\ndate: ${ds}\n---\n[[01 Daily/${ds}|← ${moment(ds).format("ddd, MMM D")} daily page]]\n\n`;
    for (const k of keys) s += `### ${k}\n${(vals[k] || "").trim()}\n\n`;
    return s.trimEnd() + "\n";
};

let file = app.vault.getAbstractFileByPath(path);
const saved = file ? parse(await app.vault.read(file)) : { out: {}, order: [] };

const root = dv.container.createDiv({ cls: "dj" });
const head = root.createDiv({ cls: "dj-head" });
head.createSpan({ cls: "dj-title", text: "Journal" });
const link = head.createEl("a", { cls: "dj-link", text: "all entries ↗" });
link.onclick = e => { e.preventDefault(); app.workspace.openLinkText(`${JFOLDER}/Journal.md`, cur.file.path, false); };
const status = head.createSpan({ cls: "dj-status" });

let timer = null;
const save = async () => {
    clearTimeout(timer); timer = null;
    const vals = {};
    for (const [k] of PROMPTS) vals[k] = (DRAFT[path + k] ?? saved.out[k] ?? "");
    for (const k of saved.order) if (!(k in vals)) vals[k] = saved.out[k];
    const empty = Object.values(vals).every(v => !String(v).trim());
    file = app.vault.getAbstractFileByPath(path);
    if (!file && empty) return;
    const text = build(vals, saved.order);
    if (!file) {
        if (!app.vault.getAbstractFileByPath(JFOLDER)) await app.vault.createFolder(JFOLDER).catch(() => {});
        file = await app.vault.create(path, text);
    } else {
        await app.vault.modify(file, text);
    }
    for (const [k] of PROMPTS) saved.out[k] = vals[k];
    status.setText("saved");
};

for (const [k, ph] of PROMPTS) {
    const box = root.createDiv({ cls: "dj-q" });
    box.createDiv({ cls: "dj-label", text: k });
    const ta = box.createEl("textarea", { cls: "dj-ta", attr: { placeholder: ph || "…", rows: 2, "data-fid": "dj-" + k } });
    ta.value = DRAFT[path + k] ?? saved.out[k] ?? "";
    if (DRAFT[path + k] !== undefined && DRAFT[path + k] === (saved.out[k] ?? "")) delete DRAFT[path + k];
    const grow = () => { ta.style.height = "auto"; ta.style.height = Math.max(44, ta.scrollHeight + 2) + "px"; };
    setTimeout(grow, 0);
    ta.addEventListener("keydown", e => e.stopPropagation());
    ta.addEventListener("input", () => {
        DRAFT[path + k] = ta.value; grow(); status.setText("…");
        clearTimeout(timer); timer = setTimeout(save, 1500);
    });
    ta.addEventListener("blur", () => { if (timer) save(); });
}

// keep typing position if the page refreshes after a save
const FK = "_djFocus";
root.addEventListener("focusin", e => { const t = e.target; if (t.dataset && t.dataset.fid) window[FK] = { fid: t.dataset.fid, t: Date.now() }; });
root.addEventListener("input", e => { const t = e.target; if (window[FK] && t.dataset && t.dataset.fid === window[FK].fid) { window[FK].s = t.selectionStart; window[FK].t = Date.now(); } });
root.addEventListener("focusout", e => { const t = e.target; setTimeout(() => { if (t.isConnected && window[FK] && window[FK].fid === t.dataset.fid) window[FK] = null; }, 0); });
{
    const f = window[FK];
    if (f && Date.now() - f.t < 120000) {
        const el = root.querySelector(`[data-fid="${CSS.escape(f.fid)}"]`);
        if (el) { el.focus(); const n = f.s ?? el.value.length; try { el.setSelectionRange(n, n); } catch (e) {} }
    }
}
