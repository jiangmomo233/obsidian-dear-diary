// Home deadlines + countdowns. Source: "00 Home/Deadlines.md" (one per line: - YYYY-MM-DD [HH:mm] · what · #group [[link]])
// Also picks up any open task anywhere tagged #deadline with a 📅 date.
const SRC = "00 Home/Deadlines.md", SHOW = 7;
const PINK = "#B9838D", LINE = "#F7E6E9", BG = "#FFF9FA";
const F = "'Cormorant Garamond','EB Garamond',Garamond,'Songti SC',serif";
const GROUP = { travel: ["#F7D9DE", "#993556"], study: ["#F5E6E9", "#B9838D"], school: ["#E2EFE7", "#3F7A5C"], work: ["#F5E8D2", "#8A6420"], life: ["#ECE6F3", "#6A5390"] };
const items = [];
const file = app.vault.getAbstractFileByPath(SRC);
if (file) for (const l of (await app.vault.cachedRead(file)).split("\n")) {
    const m = l.match(/^\s*[-*]\s+(\d{4}-\d{2}-\d{2})(?:\s+(\d{1,2}:\d{2}))?\s*[·|—-]\s*(.+)$/);
    if (!m) continue;
    let rest = m[3];
    const g = (rest.match(/#([^\s#\[]+)/) || [])[1] || "";
    const link = (rest.match(/\[\[([^\]|]+)/) || [])[1] || "";
    const what = rest.replace(/#[^\s#\[]+/g, "").replace(/\[\[[^\]]*\]\]/g, "").replace(/[·|\s]+$/, "").trim();
    const at = moment(`${m[1]} ${m[2] || "23:59"}`, "YYYY-MM-DD HH:mm");
    items.push({ at, timed: !!m[2], what, g, link: link || SRC });
}
for (const t of dv.pages().file.tasks.where(t => !t.completed && (t.tags || []).includes("#deadline"))) {
    const d = (t.text.match(/📅\s*(\d{4}-\d{2}-\d{2})/) || [])[1]; if (!d) continue;
    items.push({ at: moment(d).endOf("day"), timed: false, what: t.text.replace(/📅\s*\S+|#\S+/g, "").trim(), g: "", link: t.path });
}
const now = moment(), today = now.clone().startOf("day");
const up = items.filter(i => i.at.isAfter(now)).sort((a, b) => a.at - b.at);
const daysTo = i => i.at.clone().startOf("day").diff(today, "days");

const card = dv.container.createDiv();
card.style.cssText = `background:${BG};border:1px solid ${LINE};border-radius:14px;padding:16px 20px;margin:6px 0`;
const head = card.createDiv(); head.style.cssText = "display:flex;justify-content:space-between;align-items:baseline;cursor:pointer";
head.onclick = () => app.workspace.openLinkText(SRC, "", false);
const ht = head.createDiv({ text: "deadlines" }); ht.style.cssText = `font-family:${F};font-variant:small-caps;letter-spacing:3px;color:${PINK};font-size:1.05em`;
head.createDiv({ text: "edit ›" }).style.cssText = "font-size:.72em;color:var(--text-faint)";
if (!up.length) { card.createDiv({ text: "Nothing coming up." }).style.cssText = "color:var(--text-faint);font-size:.9em;margin-top:8px"; return; }

// hero: the nearest one
const n = up[0], nd = daysTo(n);
const hero = card.createDiv(); hero.style.cssText = `display:flex;align-items:baseline;gap:12px;margin:8px 0 12px;padding-bottom:12px;border-bottom:1px solid ${LINE};cursor:pointer`;
hero.onclick = () => app.workspace.openLinkText(n.link, "", false);
let big = nd > 0 ? String(nd) : String(Math.max(1, Math.ceil(n.at.diff(now, "hours", true))));
const bn = hero.createDiv({ text: big }); bn.style.cssText = `font-family:${F};font-size:2.6em;line-height:1;color:var(--text-normal)`;
const hb = hero.createDiv();
hb.createDiv({ text: nd > 0 ? (nd === 1 ? "day left" : "days left") : "hours left" }).style.cssText = "font-size:.75em;color:var(--text-muted)";
hb.createDiv({ text: n.what }).style.cssText = "font-size:.95em;color:var(--text-normal)";
hb.createDiv({ text: n.at.format(n.timed ? "ddd, MMM D · HH:mm" : "ddd, MMM D, YYYY") }).style.cssText = "font-size:.72em;color:var(--text-faint)";

for (const i of up.slice(1, SHOW)) {
    const r = card.createDiv(); r.style.cssText = "display:flex;align-items:center;gap:10px;padding:4px 0;font-size:.88em;cursor:pointer";
    r.onclick = () => app.workspace.openLinkText(i.link, "", false);
    const d = daysTo(i), [bg, fg] = GROUP[i.g] || ["#F3EEEF", "var(--text-muted)"];
    const p = r.createSpan({ text: d === 0 ? "today" : `${d}d` });
    p.style.cssText = `min-width:46px;text-align:center;border-radius:999px;padding:1px 8px;font-size:.85em;background:${bg};color:${fg}`;
    r.createSpan({ text: i.what }).style.cssText = "flex:1;color:var(--text-normal);overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
    r.createSpan({ text: i.at.format("MMM D") }).style.cssText = "color:var(--text-faint);font-size:.9em";
}
if (up.length > SHOW) { const m = card.createDiv({ text: `+${up.length - SHOW} more` }); m.style.cssText = "font-size:.75em;color:var(--text-faint);margin-top:6px;cursor:pointer"; m.onclick = () => app.workspace.openLinkText(SRC, "", false); }
