// Daily note ↔ 媒体库 progress logger
// keep the page from jumping to the top when Dataview re-renders this block after a save
{ const c = dv.container; const fix = () => { const sc = c.closest(".markdown-preview-view, .cm-scroller"); const top = sc ? sc.scrollTop : null; c.style.minHeight = ""; c.style.minHeight = c.offsetHeight + "px"; if (sc && top != null) sc.scrollTop = top; }; setTimeout(fix, 400); setTimeout(fix, 1500); }
// Logging "+20" here adds to the work's progress field in 80 Library, updates last_activity_at,
// and starts the work (status 进行中, started_at) if it hadn't started. Finishing is left to the
// work's own page so the library can write its history record.
const LIB = "80 Library/媒体库/作品";
const cur = dv.current();
const dailyFile = app.vault.getAbstractFileByPath(cur.file.path);
const dayM = moment(cur.file.name, "YYYY-MM-DD", true);
const isDaily = dayM.isValid();
const ds = (isDaily ? dayM : moment()).format("YYYY-MM-DD");

const CONF = {
    book:   { field: "current_page",     total: "page_count",      label: "pages" },
    series: { field: "current_episode",  total: "episode_count",   label: "eps" },
    movie:  { field: "current_minutes",  total: "runtime_minutes", label: "min" },
    game:   { field: "progress_percent", total: null, fixed: 100,  label: "%" },
    music:  { field: "progress_percent", total: null, fixed: 100,  label: "%" }
};
const ICON = { book: "📖", movie: "🎬", tv: "📺", anime: "🌸", game: "🎮", documentary: "🎞", variety: "🎤", music: "🎵", short_drama: "📱" };
const fmtFor = p => {
    const f = String(p.media_format || "");
    if (CONF[f]) return f;
    const t = String(p.media_type || "");
    if (["book", "movie", "game", "music"].includes(t)) return t;
    if (["tv", "anime", "short_drama"].includes(t)) return "series";
    if (Number(p.episode_count || 0) > 0 || Number(p.current_episode || 0) > 0) return "series";
    if (Number(p.runtime_minutes || 0) > 0 || Number(p.current_minutes || 0) > 0) return "movie";
    return t === "documentary" ? "movie" : "series";
};
const num = v => { const n = parseFloat(String(v ?? "").replace(/[^\d.]/g, "")); return isNaN(n) ? null : n; };
const dstr = v => !v ? "" : (v.toFormat ? v.toFormat("yyyy-MM-dd") : String(v).slice(0, 10));
const notice = m => { const N = window.__mediaLibraryObsidian?.Notice || (typeof Notice !== "undefined" ? Notice : null); N ? new N(m) : console.log(m); };
const refresh = () => setTimeout(() => app.workspace.trigger("dataview:refresh-views"), 150);
const openPath = path => app.workspace.openLinkText(path, cur.file.path, false);
const fileOf = path => app.vault.getAbstractFileByPath(path);

const works = dv.pages(`"${LIB}"`).where(p => p.note_type === "media");
const log = Array.isArray(cur.media_log) ? cur.media_log : [];
const articles = Array.isArray(cur.articles) ? cur.articles : [];
const logged = new Set(log.map(e => e.path));
const active = works.where(p => p.status === "进行中" || logged.has(p.file.path))
    .sort(p => dstr(p.last_activity_at) || "0", "desc");

// ── writes ──
async function logProgress(p, amount) {
    const c = CONF[fmtFor(p)];
    let from = 0, to = 0, blocked = false;
    await app.fileManager.processFrontMatter(fileOf(p.file.path), fm => {
        if (fm.status === "已完成" || fm.status === "弃置") { blocked = true; return; }
        from = num(fm[c.field]) ?? 0;
        const total = c.fixed ?? num(fm[c.total]);
        to = Math.max(0, from + amount);
        if (total) to = Math.min(to, total);
        fm[c.field] = to;
        if (!dstr(fm.last_activity_at) || dstr(fm.last_activity_at) < ds) fm.last_activity_at = ds;
        if (fm.status !== "进行中") fm.status = "进行中";
        if (!fm.started_at) fm.started_at = ds;
    });
    if (blocked) return notice("This one is marked finished — open its page to reopen it");
    if (isDaily) {
        await app.fileManager.processFrontMatter(dailyFile, fm => {
            const arr = Array.isArray(fm.media_log) ? fm.media_log : [];
            const e = arr.find(x => x.path === p.file.path);
            if (e) e.to = to;
            else arr.push({ path: p.file.path, title: String(p.title || p.file.name), field: c.field, unit: c.label, from, to });
            fm.media_log = arr;
        });
    }
    refresh();
}
async function undo(entry) {
    const f = fileOf(entry.path);
    if (f) await app.fileManager.processFrontMatter(f, fm => {
        if (num(fm[entry.field]) === Number(entry.to)) fm[entry.field] = Number(entry.from);
    });
    await app.fileManager.processFrontMatter(dailyFile, fm => {
        fm.media_log = (fm.media_log || []).filter(x => x.path !== entry.path);
    });
    refresh();
}
async function setTotal(p, n) {
    const c = CONF[fmtFor(p)];
    await app.fileManager.processFrontMatter(fileOf(p.file.path), fm => { fm[c.total] = n; });
    refresh();
}
async function start(p) {
    await app.fileManager.processFrontMatter(fileOf(p.file.path), fm => {
        fm.status = "进行中";
        if (!fm.started_at) fm.started_at = ds;
        if (!dstr(fm.last_activity_at) || dstr(fm.last_activity_at) < ds) fm.last_activity_at = ds;
    });
    refresh();
}
async function setArticles(list) {
    await app.fileManager.processFrontMatter(dailyFile, fm => { fm.articles = list; });
    refresh();
}

// ── render ── two columns: Books | 影视剧 (movies + series together)
const isBook = p => fmtFor(p) === "book";
const root = dv.container.createDiv({ cls: "dm-card" });
const head = root.createDiv({ cls: "dm-head" });
head.createSpan({ cls: "dm-title", text: "Media" });
const cols = root.createDiv({ cls: "dm-cols" });
const pool = works.where(p => !["进行中", "已完成", "弃置"].includes(p.status) && !logged.has(p.file.path))
    .sort(p => String(p.title || p.file.name));

const coverSrc = p => {
    const raw = p.cover?.path ?? String(p.cover || "");
    const link = raw.replace(/^!?\[\[/, "").replace(/\]\]$/, "").split("|")[0].trim();
    if (!link) return null;
    if (/^https?:/.test(link)) return link;
    const f = app.metadataCache.getFirstLinkpathDest(link, p.file.path) || app.vault.getAbstractFileByPath(link);
    return f ? app.vault.getResourcePath(f) : null;
};
const VERB = { book: ["Now at page", "Save"], series: ["Now at episode", "Save"], movie: ["Now at minute", "Save"] };
const renderRow = (list, p) => {
    const fmt = fmtFor(p), c = CONF[fmt];
    const val = num(p[c.field]) ?? 0;
    const total = c.fixed ?? num(p[c.total]);
    const row = list.createDiv({ cls: "dm-item" });
    const cov = row.createDiv({ cls: "dm-cover" });
    const src = coverSrc(p);
    if (src) cov.createEl("img", { attr: { src, loading: "lazy", alt: "" } });
    else cov.createDiv({ cls: "dm-cover-ph", text: String(p.title || p.file.name).slice(0, 1) });
    cov.onclick = () => openPath(p.file.path);
    const body = row.createDiv({ cls: "dm-body" });

    const a = body.createEl("a", { cls: "internal-link dm-name", text: String(p.title || p.file.name) });
    a.setAttr("data-href", p.file.path);
    const meta = body.createDiv({ cls: "dm-meta" });
    if (c.fixed) meta.setText(`${val}%`);
    else {
        meta.createSpan({ cls: "dm-cur", text: String(val) });
        meta.appendText(" / ");
        // total is always editable (e.g. a phone edition with a different page count) — saved to the library
        const t = meta.createEl("input", { cls: "dm-total", attr: { type: "number", min: "1", placeholder: "?", title: `Total ${c.label} — click to change` } });
        t.value = total ?? "";
        const saveTotal = () => { const n = num(t.value); if (n && n !== total) setTotal(p, n); };
        t.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") t.blur(); });
        t.addEventListener("change", saveTotal);
        meta.appendText(" " + c.label);
        if (total) meta.createSpan({ cls: "dm-pct", text: `${Math.min(100, Math.round(val / total * 100))}%` });
    }
    const bar = body.createDiv({ cls: "dm-bar" });
    bar.createDiv({ cls: "dm-fill" }).style.width = (total ? Math.min(100, Math.round(val / total * 100)) : 0) + "%";

    const ctl = body.createDiv({ cls: "dm-ctl" });
    if (p.status === "已完成" || p.status === "弃置") {
        ctl.createSpan({ cls: "dm-tag", text: p.status === "已完成" ? "finished ✓" : p.status });
    } else if (total && val >= total) {
        const done = ctl.createEl("a", { cls: "internal-link dm-tag dm-end", text: "Reached the end — mark finished →" });
        done.setAttr("data-href", p.file.path);
    } else {
        // enter where you are now (e.g. page 160), not how many you read
        const [verb, btnText] = VERB[fmt] || ["Now at", "Save"];
        ctl.createSpan({ cls: "dm-verb", text: verb });
        const inp = ctl.createEl("input", { cls: "dm-in", attr: { type: "number", min: "0", placeholder: String(val || "") } });
        const btn = ctl.createEl("button", { cls: "dm-btn", text: btnText });
        const go = () => { const n = num(inp.value); if (n === null) return; const delta = n - val; if (delta) logProgress(p, delta); };
        inp.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") go(); });
        btn.addEventListener("click", go);
    }
    const lg = log.find(e => e.path === p.file.path);
    if (lg) {
        const diff = Number(lg.to) - Number(lg.from);
        const r = body.createDiv({ cls: "dm-today" });
        r.createSpan({ text: `Today ${lg.from} → ${lg.to}  (${diff >= 0 ? "+" : ""}${diff} ${lg.unit})` });
        r.createEl("button", { cls: "dm-x", text: "undo" }).addEventListener("click", () => undo(lg));
    }
};

for (const [title, test, empty, pick] of [
    ["Books", isBook, "No book in progress.", "+ Start a book…"],
    ["Film & TV", p => !isBook(p), "Nothing on screen right now.", "+ Start a film or show…"]
]) {
    const col = cols.createDiv({ cls: "dm-col" });
    const ch = col.createDiv({ cls: "dm-colhead" });
    ch.createSpan({ cls: "dm-sub", text: title });
    const mine = active.where(test);
    ch.createSpan({ cls: "dm-n", text: mine.length ? String(mine.length) : "" });
    const list = col.createDiv({ cls: "dm-list" });
    if (!mine.length) list.createDiv({ cls: "dm-hint", text: empty });
    for (const p of mine) renderRow(list, p);
    const pp = pool.where(test);
    if (pp.length) {
        const sel = col.createEl("select", { cls: "dm-select dropdown" });
        sel.createEl("option", { text: pick, value: "" });
        for (const p of pp) sel.createEl("option", { text: `${p.title || p.file.name}${p.status === "暂停" ? " (paused)" : ""}`, value: p.file.path });
        sel.addEventListener("change", () => { const p = pp.find(x => x.file.path === sel.value); if (p) start(p); });
    }
    if (title === "Books") {
        // articles live with reading
        const art = col.createDiv({ cls: "dm-art" });
        art.createDiv({ cls: "dm-sub", text: "Articles" });
        articles.forEach((t, i) => {
            const r = art.createDiv({ cls: "dm-logrow" });
            const s = String(t);
            const m = s.match(/^(.*?)\s*(https?:\/\/\S+)$/);
            if (m) { const l = r.createEl("a", { text: m[1] || m[2], href: m[2] }); l.addClass("external-link"); }
            else r.createSpan({ text: s });
            r.createEl("button", { cls: "dm-x", text: "×" }).addEventListener("click", () => setArticles(articles.filter((_, j) => j !== i)));
        });
        if (isDaily) {
            const ai = art.createEl("input", { cls: "dm-in dm-wide", attr: { type: "text", placeholder: "+ Article title (and link), Enter" } });
            ai.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter" && ai.value.trim()) setArticles([...articles.map(String), ai.value.trim()]); });
        }
    }
}
const elsewhere = works.where(p => dstr(p.last_activity_at) === ds && !logged.has(p.file.path) && p.status !== "进行中");
if (elsewhere.length) root.createDiv({ cls: "dm-hint", text: "Also updated in the library today: " + elsewhere.map(p => p.title || p.file.name).join(", ") });
