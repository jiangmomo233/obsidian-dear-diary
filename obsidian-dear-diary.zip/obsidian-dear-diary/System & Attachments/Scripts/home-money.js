// Home money snapshot — 净资产 / 还款日提醒 / 今日收支.
// Reads the same notes as the money app (50 Money/Personal). Click the card title to open the ledger.
const ROOT = "50 Money/Personal";
const ACC = `${ROOT}/Accounts`, TXF = `${ROOT}/Transactions`, SET = `${ROOT}/记账设置.md`, LEDGER = `${ROOT}/Personal Expense.md`;
const PINK = "#B9838D", LINE = "#F7E6E9", BG = "#FFF9FA";
const F = "'Cormorant Garamond','EB Garamond',Garamond,'Songti SC',serif";
const num = v => { const n = parseFloat(v); return isFinite(n) ? n : 0; };
const set = (dv.page(SET) || {}).file ? dv.page(SET).file.frontmatter : {};
const RATE = num(set.usd_cny) || 6.69;
const toCNY = (v, cur, r) => cur === "USD" ? v * (r || RATE) : v;
const yuan = v => "¥" + Math.abs(v).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pd = v => { if (!v) return null; if (v.toISO) return moment(v.toISO()); const m = moment(String(v)); return m.isValid() ? m : null; };

const accts = dv.pages(`"${ACC}"`).array().map(p => ({ name: p.file.name, path: p.file.path, ...p.file.frontmatter }))
    .filter(a => !a.hidden && !a.archived);
const TX = dv.pages(`"${TXF}"`).array().map(p => {
    const f = p.file.frontmatter || {}; const m = pd(f.date);
    return f.type && m ? { ...f, type: String(f.type), m, ts: m.valueOf(), amount: num(f.amount), fee: num(f.fee), rate: num(f.rate) || null,
        to_amount: f.to_amount === undefined || f.to_amount === null || f.to_amount === "" ? null : num(f.to_amount), currency: f.currency || "CNY" } : null;
}).filter(Boolean);

// balance = anchor balance at balance_date + every movement after it (same rule as the money app)
const delta = (t, n) => {
    let d = 0;
    if (t.type === "支出" && t.account === n) d -= t.amount;
    if ((t.type === "收入" || t.type === "退款") && t.account === n) d += t.amount;
    if (t.type === "转账") { if (t.account === n) d -= t.amount + t.fee; if (t.to_account === n) d += t.to_amount ?? t.amount; }
    return d;
};
const balOf = a => {
    if (a.balance === undefined || a.balance === null || a.balance === "" || !a.balance_date) return null;
    const bd = String(a.balance_date.toISO ? a.balance_date.toISO() : a.balance_date);
    const anchor = (bd.length <= 10 ? moment(bd).endOf("day") : moment(bd)).valueOf();
    let b = num(a.balance); for (const t of TX) if (t.ts > anchor) b += delta(t, a.name);
    return b;
};
let assets = 0, debt = 0;
for (const a of accts) { const b = balOf(a); if (b === null) continue; a.cur = b; const c = toCNY(b, a.currency); if (c >= 0) assets += c; else debt += -c; }
const net = assets - debt;

// today
const biz = t => t.type !== "转账" && (t.category === "生意成本" || t.category === "生意回款");
const spend = t => t.exclude || biz(t) ? 0 : t.type === "支出" ? (t.reimburse === "已报销" ? 0 : toCNY(t.amount, t.currency, t.rate)) : t.type === "退款" ? -toCNY(t.amount, t.currency, t.rate) : t.type === "转账" && t.fee ? toCNY(t.fee, t.currency, t.rate) : 0;
const income = t => t.type === "收入" && !t.exclude && !biz(t) ? toCNY(t.amount, t.currency, t.rate) : 0;
const today = moment().startOf("day"), tm = today.valueOf(), tmr = today.clone().add(1, "day").valueOf(), mStart = today.clone().startOf("month").valueOf();
let tExp = 0, tInc = 0, nToday = 0, mExp = 0;
for (const t of TX) {
    if (t.ts >= tm && t.ts < tmr) { tExp += spend(t); tInc += income(t); if (t.type !== "转账") nToday++; }
    if (t.ts >= mStart && t.ts < tmr) mExp += spend(t);
}

// repayment reminders — credit accounts with a due_day (or only a statement_day)
const nextDay = day => { let d = today.clone().date(Math.min(day, today.daysInMonth())); if (d.isBefore(today)) { d = today.clone().add(1, "month").startOf("month"); d.date(Math.min(day, d.daysInMonth())); } return d; };
const dues = accts.filter(a => a.kind === "信用" && (a.due_day || a.statement_day)).map(a => {
    const isDue = !!a.due_day, d = nextDay(num(a.due_day || a.statement_day));
    return { a, isDue, d, days: d.diff(today, "days"), owe: a.cur && a.cur < 0 ? -a.cur : 0 };
}).sort((x, y) => x.days - y.days);

// ── render
const card = dv.container.createDiv();
card.style.cssText = `background:${BG};border:1px solid ${LINE};border-radius:14px;padding:16px 20px;margin:6px 0`;
const head = card.createDiv(); head.style.cssText = `display:flex;justify-content:space-between;align-items:baseline;cursor:pointer`;
head.onclick = () => app.workspace.openLinkText(LEDGER, "", false);
const ht = head.createDiv({ text: "money" }); ht.style.cssText = `font-family:${F};font-variant:small-caps;letter-spacing:3px;color:${PINK};font-size:1.05em`;
const hr = head.createDiv({ text: `$1 = ¥${RATE}` }); hr.style.cssText = `font-size:.72em;color:var(--text-faint)`;

const nw = card.createDiv(); nw.style.cssText = "margin:8px 0 2px";
const nlr = nw.createDiv(); nlr.style.cssText = "display:flex;align-items:baseline;gap:10px";
const nl = nlr.createDiv({ text: "净资产" }); nl.style.cssText = "font-size:.75em;color:var(--text-muted)";
const tog = nlr.createEl("span", { attr: { role: "button" } }); tog.style.cssText = `font-family:${F};font-style:italic;font-size:.82em;color:${PINK};cursor:pointer;border-bottom:1px solid transparent;line-height:1.2`;
tog.addEventListener("mouseenter", () => tog.style.borderBottomColor = PINK);
tog.addEventListener("mouseleave", () => tog.style.borderBottomColor = "transparent");
const nv = nw.createDiv(); nv.style.cssText = `font-family:${F};font-size:2.1em;line-height:1.15;color:var(--text-normal)`;
const ns = nw.createDiv(); ns.style.cssText = "font-size:.75em;color:var(--text-faint);min-height:1.4em";
// hidden by default; once shown it stays visible for 2 minutes, then hides again
const paintNW = () => {
    const show = window._mnyShowUntil && Date.now() < window._mnyShowUntil;
    nv.empty(); ns.empty();
    if (show) { nv.setText((net < 0 ? "−" : "") + yuan(net)); ns.setText(`资产 ${yuan(assets)} · 负债 ${yuan(debt)}`); }
    else { const d = nv.createSpan({ text: "—" }); d.style.cssText = "color:var(--text-faint)"; }
    tog.setText(show ? "hide" : "show");
};
tog.addEventListener("click", e => {
    e.stopPropagation();
    const show = window._mnyShowUntil && Date.now() < window._mnyShowUntil;
    window._mnyShowUntil = show ? 0 : Date.now() + 120000;
    paintNW();
    clearTimeout(window._mnyHideT);
    if (!show) window._mnyHideT = setTimeout(() => { window._mnyShowUntil = 0; if (tog.isConnected) paintNW(); }, 120000);
});
paintNW();

const row = card.createDiv(); row.style.cssText = `display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0;padding:10px 0;border-top:1px solid ${LINE};border-bottom:1px solid ${LINE}`;
const stat = (lab, val, col, sub) => { const c = row.createDiv(); const l = c.createDiv({ text: lab }); l.style.cssText = "font-size:.75em;color:var(--text-muted)"; const v = c.createDiv({ text: val }); v.style.cssText = `font-size:1.25em;color:${col}`; if (sub) { const s = c.createDiv({ text: sub }); s.style.cssText = "font-size:.7em;color:var(--text-faint)"; } };
stat("今日支出", "−" + yuan(tExp), "#C2727F", `本月 ${yuan(mExp)}`);
stat("今日收入", "+" + yuan(tInc), "#6E9C86", nToday ? `${nToday} 笔记录` : "今天还没记账");

const dl = card.createDiv({ text: "还款日" }); dl.style.cssText = "font-size:.75em;color:var(--text-muted);margin-bottom:4px";
if (!dues.length) card.createDiv({ text: "没有设置还款日的信用账户" }).style.cssText = "font-size:.85em;color:var(--text-faint)";
for (const x of dues) {
    const r = card.createDiv(); r.style.cssText = "display:flex;align-items:center;gap:10px;padding:4px 0;font-size:.88em;cursor:pointer";
    r.onclick = () => app.workspace.openLinkText(x.a.path, "", false);
    const urgent = x.isDue && x.days <= 3;
    const pill = r.createSpan({ text: x.days === 0 ? "今天" : `${x.days}天` });
    pill.style.cssText = `min-width:42px;text-align:center;border-radius:999px;padding:1px 8px;font-size:.85em;${urgent ? "background:#F7D9DE;color:#993556" : "background:#F3EEEF;color:var(--text-muted)"}`;
    const nm = r.createSpan({ text: x.a.name }); nm.style.cssText = "flex:1;color:var(--text-normal)";
    const info = r.createSpan({ text: `${x.isDue ? "还款" : "账单日"} ${x.d.format("M/D")}${x.owe ? " · " + (x.a.currency === "USD" ? "$" + x.owe.toFixed(2) : yuan(x.owe)) : ""}` });
    info.style.cssText = "color:var(--text-faint);font-size:.9em";
}
