// Daily habits widget: two-column list with the same descriptions as Home (read from home-habits.js INFO).
// keep the page from jumping to the top when Dataview re-renders this block after a save
{ const c = dv.container; const fix = () => { const sc = c.closest(".markdown-preview-view, .cm-scroller"); const top = sc ? sc.scrollTop : null; c.style.minHeight = ""; c.style.minHeight = c.offsetHeight + "px"; if (sc && top != null) sc.scrollTop = top; }; setTimeout(fix, 400); setTimeout(fix, 1500); }
// The real task lines stay in the note (hidden callouts), so Home's tracker keeps counting them.
const cur = dv.current();
const file = app.vault.getAbstractFileByPath(cur.file.path);
const dayM = moment(cur.file.name, "YYYY-MM-DD", true);
const d = dayM.isValid() ? dayM : moment();
let INFO = {};
try {
    const src = await app.vault.adapter.read("System & Attachments/Scripts/home-habits.js");
    const m = src.match(/const INFO = (\{[\s\S]*?\n\});/);
    if (m) INFO = new Function("return " + m[1])();
} catch (e) {}

const text = await app.vault.read(file);
const items = [];
for (const line of text.split("\n")) {
    const m = line.match(/^[>\s]*[-*+] \[(.)\] (.*?)#habit\/([^\s\/#]+)/);
    if (!m) continue;
    const k = m[3];
    const info = INFO[k] || [];
    items.push({ k, done: m[1] !== " ", label: m[2].trim(), desc: info[0] || "", per: info[1] || "day", target: info[2] || 1 });
}
if (!items.length) return;

// this week's / month's count for non-daily habits
const counts = {};
for (const p of dv.pages(`"01 Daily"`)) {
    const pm = moment(p.file.name, "YYYY-MM-DD", true); if (!pm.isValid()) continue;
    for (const t of p.file.tasks) if (t.completed) for (const tag of (t.tags || [])) {
        const mm = tag.match(/^#habit\/([^\/\s#]+)/); if (!mm) continue;
        const it = items.find(x => x.k === mm[1]); if (!it || it.per === "day") continue;
        if (pm.isSame(d, it.per === "week" ? "isoWeek" : "month")) counts[it.k] = (counts[it.k] || 0) + 1;
    }
}

const toggle = async (it, row) => {
    it.done = !it.done; row.toggleClass("is-done", it.done);
    await app.vault.process(file, t => t.split("\n").map(l =>
        new RegExp(`#habit\\/${it.k}(?![\\w-])`).test(l) ? l.replace(/\[(.)\]/, it.done ? "[x]" : "[ ]") : l).join("\n"));
};

const root = dv.container.createDiv({ cls: "dh" });
const groups = [["Daily habits", items.filter(i => i.per === "day")], ["Weekly & monthly", items.filter(i => i.per !== "day")]];
for (const [title, list] of groups) {
    if (!list.length) continue;
    const card = root.createDiv({ cls: "dh-card" });
    const h = card.createDiv({ cls: "dh-head" });
    h.createSpan({ cls: "dh-title", text: title });
    h.createSpan({ cls: "dh-count", text: `${list.filter(i => i.done).length} / ${list.length}` });
    const g = card.createDiv({ cls: "dh-grid" });
    for (const it of list) {
        const r = g.createDiv({ cls: "dh-row" + (it.done ? " is-done" : "") });
        r.createDiv({ cls: "dh-check" });
        const b = r.createDiv({ cls: "dh-body" });
        b.createDiv({ cls: "dh-name", text: it.label });
        if (it.desc) b.createDiv({ cls: "dh-desc", text: it.desc });
        if (it.per !== "day") {
            const n = (counts[it.k] || 0);
            r.createDiv({ cls: "dh-goal" + (n >= it.target ? " ok" : ""), text: `${n}/${it.target} ${it.per === "week" ? "this week" : "this month"}` });
        }
        r.onclick = () => toggle(it, r);
    }
}
