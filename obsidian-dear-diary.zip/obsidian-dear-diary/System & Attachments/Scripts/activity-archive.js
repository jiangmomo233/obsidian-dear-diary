// Activity Log archive: every activities: entry from 01 Daily, newest day first, grouped by month.
const FOLDER = "01 Daily";
const arr = v => (Array.isArray(v) ? v : (v ? [v] : [])).filter(x => x && typeof x === "object" && x.text);
const days = dv.pages(`"${FOLDER}"`)
    .where(p => moment(p.file.name, "YYYY-MM-DD", true).isValid() && arr(p.activities).length)
    .sort(p => p.file.name, "desc").array()
    .map(p => ({ name: p.file.name, path: p.file.path, m: moment(p.file.name, "YYYY-MM-DD"),
        acts: arr(p.activities).map(a => ({ time: String(a.time || ""), text: String(a.text), tag: a.tag ? String(a.tag) : null }))
            .sort((a, b) => a.time.localeCompare(b.time)) }));

const root = dv.container.createDiv({ cls: "da ala" });
const total = days.reduce((n, d) => n + d.acts.length, 0);
const head = root.createDiv({ cls: "dn-header" });
const hl = head.createDiv();
hl.createDiv({ cls: "dn-weekday", text: "Archive" });
hl.createDiv({ cls: "dn-date", text: "Activity Log" });
hl.createDiv({ cls: "dn-meta", text: total ? `${total} entries · ${days.length} days · since ${days[days.length - 1].m.format("MMM D, YYYY")}` : "No entries yet" });
const hr = head.createDiv({ cls: "dn-right" });
const home = hr.createEl("a", { cls: "dn-nav", text: "Home" });
home.onclick = e => { e.preventDefault(); app.workspace.openLinkText("00 Home/Home.md", "", false); };

if (!total) { root.createDiv({ cls: "da-card al-empty", text: "Add things in the Activity log on any daily page and they'll collect here." }); return; }

// filters
const st = (window._alaState = window._alaState || { q: "", tag: null });
const bar = root.createDiv({ cls: "da-card ala-bar" });
const q = bar.createEl("input", { cls: "da-in", attr: { type: "search", placeholder: "Search everything you've logged…" } });
q.value = st.q;
q.addEventListener("keydown", e => e.stopPropagation());
const tags = [...new Set(days.flatMap(d => d.acts.map(a => a.tag).filter(Boolean)))].sort();
const tg = bar.createDiv({ cls: "al-tags" });
const tagBtns = tags.map(t => {
    const b = tg.createEl("button", { cls: "da-chip al-tag" + (st.tag === t ? " on" : ""), text: t });
    b.onclick = () => { st.tag = st.tag === t ? null : t; tagBtns.forEach(x => x.toggleClass("on", x.textContent === st.tag)); draw(); };
    return b;
});
const info = bar.createDiv({ cls: "al-count ala-info" });

const list = root.createDiv();
const draw = () => {
    list.empty();
    const s = st.q.trim().toLowerCase();
    let shown = 0, month = null;
    for (const d of days) {
        const acts = d.acts.filter(a => (!st.tag || a.tag === st.tag) && (!s || a.text.toLowerCase().includes(s) || (a.tag || "").includes(s)));
        if (!acts.length) continue;
        shown += acts.length;
        const mk = d.m.format("YYYY-MM");
        if (mk !== month) { month = mk; list.createDiv({ cls: "ala-month", text: d.m.format("MMMM YYYY") }); }
        const c = list.createDiv({ cls: "da-card ala-day" });
        const h = c.createDiv({ cls: "al-head" });
        const a = h.createEl("a", { cls: "da-title ala-date", text: d.m.format("ddd, MMM D") });
        a.onclick = e => { e.preventDefault(); app.workspace.openLinkText(d.path, "", false); };
        h.createSpan({ cls: "al-count", text: `${acts.length} ${acts.length === 1 ? "entry" : "entries"}` });
        const l = c.createDiv({ cls: "al-list" });
        for (const x of acts) {
            const r = l.createDiv({ cls: "al-item" });
            r.createSpan({ cls: "al-t", text: x.time });
            r.createSpan({ cls: "al-rail" });
            r.createSpan({ cls: "al-txt", text: x.text });
            if (x.tag) r.createSpan({ cls: "al-tagl", text: x.tag }); else r.createSpan();
        }
    }
    info.setText(s || st.tag ? `${shown} matching ${shown === 1 ? "entry" : "entries"}` : "");
    if (!shown) list.createDiv({ cls: "al-empty", text: "Nothing matches." });
};
let t = null;
q.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { st.q = q.value; draw(); }, 150); });
draw();
