// Home nav bar — editorial serif links; hover a folder to see its subfolders and latest notes.
// Built from the top-level folders automatically, so new folders show up on their own.
// No hover popup on covers: stop Obsidian's page preview for any link that shows a cover/poster.
if (!window.__mediaNoCoverHover) {
    window.__mediaNoCoverHover = true;
    document.addEventListener("mouseover", e => {
        const el = e.target?.closest?.("a.internal-link, [data-href]");
        if (el && (el.querySelector("img") || /cover|poster|card/i.test(el.className || ""))) e.stopPropagation();
    }, true);
}

const SKIP = ["00 Home", "02 Inbox", "System & Attachments", "docs"];
const PINK = "#B9838D", LINE = "#F7E6E9", TINT = "#FBEAF0";
const F = "'Cormorant Garamond','EB Garamond',Garamond,'Songti SC',serif";
const root = app.vault.getRoot();
const label = n => n.replace(/^\d+\s*/, "");
const isNote = f => f.extension === "md";
const recent = (folder, n) => {
    const out = [];
    const walk = f => { for (const c of f.children || []) { if (c.children) { if (!c.name.startsWith(".")) walk(c); } else if (isNote(c)) out.push(c); } };
    walk(folder);
    return out.sort((a, b) => b.stat.mtime - a.stat.mtime).slice(0, n);
};
const openToday = async () => {
    const path = `01 Daily/${moment().format("YYYY-MM-DD")}.md`;
    let f = app.vault.getAbstractFileByPath(path);
    if (!f) { const tp = app.vault.getAbstractFileByPath("System & Attachments/Templates/Dear Diary.md"); f = await app.vault.create(path, tp ? await app.vault.read(tp) : ""); }
    app.workspace.getLeaf(false).openFile(f);
};
const openFolder = folder => {
    if (folder.path === "01 Daily") return openToday();
    if (folder.path === "50 Money") { const pe = app.vault.getAbstractFileByPath("50 Money/Personal/Personal Expense.md"); if (pe) return app.workspace.getLeaf(false).openFile(pe); }
    if (folder.path === "80 Library") { const home = app.vault.getAbstractFileByPath("80 Library/媒体库/首页.md"); if (home) return app.workspace.getLeaf(false).openFile(home); }
    // a folder note (Folder/Folder.md) opens; otherwise reveal the folder in the sidebar
    const fn = app.vault.getAbstractFileByPath(`${folder.path}/${folder.name}.md`);
    if (fn) return app.workspace.getLeaf(false).openFile(fn);
    const fe = app.internalPlugins.getPluginById("file-explorer");
    if (fe && fe.instance && fe.instance.revealInFolder) fe.instance.revealInFolder(folder);
};

if (!document.getElementById("home-nav-style")) {
    const st = document.createElement("style"); st.id = "home-nav-style";
    st.textContent = `
.hnav{display:flex;flex-wrap:wrap;justify-content:center;gap:4px 26px;border-bottom:1px solid ${LINE};padding:4px 0 10px;margin:0 10px 14px;font-family:${F};font-variant:small-caps;letter-spacing:2px;font-size:1.12em}
.hnav-it{position:relative;color:${PINK};cursor:pointer;padding:2px 0}
.hnav-it>span{border-bottom:1px solid transparent;transition:border-color .15s}
.hnav-it:hover>span{border-color:${PINK}}
.hnav-dd{visibility:hidden;opacity:0;transform:translate(-50%,4px);transition:opacity .15s,transform .15s;position:fixed;z-index:9999;padding-top:8px}
.hnav-dd.on{visibility:visible;opacity:1;transform:translate(-50%,0)}
.hnav-box{background:var(--background-primary);border:1px solid ${LINE};border-radius:12px;padding:6px;min-width:170px;font-variant:normal;letter-spacing:0;font-size:.82em;font-family:var(--font-interface);box-shadow:0 6px 20px rgba(185,131,141,.12)}
.hnav-box a{display:block;padding:5px 12px;border-radius:7px;color:var(--text-normal);text-decoration:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:240px}
.hnav-box a:hover{background:${TINT};color:#993556}
.hnav-h{font-size:.78em;color:${PINK};padding:6px 12px 2px;letter-spacing:.06em}
.hnav-sep{height:1px;background:${LINE};margin:5px 8px}`;
    document.head.appendChild(st);
}

// drop only orphaned menus (their nav bar is no longer on screen); never another live render's menus
document.querySelectorAll(".hnav-dd").forEach(x => { if (!x._owner || !x._owner.isConnected) x.remove(); });
const bar = dv.container.createDiv({ cls: "hnav" });
const folders = root.children.filter(c => c.children && !c.name.startsWith(".") && !SKIP.includes(c.name)).sort((a, b) => a.name.localeCompare(b.name));
for (const f of folders) {
    const it = bar.createDiv({ cls: "hnav-it" });
    it.createSpan({ text: label(f.name) });
    it.addEventListener("click", e => { if (e.target === it || e.target.parentElement === it) openFolder(f); });
    const subs = f.children.filter(c => c.children && !c.name.startsWith(".")).sort((a, b) => a.name.localeCompare(b.name, "zh"));
    const notes = recent(f, 4);
    if (f.path === "01 Daily" || f.path === "50 Money" || f.path === "80 Library" || (!subs.length && !notes.length)) continue;
    const dd = document.body.createDiv({ cls: "hnav-dd" }); dd._owner = it;
    const box = dd.createDiv({ cls: "hnav-box" });
    let hideT = null;
    const show = () => { clearTimeout(hideT); if (!dd.isConnected) document.body.appendChild(dd); document.querySelectorAll(".hnav-dd.on").forEach(x => x !== dd && x.removeClass("on")); const r = it.getBoundingClientRect(); dd.style.left = (r.left + r.width / 2) + "px"; dd.style.top = r.bottom + "px"; dd.addClass("on"); };
    const hide = () => { hideT = setTimeout(() => dd.removeClass("on"), 120); };
    it.addEventListener("mouseenter", show); it.addEventListener("mouseleave", hide);
    dd.addEventListener("mouseenter", () => clearTimeout(hideT)); dd.addEventListener("mouseleave", hide);
    dd.addEventListener("click", () => dd.removeClass("on"));
    if (subs.length) {
        box.createDiv({ cls: "hnav-h", text: "Folders" });
        for (const s of subs) { const a = box.createEl("a", { text: s.name }); a.onclick = e => { e.stopPropagation(); openFolder(s); }; }
    }
    if (notes.length) {
        if (subs.length) box.createDiv({ cls: "hnav-sep" });
        box.createDiv({ cls: "hnav-h", text: "Recent" });
        for (const n of notes) { const a = box.createEl("a", { text: n.basename }); a.onclick = e => { e.stopPropagation(); app.workspace.getLeaf(false).openFile(n); }; }
    }
}
