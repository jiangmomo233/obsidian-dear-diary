// 记账 · iCost-style personal finance for Obsidian
// Loaded with: await dv.view("System & Attachments/Scripts/money")              → full app
//              await dv.view("System & Attachments/Scripts/money", {account})   → one account
// Data lives in notes: 50 Money/Personal/Transactions/<YYYY-MM>/*.md (one note per entry),
// 50 Money/Personal/Accounts/*.md (one per account) and 50 Money/Personal/记账设置.md.

const ROOT = "50 Money/Personal";
const P = { tx: ROOT + "/Transactions", acc: ROOT + "/Accounts", settings: ROOT + "/记账设置.md", exp: ROOT + "/导出" };
const W = (window.__mny = window.__mny || {
    tab: "ledger", month: moment().format("YYYY-MM"), filter: "all", q: "", acct: "",
    statPeriod: "month", statType: "支出", statAnchor: moment().format("YYYY-MM-DD"), openCat: null,
    calMonth: moment().format("YYYY-MM"), calDay: null, budgetPeriod: "month", showHidden: false,
});
const ACCOUNT_MODE = input && input.account;

// ───────────────────────── helpers ─────────────────────────
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = v => { if (typeof v === "number") return v; const n = parseFloat(String(v ?? "").replace(/[^\d.\-]/g, "")); return isNaN(n) ? 0 : n; };
const r2 = v => Math.round(v * 100) / 100;
const SYM = { CNY: "¥", USD: "$" };
const WEEK = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
const fmtN = v => Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmt = (v, cur = "CNY", sign = false) => (v < -0.004 ? "−" : sign && v > 0.004 ? "+" : "") + (SYM[cur] || cur + " ") + fmtN(v);
const fmtShort = v => { const a = Math.abs(v); return a >= 10000 ? (v / 10000).toFixed(a >= 100000 ? 0 : 1) + "万" : a >= 1000 ? Math.round(v).toLocaleString("en-US") : String(Math.round(v)); };
const calc = s => { // amount field accepts simple arithmetic like 35+12.5
    s = String(s ?? "").replace(/[×＊]/g, "*").replace(/[÷／]/g, "/").replace(/[＋]/g, "+").replace(/[－—]/g, "-").replace(/,/g, "").trim();
    if (!s) return NaN;
    if (!/^[\d.+\-*/() ]+$/.test(s)) return NaN;
    try { const v = Function(`"use strict";return (${s})`)(); return isFinite(v) ? r2(v) : NaN; } catch (e) { return NaN; }
};
const stopKeys = el => el.addEventListener("keydown", e => e.stopPropagation());
const h = (tag, attrs = {}, kids = []) => {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
        if (v == null || v === false) continue;
        if (k === "cls") el.className = v;
        else if (k === "html") el.innerHTML = v;
        else if (k === "text") el.textContent = v;
        else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
        else if (k === "style" && typeof v === "object") { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith("--")) el.style.setProperty(sk, sv); else el.style[sk] = sv; } }
        else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of [].concat(kids)) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c)));
    if (tag === "input" || tag === "textarea") stopKeys(el);
    return el;
};
const toast = msg => {
    const t = h("div", { cls: "mny-toast", text: msg });
    document.body.append(t);
    setTimeout(() => t.classList.add("on"), 10);
    setTimeout(() => { t.classList.remove("on"); setTimeout(() => t.remove(), 300); }, 2200);
};
const getFile = path => app.vault.getAbstractFileByPath(path);
const ensureFolder = async path => {
    const parts = path.split("/"); let cur = "";
    for (const p of parts) { cur = cur ? cur + "/" + p : p; if (!getFile(cur)) { try { await app.vault.createFolder(cur); } catch (e) { } } }
};
const safeName = s => String(s || "").replace(/[\\/:*?"<>|#^[\]\n\r\t]/g, " ").replace(/\s+/g, " ").trim().slice(0, 28).trim() || "记账";
const openNote = path => app.workspace.openLinkText(path, "", true);
let rerenderTimer = null;
const rerender = (delay = 700) => { clearTimeout(rerenderTimer); rerenderTimer = setTimeout(() => { try { renderAll(); } catch (e) { console.error(e); } }, delay); };

// ───────────────────────── settings ─────────────────────────
const DEFAULT_SETTINGS = {
    base_currency: "CNY", usd_cny: 6.69, rate_updated: "", auto_rate: true,
    expense_categories: [{ name: "餐饮", icon: "🍜", subs: ["正餐"] }, { name: "其他", icon: "📦", subs: ["其他"] }],
    income_categories: [{ name: "工作", icon: "💼", subs: ["工资"] }, { name: "其他", icon: "📦", subs: ["其他"] }],
    budgets: { week: { total: 0, cats: {} }, month: { total: 0, cats: {} }, year: { total: 0, cats: {} } },
    templates: [], recurring: [],
};
function loadSettings() {
    const pg = dv.page(P.settings);
    const fm = (pg && pg.file && pg.file.frontmatter) || {};
    const S = Object.assign({}, DEFAULT_SETTINGS, JSON.parse(JSON.stringify(fm)));
    S.budgets = Object.assign({}, DEFAULT_SETTINGS.budgets, S.budgets || {});
    for (const k of ["week", "month", "year"]) S.budgets[k] = Object.assign({ total: 0, cats: {} }, S.budgets[k] || {});
    for (const k of ["templates", "recurring"]) if (!Array.isArray(S[k])) S[k] = [];
    return S;
}
async function saveSettings(patch) {
    let f = getFile(P.settings);
    if (!f) { await ensureFolder(ROOT); f = await app.vault.create(P.settings, ""); }
    await app.fileManager.processFrontMatter(f, fm => {
        for (const [k, v] of Object.entries(patch)) fm[k] = typeof v === "function" ? v(fm[k]) : v;
    });
}
let S = loadSettings();
const rate = () => num(S.usd_cny) || 6.69;
const BASE = () => S.base_currency === "USD" ? "USD" : "CNY";
const toCNY = (v, cur, r) => cur === "USD" ? v * (r || rate()) : v;
const toBase = vCNY => BASE() === "USD" ? vCNY / rate() : vCNY;
const money = (vCNY, sign) => fmt(toBase(vCNY), BASE(), sign);
const catList = type => (type === "收入" ? S.income_categories : S.expense_categories) || [];
const catInfo = (type, name) => catList(type === "退款" ? "支出" : type).find(c => c.name === name) || { name: name || "未分类", icon: "•", subs: [] };
const PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"];
const catColor = (type, name) => { const l = catList(type === "退款" ? "支出" : type); const i = l.findIndex(c => c.name === name); return i < 0 ? "#8a8a8a" : PALETTE[i % PALETTE.length]; };

// ───────────────────────── data ─────────────────────────
function loadAccounts() {
    const out = [];
    for (const p of dv.pages(`"${P.acc}"`)) {
        const f = p.file.frontmatter || {};
        out.push({
            name: p.file.name, path: p.file.path, kind: f.kind === "信用" ? "信用" : "资金", currency: f.currency || "CNY",
            icon: f.icon || p.file.name.slice(0, 1), color: f.color || "#888", order: num(f.order) || 99,
            balance: f.balance, balance_date: f.balance_date, statement_day: num(f.statement_day) || null, due_day: num(f.due_day) || null,
            credit_limit: num(f.credit_limit) || null, hidden: !!f.hidden, archived: !!f.archived, note: f.note || "",
        });
    }
    out.sort((a, b) => a.order - b.order || a.name.localeCompare(b.name));
    return out;
}
function parseDate(v) {
    if (!v) return null;
    if (v.toISO) return moment(v.toISO());
    const m = moment(String(v), [moment.ISO_8601, "YYYY-MM-DD HH:mm", "YYYY-MM-DD"], true);
    return m.isValid() ? m : (moment(String(v)).isValid() ? moment(String(v)) : null);
}
function loadTx() {
    const out = [];
    for (const p of dv.pages(`"${P.tx}"`)) {
        const f = p.file.frontmatter || {};
        if (!f.type) continue;
        const m = parseDate(f.date) || moment(p.file.ctime.toMillis ? p.file.ctime.toMillis() : undefined);
        const t = {
            path: p.file.path, name: p.file.name, type: String(f.type), m, ts: m.valueOf(), ymd: m.format("YYYY-MM-DD"), ym: m.format("YYYY-MM"),
            amount: num(f.amount), currency: f.currency || "CNY", category: f.category || "", sub: f.subcategory || "", account: f.account || "",
            to_account: f.to_account || "", to_amount: f.to_amount === undefined || f.to_amount === null || f.to_amount === "" ? null : num(f.to_amount),
            to_currency: f.to_currency || null, rate: num(f.rate) || null, fee: num(f.fee), merchant: f.merchant || "", item: f.item || "",
            note: f.note || "", review: f.review === true || f.review === "true", exclude: f.exclude === true || f.exclude === "true",
            reimburse: f.reimburse || "", refund_of: null, source: f.source || "", raw: f,
        };
        const refs = Array.isArray(f.refund_of) ? f.refund_of : f.refund_of ? [f.refund_of] : [];
        t.refund_ofs = refs.map(r => { const lk = String(r).replace(/^\[\[|\]\]$/g, "").split("|")[0]; const dest = app.metadataCache.getFirstLinkpathDest(lk, p.file.path); return dest ? dest.path : null; }).filter(Boolean);
        t.refund_of = t.refund_ofs[0] || null;
        t.aa = f.aa === true || f.aa === "true";
        t.aa_expect = num(f.aa_expect) || 0;
        t.aa_with = f.aa_with || "";
        t.project = f.project ? String(f.project) : "";
        t.cny = toCNY(t.amount, t.currency, t.rate);
        out.push(t);
    }
    out.sort((a, b) => b.ts - a.ts || a.name.localeCompare(b.name));
    return out;
}
let ACCS = [], TX = [], REFUNDED = {}, AARECV = {};
function reload() {
    S = loadSettings();
    ACCS = loadAccounts();
    TX = loadTx();
    REFUNDED = {}; AARECV = {};
    const byPath = Object.fromEntries(TX.map(t => [t.path, t]));
    const pending = [];
    for (const t of TX) {
        if (t.type !== "退款" || !t.refund_ofs.length) continue;
        const origs = t.refund_ofs.map(p => byPath[p]).filter(Boolean);
        if (!origs.length) continue;
        pending.push([t, origs]);
    }
    // One AA payment can cover several bills (e.g. three hotel nights). Bills with 「别人应还」 are filled first,
    // up to what is still owed; the rest is split across the other linked bills by amount.
    for (const [t, origs] of pending.sort((a, b) => a[0].ts - b[0].ts)) {
        const add = (o, v) => { REFUNDED[o.path] = (REFUNDED[o.path] || 0) + v; if (t.aa) AARECV[o.path] = (AARECV[o.path] || 0) + v; };
        if (origs.length === 1) { add(origs[0], t.cny); continue; }
        let left = t.cny;
        const withExp = origs.filter(o => o.aa_expect), rest = origs.filter(o => !o.aa_expect);
        const owed = withExp.map(o => Math.max(0, toCNY(o.aa_expect, o.currency, o.rate) - (AARECV[o.path] || 0)));
        const owedTot = owed.reduce((a, b) => a + b, 0);
        if (owedTot > 0) { const f = Math.min(1, left / owedTot); withExp.forEach((o, i) => add(o, owed[i] * f)); left -= Math.min(left, owedTot); }
        if (left > 0.004) {
            const tgt = rest.length ? rest : withExp, tot = tgt.reduce((a, o) => a + o.cny, 0) || 1;
            tgt.forEach(o => add(o, left * o.cny / tot));
        }
    }
}
const accByName = n => ACCS.find(a => a.name === n);
const aaLeft = t => t.type === "支出" && t.aa_expect ? toCNY(t.aa_expect, t.currency, t.rate) - (AARECV[t.path] || 0) : 0;

// Net spending effect of one entry in CNY (refunds negative, transfer fees count as spending).
// 垫款生意: money fronted to suppliers and paid back by buyers. Kept out of personal 收支/预算,
// tracked on the 生意 tab instead (account balances still move).
const BIZ_EXP = "生意成本", BIZ_INC = "生意回款";
const isBiz = t => t.type !== "转账" && (t.category === BIZ_EXP || t.category === BIZ_INC);
function spendOf(t) {
    if (t.exclude || isBiz(t)) return 0;
    if (t.type === "支出") return t.reimburse === "已报销" ? 0 : t.cny;
    if (t.type === "退款") return -t.cny;
    if (t.type === "转账" && t.fee) return toCNY(t.fee, t.currency, t.rate);
    return 0;
}
const incomeOf = t => (t.type === "收入" && !t.exclude && !isBiz(t) ? t.cny : 0);
const catOf = t => t.type === "转账" ? "生活服务" : t.category || "未分类";
const subOf = t => t.type === "转账" ? "手续费" : t.sub || "";
function summarize(list) {
    let exp = 0, inc = 0;
    for (const t of list) { exp += spendOf(t); inc += incomeOf(t); }
    return { exp, inc, bal: inc - exp };
}
const inRange = (t, a, b) => t.ts >= a.valueOf() && t.ts < b.valueOf();
function periodRange(kind, anchor) {
    const a = moment(anchor);
    if (kind === "week") { const s = a.clone().startOf("isoWeek"); return [s, s.clone().add(1, "week")]; }
    if (kind === "year") { const s = a.clone().startOf("year"); return [s, s.clone().add(1, "year")]; }
    const s = a.clone().startOf("month"); return [s, s.clone().add(1, "month")];
}
const periodLabel = (kind, a) => kind === "week" ? `${a.format("M月D日")} – ${a.clone().add(6, "day").format("M月D日")}` : kind === "year" ? a.format("YYYY年") : a.format("YYYY年M月");

// Balance: anchor balance at balance_date + every movement after it.
function delta(t, accName) {
    let d = 0;
    if (t.type === "支出" && t.account === accName) d -= t.amount;
    if ((t.type === "收入" || t.type === "退款") && t.account === accName) d += t.amount;
    if (t.type === "转账") {
        if (t.account === accName) d -= t.amount + (t.fee || 0);
        if (t.to_account === accName) d += t.to_amount ?? t.amount;
    }
    return d;
}
function balanceOf(a) {
    if (a.balance === undefined || a.balance === null || a.balance === "" || !a.balance_date) return null;
    const bd = String(a.balance_date);
    const anchor = bd.length <= 10 ? moment(bd).endOf("day") : moment(bd);
    let b = num(a.balance);
    for (const t of TX) if (t.ts > anchor.valueOf()) b += delta(t, a.name);
    return r2(b);
}
function daysUntil(day) {
    if (!day) return null;
    const today = moment().startOf("day");
    let d = today.clone().date(Math.min(day, today.daysInMonth()));
    if (d.isBefore(today)) { d = today.clone().add(1, "month").startOf("month"); d.date(Math.min(day, d.daysInMonth())); }
    return d.diff(today, "days");
}

// ───────────────────────── note writing ─────────────────────────
const FIELD_ORDER = ["type", "date", "amount", "currency", "category", "subcategory", "account", "to_account", "to_amount", "to_currency", "rate", "fee",
    "merchant", "item", "note", "refund_of", "aa", "aa_expect", "aa_with", "project", "reimburse", "exclude", "review", "source", "source_id", "source_ids"];
function cleanFM(fm, data) {
    for (const [k, v] of Object.entries(data)) {
        if (v === undefined || v === null || v === "" || v === false || (k === "fee" && !v)) delete fm[k];
        else fm[k] = v;
    }
    const tmp = {};
    for (const k of FIELD_ORDER) if (k in fm) tmp[k] = fm[k];
    for (const k of Object.keys(fm)) if (!(k in tmp)) tmp[k] = fm[k];
    for (const k of Object.keys(fm)) delete fm[k];
    Object.assign(fm, tmp);
}
async function createTx(data) {
    const m = moment(data.date);
    const folder = `${P.tx}/${m.format("YYYY-MM")}`;
    await ensureFolder(folder);
    const title = data.type === "转账" ? `${data.account}→${data.to_account}` : (data.merchant || data.subcategory || data.category || data.type);
    let base = `${folder}/${m.format("YYYY-MM-DD HHmm")} ${safeName(title)}`, path = base + ".md", i = 2;
    while (getFile(path)) path = `${base} ${i++}.md`;
    const f = await app.vault.create(path, "");
    await app.fileManager.processFrontMatter(f, fm => cleanFM(fm, Object.assign({ source: "手动" }, data)));
    return f;
}
async function updateTx(path, data) {
    const f = getFile(path); if (!f) return;
    await app.fileManager.processFrontMatter(f, fm => cleanFM(fm, data));
}
async function deleteTx(path) {
    const f = getFile(path); if (!f) return;
    if (app.fileManager.trashFile) await app.fileManager.trashFile(f); else await app.vault.trash(f, true);
}
async function updateAccount(path, patch) {
    const f = getFile(path); if (!f) return;
    await app.fileManager.processFrontMatter(f, fm => { for (const [k, v] of Object.entries(patch)) { if (v === null || v === "") fm[k] = null; else fm[k] = v; } });
}

// ───────────────────────── live exchange rate ─────────────────────────
async function fetchRate() {
    const url = "https://open.er-api.com/v6/latest/USD";
    let j;
    try { const ob = require("obsidian"); j = (await ob.requestUrl({ url })).json; }
    catch (e) { j = await (await fetch(url)).json(); }
    const v = j && j.rates && j.rates.CNY;
    if (!v) throw new Error("no rate");
    return Math.round(v * 10000) / 10000;
}
async function refreshRate(manual) {
    try {
        const v = await fetchRate();
        await saveSettings({ usd_cny: v, rate_updated: moment().format("YYYY-MM-DD") });
        if (manual) toast(`汇率已更新：1 USD = ${v} CNY`);
        rerender(600);
    } catch (e) { if (manual) toast("没取到最新汇率，请检查网络，或直接手动输入"); }
}

// ───────────────────────── recurring entries ─────────────────────────
async function runRecurring() {
    if (W.recurringRan === moment().format("YYYY-MM-DD") || !S.recurring.length) return;
    W.recurringRan = moment().format("YYYY-MM-DD");
    let made = 0;
    for (const r of S.recurring) {
        if (!r || !r.id || !r.day || !r.data) continue;
        for (const back of [1, 0]) {
            const mo = moment().subtract(back, "month");
            const due = mo.clone().date(Math.min(num(r.day), mo.daysInMonth())).hour(9).minute(0);
            if (due.isAfter(moment()) || (r.start && due.format("YYYY-MM") < r.start)) continue;
            const exists = TX.some(t => t.raw.source_id === `recurring-${r.id}-${due.format("YYYY-MM")}`);
            if (exists) continue;
            await createTx(Object.assign({}, r.data, { date: due.format("YYYY-MM-DDTHH:mm"), source: "周期记账", source_id: `recurring-${r.id}-${due.format("YYYY-MM")}` }));
            made++;
        }
    }
    if (made) { toast(`已自动记入 ${made} 笔周期账单`); rerender(900); }
}

// ───────────────────────── UI pieces ─────────────────────────
const icon = (emoji, color, size) => h("div", { cls: "mny-ic" + (size ? " " + size : ""), style: { "--c": color }, text: emoji });
const accIcon = a => h("div", { cls: "mny-ic acc", style: { "--c": a ? a.color : "#888" }, text: a ? a.icon : "?" });

// Readable product name: drop order numbers and anything that just repeats the merchant.
function itemLabel(t) {
    if (t.source === "Chase") return "";
    let s = String(t.item || "").split("；")[0];
    s = s.replace(/^退款-/, "").replace(/^地铁_([^_]+)_.*$/, "$1站")
        .replace(/[(（][^)）]*\d{6,}[^)）]*[)）]?/g, "")
        .replace(/[-_ ,]?(美团App|美团\/大众点评点餐订单|美团收银|扫码付|桌边付|订单编号:?)[-:]?.*$/, "")
        .replace(/[-_ ]?[A-Z]{0,4}\d{8,}.*$/, "").replace(/[,，\-_ (（]+$/, "").trim();
    const m = String(t.merchant || "").replace(/^淘宝 · /, "");
    if (m && s.toLowerCase().startsWith(m.toLowerCase())) s = s.slice(m.length).replace(/^[\s(（·\-]+|[)）\s]+$/g, "");
    if (!s || s === "/" || s === m || (m && m.includes(s)) || /^(费用|商品|商品交易|普通订单|订单付款|先购后付|先骑后付|销售商品|收钱码收款|消费)$/.test(s)) return "";
    if (t.item && t.item.includes("；")) s += " 等";
    return s.length > 26 ? s.slice(0, 26) + "…" : s;
}
function txRow(t) {
    const isT = t.type === "转账";
    const ci = catInfo(t.type, t.category);
    const refunded = (REFUNDED[t.path] || 0) - (AARECV[t.path] || 0);
    const full = t.type === "支出" && refunded >= t.cny - 0.005;
    const title = isT ? (t.merchant && t.merchant.startsWith("换汇") ? t.merchant : "转账") : (t.type === "退款" ? `${t.aa ? "AA收款" : "退款"} · ${t.sub || t.category || ""}` : (t.sub ? `${t.category} · ${t.sub}` : (t.category || "未分类")));
    const subtitle = isT ? `${t.account} → ${t.to_account}` : [t.merchant, itemLabel(t), t.account].filter(Boolean).join(" · ");
    let amtTxt, cls = "";
    if (isT) {
        amtTxt = fmt(t.amount, t.currency);
        if (t.to_currency && t.to_currency !== t.currency) amtTxt += ` → ${fmt(t.to_amount, t.to_currency)}`;
        cls = "neutral";
    } else if (t.type === "收入" || t.type === "退款") { amtTxt = fmt(t.amount, t.currency, true); cls = "pos"; }
    else amtTxt = fmt(-t.amount, t.currency);
    const badges = [];
    if (t.review) badges.push(h("span", { cls: "mny-badge warn", text: "待确认" }));
    if (refunded > 0 && t.type === "支出") badges.push(h("span", { cls: "mny-badge", text: full ? "已退款" : `已退 ${fmt(refunded)}` }));
    if (t.type === "支出" && !t.aa_expect && AARECV[t.path] > 0.004) badges.push(h("span", { cls: "mny-badge good", text: `AA 收回 ${money(AARECV[t.path])} · 我付 ${money(t.cny - AARECV[t.path])}` }));
    if (t.type === "支出" && t.aa_expect) {
        const left = aaLeft(t);
        badges.push(left > 0.5 ? h("span", { cls: "mny-badge warn", text: `AA 待收 ${money(left)}` }) : h("span", { cls: "mny-badge good", text: `AA 已收齐 · 我付 ${money(t.cny - (AARECV[t.path] || 0))}` }));
    }
    if (t.type === "退款" && t.aa && t.refund_ofs.length > 1) badges.push(h("span", { cls: "mny-badge", text: `分摊 ${t.refund_ofs.length} 笔` }));
    if (isBiz(t)) badges.push(h("span", { cls: "mny-badge biz", text: t.project ? `生意 · ${t.project}` : "生意 · 未指定项目" }));
    if (t.exclude) badges.push(h("span", { cls: "mny-badge", text: "不计收支" }));
    if (t.reimburse) badges.push(h("span", { cls: "mny-badge", text: t.reimburse }));
    if (t.currency === "USD" && !isT) badges.push(h("span", { cls: "mny-badge", text: `≈ ${money(t.cny)}` }));
    if (isT && t.rate && t.to_currency && t.to_currency !== t.currency) badges.push(h("span", { cls: "mny-badge", text: `汇率 ${t.rate}` }));
    return h("div", { cls: "mny-row" + (full ? " muted" : ""), onclick: () => openEditor(t) }, [
        isT ? icon("⇄", "#6b7280") : icon(ci.icon, catColor(t.type, t.category)),
        h("div", { cls: "mny-row-main" }, [
            h("div", { cls: "mny-row-title" }, [title, ...badges]),
            h("div", { cls: "mny-row-sub", text: (t.m.format("HH:mm") === "00:00" ? "" : t.m.format("HH:mm") + " · ") + subtitle }),
            t.note && !isT ? h("div", { cls: "mny-row-note", text: t.note }) : null,
        ]),
        h("div", { cls: "mny-row-amt " + cls + (full ? " strike" : ""), text: amtTxt }),
    ]);
}
function dayGroups(list, parent, opts = {}) {
    const groups = {};
    for (const t of list) (groups[t.ymd] = groups[t.ymd] || []).push(t);
    const days = Object.keys(groups).sort().reverse();
    if (!days.length) { parent.append(h("div", { cls: "mny-empty", text: opts.empty || "这段时间还没有记录" })); return; }
    const limit = opts.limit || 9999;
    days.slice(0, limit).forEach(d => {
        const s = summarize(groups[d]);
        const m = moment(d);
        const card = h("div", { cls: "mny-card mny-day" }, [
            h("div", { cls: "mny-day-head" }, [
                h("span", { cls: "mny-day-date", text: `${m.format("M月D日")} ${WEEK[m.day()]}` }),
                h("span", { cls: "mny-day-sum", text: [s.exp ? `支出 ${money(s.exp)}` : "", s.inc ? `收入 ${money(s.inc)}` : ""].filter(Boolean).join("　") }),
            ]),
        ]);
        groups[d].forEach(t => card.append(txRow(t)));
        parent.append(card);
    });
    if (days.length > limit) {
        const more = h("button", { cls: "mny-btn ghost wide", text: `显示更早的 ${days.length - limit} 天`, onclick: () => { more.remove(); dayGroups(list.filter(t => t.ymd < days[limit - 1]), parent, { limit: 9999 }); } });
        parent.append(more);
    }
}
function navBar(label, onPrev, onNext, onLabel) {
    return h("div", { cls: "mny-nav" }, [
        h("button", { cls: "mny-navbtn", text: "‹", onclick: onPrev, "aria-label": "上一个" }),
        h("button", { cls: "mny-navlabel", text: label, onclick: onLabel }),
        h("button", { cls: "mny-navbtn", text: "›", onclick: onNext, "aria-label": "下一个" }),
    ]);
}
function seg(options, value, onChange, cls = "") {
    return h("div", { cls: "mny-seg " + cls }, options.map(([v, label]) => h("button", { cls: v === value ? "on" : "", text: label, onclick: () => onChange(v) })));
}
function progress(used, total) {
    const pct = total > 0 ? used / total : 0;
    const over = pct > 1;
    return h("div", { cls: "mny-prog" + (over ? " over" : pct > 0.85 ? " warn" : "") }, [h("div", { style: { width: Math.min(100, pct * 100).toFixed(1) + "%" } })]);
}

// ───────────────────────── tab: 账本 ─────────────────────────
function renderLedger(el) {
    const mm = moment(W.month + "-01");
    const [a, b] = [mm.clone().startOf("month"), mm.clone().add(1, "month").startOf("month")];
    const monthTx = TX.filter(t => inRange(t, a, b));
    const s = summarize(monthTx);
    el.append(navBar(mm.format("YYYY年M月"),
        () => { W.month = mm.clone().subtract(1, "month").format("YYYY-MM"); renderAll(); },
        () => { W.month = mm.clone().add(1, "month").format("YYYY-MM"); renderAll(); },
        () => { W.month = moment().format("YYYY-MM"); renderAll(); }));
    const bud = num(S.budgets.month.total);
    const hero = h("div", { cls: "mny-card mny-hero" }, [
        h("div", { cls: "mny-hero-label", text: "本月支出" }),
        h("div", { cls: "mny-hero-num", text: money(s.exp) }),
        h("div", { cls: "mny-hero-row" }, [
            h("div", {}, [h("span", { text: "收入 " }), h("b", { text: money(s.inc) })]),
            h("div", {}, [h("span", { text: "结余 " }), h("b", { text: money(s.bal) })]),
        ]),
    ]);
    if (bud > 0) {
        const left = bud - s.exp;
        const today = moment();
        const daysLeft = today.isSame(mm, "month") ? mm.daysInMonth() - today.date() + 1 : 0;
        hero.append(h("div", { cls: "mny-hero-budget" }, [
            h("div", { cls: "mny-hero-row small" }, [
                h("span", { text: `月预算 ${money(bud)}` }),
                h("span", { text: left >= 0 ? `剩余 ${money(left)}${daysLeft ? ` · 日均可用 ${money(left / daysLeft)}` : ""}` : `已超支 ${money(-left)}` }),
            ]),
            progress(s.exp, bud),
        ]));
    }
    el.append(hero);

    // filters
    const nReview = TX.filter(t => t.review).length;
    const bar = h("div", { cls: "mny-filters" });
    const nAA = TX.filter(t => aaLeft(t) > 0.5).length;
    const chips = [["all", "全部"], ["支出", "支出"], ["收入", "收入"], ["转账", "转账"], ["退款", "退款"], ["review", `待确认 ${nReview}`], ["aa", nAA ? `AA待收 ${nAA}` : "AA"], ["reimburse", "报销"]];
    bar.append(h("div", { cls: "mny-chips" }, chips.map(([v, l]) => h("button", { cls: "mny-chip" + (W.filter === v ? " on" : "") + (v === "review" && nReview ? " warn" : ""), text: l, onclick: () => { W.filter = v; renderAll(); } }))));
    const sel = h("select", { cls: "mny-select", onchange: e => { W.acct = e.target.value; renderAll(); } }, [h("option", { value: "", text: "全部账户" }), ...ACCS.filter(x => !x.archived).map(x => h("option", { value: x.name, text: x.name, selected: W.acct === x.name }))]);
    const q = h("input", { cls: "mny-input", type: "search", placeholder: "搜索商家 / 备注 / 分类", value: W.q });
    q.addEventListener("input", e => { W.q = e.target.value; clearTimeout(W._qt); W._qt = setTimeout(() => { renderAll(); const n = root.querySelector(".mny-filters input"); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } }, 350); });
    bar.append(h("div", { cls: "mny-filter-row" }, [q, sel]));
    el.append(bar);

    // review & search span all months; otherwise this month
    let list = (W.filter === "review" || W.filter === "reimburse" || W.filter === "aa" || W.q) ? TX : monthTx;
    if (W.filter === "review") list = list.filter(t => t.review);
    else if (W.filter === "aa") list = list.filter(t => t.aa_expect || t.aa);
    else if (W.filter === "reimburse") list = list.filter(t => t.reimburse);
    else if (W.filter !== "all") list = list.filter(t => t.type === W.filter);
    if (W.acct) list = list.filter(t => t.account === W.acct || t.to_account === W.acct);
    if (W.q) { const k = W.q.toLowerCase(); list = list.filter(t => [t.merchant, t.item, t.note, t.category, t.sub, t.account, t.to_account, String(t.amount)].join(" ").toLowerCase().includes(k)); }
    if (W.filter === "review" && list.length) el.append(h("div", { cls: "mny-hint", text: "这些是我整理时拿不准的：转给个人的钱、没有明细的账单、换汇的美元金额。点开改好分类或金额后点「确认」即可。" }));
    if (W.filter === "aa") {
        const owed = TX.reduce((s, t) => s + Math.max(0, aaLeft(t)), 0);
        el.append(h("div", { cls: "mny-hint", text: owed > 0.5 ? `朋友还欠你 ${money(owed)}。收到转账后，点开那笔收入 →「关联到 AA 账单」。` : "没有待收的 AA。先付钱时，在那笔支出里填「别人应还」；收到朋友转账后关联回去。" }));
    }
    if (W.q || W.filter === "review" || W.filter === "reimburse") {
        const ss = summarize(list);
        el.append(h("div", { cls: "mny-hint", text: `共 ${list.length} 笔 · 支出 ${money(ss.exp)} · 收入 ${money(ss.inc)}` }));
    }
    dayGroups(list, el, { limit: W.q || W.filter !== "all" ? 9999 : 9999 });
}

// ───────────────────────── tab: 统计 ─────────────────────────
function barChart(parent, data, opts = {}) { // data: [{label, value, tip, key}]
    const Wd = 640, H = 170, padL = 6, padB = 22, padT = 18;
    const max = Math.max(1, ...data.map(d => d.value));
    const n = data.length, slot = (Wd - padL * 2) / n, bw = Math.max(3, Math.min(26, slot * 0.62));
    const wrap = h("div", { cls: "mny-chart" });
    const tip = h("div", { cls: "mny-tip" });
    let svg = `<svg viewBox="0 0 ${Wd} ${H}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${esc(opts.aria || "趋势")}">`;
    const base = H - padB;
    for (const g of [0.5, 1]) svg += `<line x1="0" x2="${Wd}" y1="${base - (base - padT) * g}" y2="${base - (base - padT) * g}" class="grid"/>`;
    svg += `<line x1="0" x2="${Wd}" y1="${base}" y2="${base}" class="axis"/>`;
    svg += `<text x="${Wd}" y="${padT - 6}" class="lbl" text-anchor="end">${esc(fmtShort(toBase(max)))}</text>`;
    data.forEach((d, i) => {
        const x = padL + i * slot + (slot - bw) / 2;
        const hh = d.value > 0 ? Math.max(2, (base - padT) * d.value / max) : 0;
        const y = base - hh, r = Math.min(4, bw / 2, hh);
        if (hh > 0) svg += `<path class="bar${d.hi ? " hi" : ""}" d="M${x},${base} V${y + r} Q${x},${y} ${x + r},${y} H${x + bw - r} Q${x + bw},${y} ${x + bw},${y + r} V${base} Z"/>`;
        if (d.showLabel) svg += `<text x="${x + bw / 2}" y="${H - 6}" class="lbl" text-anchor="middle">${esc(d.label)}</text>`;
        svg += `<rect class="hit" data-i="${i}" x="${padL + i * slot}" y="0" width="${slot}" height="${H}"/>`;
    });
    svg += "</svg>";
    wrap.innerHTML = svg;
    wrap.append(tip);
    wrap.querySelectorAll(".hit").forEach(r => {
        const d = data[+r.dataset.i];
        r.addEventListener("mouseenter", () => {
            tip.innerHTML = `<b>${esc(d.tip || d.label)}</b><br>${esc(money(d.value))}`;
            tip.style.display = "block";
            const box = wrap.getBoundingClientRect(), rb = r.getBoundingClientRect();
            let left = rb.left - box.left + rb.width / 2;
            left = Math.max(60, Math.min(box.width - 60, left));
            tip.style.left = left + "px";
        });
        r.addEventListener("mouseleave", () => (tip.style.display = "none"));
        if (opts.onClick) r.addEventListener("click", () => opts.onClick(d));
    });
    parent.append(wrap);
}
function renderStats(el) {
    const kind = W.statPeriod, type = W.statType;
    const anchor = moment(W.statAnchor);
    const [a, b] = periodRange(kind, anchor);
    el.append(h("div", { cls: "mny-row-flex" }, [
        seg([["week", "周"], ["month", "月"], ["year", "年"]], kind, v => { W.statPeriod = v; W.openCat = null; renderAll(); }),
        seg([["支出", "支出"], ["收入", "收入"]], type, v => { W.statType = v; W.openCat = null; renderAll(); }),
    ]));
    el.append(navBar(periodLabel(kind, a),
        () => { W.statAnchor = a.clone().subtract(1, kind === "week" ? "week" : kind).format("YYYY-MM-DD"); W.openCat = null; renderAll(); },
        () => { W.statAnchor = a.clone().add(1, kind === "week" ? "week" : kind).format("YYYY-MM-DD"); W.openCat = null; renderAll(); },
        () => { W.statAnchor = moment().format("YYYY-MM-DD"); renderAll(); }));
    const val = t => type === "支出" ? spendOf(t) : incomeOf(t);
    const list = TX.filter(t => inRange(t, a, b) && val(t) !== 0);
    const total = list.reduce((s, t) => s + val(t), 0);
    const [pa, pb] = [a.clone().subtract(1, kind === "week" ? "week" : kind), a];
    const prev = TX.filter(t => inRange(t, pa, pb)).reduce((s, t) => s + val(t), 0);
    const elapsed = Math.max(1, Math.min(b.diff(a, "days"), moment().endOf("day").diff(a, "days") + 1));
    const change = prev > 0 ? (total - prev) / prev : null;
    el.append(h("div", { cls: "mny-card mny-hero" }, [
        h("div", { cls: "mny-hero-label", text: `${type}合计` }),
        h("div", { cls: "mny-hero-num", text: money(total) }),
        h("div", { cls: "mny-hero-row" }, [
            h("div", {}, [h("span", { text: "日均 " }), h("b", { text: money(total / elapsed) })]),
            h("div", {}, [h("span", { text: "笔数 " }), h("b", { text: String(list.filter(t => t.type !== "退款").length) })]),
            h("div", {}, [h("span", { text: "比上期 " }), h("b", { text: change === null ? "—" : `${change >= 0 ? "↑" : "↓"} ${Math.abs(change * 100).toFixed(0)}%` })]),
        ]),
    ]));

    // trend
    const trend = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: kind === "year" ? "每月趋势" : "每日趋势" })]);
    const buckets = [];
    if (kind === "year") for (let i = 0; i < 12; i++) { const m = a.clone().add(i, "month"); buckets.push({ key: m.format("YYYY-MM"), label: `${i + 1}`, tip: m.format("YYYY年M月"), showLabel: true, value: 0 }); }
    else { const n = b.diff(a, "days"); for (let i = 0; i < n; i++) { const d = a.clone().add(i, "day"); buckets.push({ key: d.format("YYYY-MM-DD"), label: kind === "week" ? WEEK[d.day()].slice(1) : String(d.date()), tip: `${d.format("M月D日")} ${WEEK[d.day()]}`, showLabel: kind === "week" || d.date() === 1 || d.date() % 5 === 0, value: 0, hi: d.isSame(moment(), "day") }); } }
    const bi = Object.fromEntries(buckets.map((x, i) => [x.key, i]));
    for (const t of list) { const k = kind === "year" ? t.ym : t.ymd; if (k in bi) buckets[bi[k]].value += val(t); }
    buckets.forEach(x => (x.value = Math.max(0, x.value)));
    barChart(trend, buckets, { aria: `${type}趋势`, onClick: d => { if (kind !== "year") { W.tab = "calendar"; W.calMonth = d.key.slice(0, 7); W.calDay = d.key; renderAll(); } else { W.statPeriod = "month"; W.statAnchor = d.key + "-01"; renderAll(); } } });
    el.append(trend);

    // category ranking
    const cats = {};
    for (const t of list) { const c = catOf(t); (cats[c] = cats[c] || { v: 0, n: 0, subs: {}, tx: [] }); cats[c].v += val(t); cats[c].n++; cats[c].tx.push(t); const sb = subOf(t) || "其他"; cats[c].subs[sb] = (cats[c].subs[sb] || 0) + val(t); }
    const rows = Object.entries(cats).filter(([, x]) => x.v > 0.004).sort((x, y) => y[1].v - x[1].v);
    const rank = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: `${type}分类排行` })]);
    if (!rows.length) rank.append(h("div", { cls: "mny-empty", text: "这段时间没有数据" }));
    const top = rows.length ? rows[0][1].v : 1;
    for (const [c, x] of rows) {
        const ci = catInfo(type, c);
        const open = W.openCat === c;
        const row = h("div", { cls: "mny-rank" + (open ? " open" : ""), onclick: () => { W.openCat = open ? null : c; renderAll(); } }, [
            icon(ci.icon, catColor(type, c)),
            h("div", { cls: "mny-rank-main" }, [
                h("div", { cls: "mny-rank-top" }, [h("span", { text: c }), h("span", { cls: "pct", text: `${(x.v / total * 100).toFixed(1)}%` }), h("span", { cls: "mny-rank-amt", text: money(x.v) })]),
                h("div", { cls: "mny-rank-bar" }, [h("div", { style: { width: (x.v / top * 100).toFixed(1) + "%" } })]),
            ]),
        ]);
        rank.append(row);
        if (open) {
            const box = h("div", { cls: "mny-rank-detail" });
            Object.entries(x.subs).filter(([, v]) => Math.abs(v) > 0.004).sort((p, q) => q[1] - p[1]).forEach(([sb, v]) => box.append(h("div", { cls: "mny-subrow" }, [h("span", { text: sb }), h("span", { text: `${(v / x.v * 100).toFixed(0)}%` }), h("b", { text: money(v) })])));
            box.append(h("div", { cls: "mny-subhead", text: `${x.n} 笔` }));
            x.tx.slice(0, 30).forEach(t => box.append(txRow(t)));
            rank.append(box);
        }
    }
    el.append(rank);

    // merchants + biggest
    const grid = h("div", { cls: "mny-grid2" });
    const merch = {};
    for (const t of list) { const k = t.type === "转账" ? "手续费" : (t.merchant || t.item || catOf(t)); merch[k] = (merch[k] || 0) + val(t); }
    const mc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: type === "支出" ? "常去商家" : "收入来源" })]);
    Object.entries(merch).filter(([, v]) => v > 0.004).sort((p, q) => q[1] - p[1]).slice(0, 8).forEach(([k, v], i) => mc.append(h("div", { cls: "mny-subrow" }, [h("span", { cls: "rank-n", text: String(i + 1) }), h("span", { cls: "grow", text: k }), h("b", { text: money(v) })])));
    const big = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: type === "支出" ? "最大的几笔" : "最大的几笔收入" })]);
    list.filter(t => t.type === type).sort((p, q) => q.cny - p.cny).slice(0, 8).forEach(t => big.append(txRow(t)));
    grid.append(mc, big);
    el.append(grid);
}

// ───────────────────────── tab: 日历 ─────────────────────────
function renderCalendar(el) {
    const mm = moment(W.calMonth + "-01");
    el.append(navBar(mm.format("YYYY年M月"),
        () => { W.calMonth = mm.clone().subtract(1, "month").format("YYYY-MM"); W.calDay = null; renderAll(); },
        () => { W.calMonth = mm.clone().add(1, "month").format("YYYY-MM"); W.calDay = null; renderAll(); },
        () => { W.calMonth = moment().format("YYYY-MM"); W.calDay = moment().format("YYYY-MM-DD"); renderAll(); }));
    const byDay = {};
    for (const t of TX) if (t.ym === W.calMonth) { const d = (byDay[t.ymd] = byDay[t.ymd] || { exp: 0, inc: 0, tx: [] }); d.exp += spendOf(t); d.inc += incomeOf(t); d.tx.push(t); }
    const exps = Object.values(byDay).map(d => d.exp).filter(v => v > 0).sort((a, b) => a - b);
    const q = p => exps.length ? exps[Math.min(exps.length - 1, Math.floor(p * exps.length))] : 0;
    const steps = [q(0.25), q(0.5), q(0.75), q(0.9)];
    const lvl = v => v <= 0 ? 0 : 1 + steps.filter(s => v > s).length;
    const card = h("div", { cls: "mny-card" });
    const grid = h("div", { cls: "mny-cal" });
    ["一", "二", "三", "四", "五", "六", "日"].forEach(d => grid.append(h("div", { cls: "mny-cal-h", text: d })));
    const first = mm.clone().startOf("month");
    for (let i = 0; i < (first.isoWeekday() - 1); i++) grid.append(h("div", { cls: "mny-cal-c empty" }));
    for (let d = 1; d <= mm.daysInMonth(); d++) {
        const key = mm.clone().date(d).format("YYYY-MM-DD");
        const x = byDay[key];
        grid.append(h("button", {
            cls: `mny-cal-c l${x ? lvl(x.exp) : 0}` + (W.calDay === key ? " sel" : "") + (key === moment().format("YYYY-MM-DD") ? " today" : ""),
            onclick: () => { W.calDay = W.calDay === key ? null : key; renderAll(); },
            title: x ? `${key} 支出 ${money(x.exp)} 收入 ${money(x.inc)}` : key,
        }, [h("div", { cls: "d", text: String(d) }), x && x.exp > 0.004 ? h("div", { cls: "e", text: "−" + fmtShort(toBase(x.exp)) }) : null, x && x.inc > 0.004 ? h("div", { cls: "i", text: "+" + fmtShort(toBase(x.inc)) }) : null]));
    }
    card.append(grid);
    card.append(h("div", { cls: "mny-cal-legend" }, [h("span", { text: "支出少" }), ...[1, 2, 3, 4, 5].map(i => h("i", { cls: "l" + i })), h("span", { text: "多" })]));
    el.append(card);
    const s = summarize(TX.filter(t => t.ym === W.calMonth));
    el.append(h("div", { cls: "mny-hint", text: `${mm.format("M月")}支出 ${money(s.exp)} · 收入 ${money(s.inc)}` }));
    if (W.calDay && byDay[W.calDay]) dayGroups(byDay[W.calDay].tx, el);
    else if (W.calDay) el.append(h("div", { cls: "mny-empty", text: "这天没有记录" }));
}

// ───────────────────────── tab: 资产 ─────────────────────────
function accCard(a, onClick) {
    const bal = balanceOf(a);
    const sub = [];
    if (a.kind === "信用") {
        const s = daysUntil(a.statement_day), d = daysUntil(a.due_day);
        if (s !== null) sub.push(s === 0 ? "今天出账" : `${s}天后出账`);
        if (d !== null) sub.push(d === 0 ? "今天还款" : `${d}天后还款`);
        if (a.credit_limit && bal !== null) sub.push(`可用 ${fmt(a.credit_limit + bal, a.currency)}`);
    } else if (a.note) sub.push(a.note);
    let right;
    if (bal === null) right = h("div", { cls: "mny-acc-bal unset", text: "设置余额" });
    else right = h("div", { cls: "mny-acc-bal" }, [
        h("div", { text: a.kind === "信用" && bal < 0 ? `欠 ${fmt(-bal, a.currency)}` : fmt(bal, a.currency) }),
        a.currency !== BASE() ? h("div", { cls: "conv", text: `≈ ${money(toCNY(bal, a.currency))}` }) : null,
    ]);
    return h("div", { cls: "mny-row acc" + (a.hidden ? " muted" : ""), onclick: onClick }, [
        accIcon(a),
        h("div", { cls: "mny-row-main" }, [h("div", { cls: "mny-row-title", text: a.name }), h("div", { cls: "mny-row-sub", text: [a.kind === "信用" ? "信用账户" : "", ...sub].filter(Boolean).join(" · ") })]),
        right,
    ]);
}
function renderAssets(el) {
    let assets = 0, debts = 0, unset = 0;
    for (const a of ACCS.filter(x => !x.archived)) {
        const b = balanceOf(a);
        if (b === null) { unset++; continue; }
        const v = toCNY(b, a.currency);
        if (v >= 0) assets += v; else debts += -v;
    }
    el.append(h("div", { cls: "mny-card mny-hero" }, [
        h("div", { cls: "mny-hero-label", text: "净资产" }),
        h("div", { cls: "mny-hero-num", text: money(assets - debts) }),
        h("div", { cls: "mny-hero-row" }, [
            h("div", {}, [h("span", { text: "资产 " }), h("b", { text: money(assets) })]),
            h("div", {}, [h("span", { text: "负债 " }), h("b", { text: money(debts) })]),
        ]),
        h("div", { cls: "mny-hero-foot", text: `美元按 1 USD = ${rate()} CNY 折算` + (S.rate_updated ? `（${S.rate_updated}）` : "") }),
    ]));
    if (unset) el.append(h("div", { cls: "mny-hint warn", text: `有 ${unset} 个账户还没设置余额，没算进净资产。点进账户，用「调整余额」填上当前余额，之后的收支会自动从这个数往下算。` }));
    for (const [kind, title] of [["资金", "资金账户"], ["信用", "信用账户"]]) {
        const list = ACCS.filter(a => a.kind === kind && !a.archived && (W.showHidden || !a.hidden));
        if (!list.length) continue;
        const card = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: `${title}（${list.length}）` })]);
        list.forEach(a => card.append(accCard(a, () => openNote(a.path))));
        el.append(card);
    }
    const archived = ACCS.filter(a => a.archived);
    const nHidden = ACCS.filter(a => a.hidden && !a.archived).length;
    const foot = h("div", { cls: "mny-row-flex" });
    if (nHidden) foot.append(h("button", { cls: "mny-btn ghost", text: W.showHidden ? "不显示隐藏账户" : `显示隐藏账户（${nHidden}）`, onclick: () => { W.showHidden = !W.showHidden; renderAll(); } }));
    foot.append(h("button", { cls: "mny-btn", text: "＋ 添加账户", onclick: openAccountEditor }));
    el.append(foot);
    if (archived.length) {
        const card = h("details", { cls: "mny-card" }, [h("summary", { cls: "mny-card-title", text: `已归档（${archived.length}）` })]);
        archived.forEach(a => card.append(accCard(a, () => openNote(a.path))));
        el.append(card);
    }
}
function renderAccountPage(el, name) {
    const a = accByName(name);
    if (!a) { el.append(h("div", { cls: "mny-empty", text: "找不到这个账户" })); return; }
    const bal = balanceOf(a);
    const hero = h("div", { cls: "mny-card mny-hero" }, [
        h("div", { cls: "mny-acc-head" }, [accIcon(a), h("div", {}, [h("div", { cls: "mny-hero-label", text: `${a.kind === "信用" ? "信用账户" : "资金账户"} · ${a.currency}` }), h("div", { cls: "mny-hero-num", text: bal === null ? "未设置余额" : (a.kind === "信用" && bal < 0 ? `欠 ${fmt(-bal, a.currency)}` : fmt(bal, a.currency)) })])]),
    ]);
    if (bal !== null && a.currency !== "CNY") hero.append(h("div", { cls: "mny-hero-foot", text: `≈ ${fmt(toCNY(bal, a.currency), "CNY")}（1 USD = ${rate()} CNY）` }));
    if (a.balance_date) hero.append(h("div", { cls: "mny-hero-foot", text: `从 ${String(a.balance_date).replace("T", " ")} 的 ${fmt(num(a.balance), a.currency)} 往后推算` }));
    if (a.kind === "信用") {
        const s = daysUntil(a.statement_day), d = daysUntil(a.due_day);
        hero.append(h("div", { cls: "mny-hero-row small" }, [
            h("span", { text: a.statement_day ? `每月${a.statement_day}日出账${s !== null ? `（${s}天后）` : ""}` : "未设置出账日" }),
            h("span", { text: a.due_day ? `每月${a.due_day}日还款${d !== null ? `（${d}天后）` : ""}` : "未设置还款日" }),
            a.credit_limit ? h("span", { text: `额度 ${fmt(a.credit_limit, a.currency)}` }) : null,
        ]));
    }
    hero.append(h("div", { cls: "mny-row-flex" }, [
        h("button", { cls: "mny-btn", text: "调整余额", onclick: () => adjustBalance(a, bal) }),
        h("button", { cls: "mny-btn ghost", text: "编辑账户", onclick: () => openAccountEditor(a) }),
        h("button", { cls: "mny-btn ghost", text: a.hidden ? "取消隐藏" : "隐藏", onclick: async () => { await updateAccount(a.path, { hidden: !a.hidden }); rerender(500); } }),
        h("button", { cls: "mny-btn ghost", text: a.archived ? "取消归档" : "归档", onclick: async () => { await updateAccount(a.path, { archived: !a.archived }); rerender(500); } }),
        h("button", { cls: "mny-btn ghost", text: "＋ 记一笔", onclick: () => openEditor(null, { account: a.name }) }),
    ]));
    el.append(hero);
    const list = TX.filter(t => t.account === a.name || t.to_account === a.name);
    let inflow = 0, outflow = 0;
    const thisMonth = list.filter(t => t.ym === moment().format("YYYY-MM"));
    for (const t of thisMonth) { const d = delta(t, a.name); if (d > 0) inflow += d; else outflow -= d; }
    el.append(h("div", { cls: "mny-hint", text: `本月流入 ${fmt(inflow, a.currency)} · 流出 ${fmt(outflow, a.currency)} · 全部 ${list.length} 笔` }));
    dayGroups(list, el, { limit: 40, empty: "这个账户还没有记录" });
}
function adjustBalance(a, current) {
    modal("调整余额", box => {
        box.append(h("div", { cls: "mny-hint", text: `输入「${a.name}」现在的实际余额${a.kind === "信用" ? "（欠款填负数，比如 −1200）" : ""}。之后的收支会从这个数自动往下算。` }));
        const inp = h("input", { cls: "mny-input big", inputmode: "decimal", value: current === null ? "" : String(current) });
        box.append(h("label", { cls: "mny-field" }, [h("span", { text: `余额（${a.currency}）` }), inp]));
        setTimeout(() => inp.focus(), 50);
        return [{ label: "保存", primary: true, run: async () => {
            const v = calc(inp.value);
            if (isNaN(v)) { toast("请输入数字"); return false; }
            await updateAccount(a.path, { balance: v, balance_date: moment().format("YYYY-MM-DDTHH:mm:ss") });
            toast("余额已更新"); rerender(500);
        } }];
    });
}
function openAccountEditor(a) {
    const isNew = !a || !a.name;
    a = a && a.name ? a : { name: "", kind: "资金", currency: "CNY", icon: "", color: "#2a78d6", statement_day: null, due_day: null, credit_limit: null, note: "", order: ACCS.length + 1 };
    modal(isNew ? "添加账户" : "编辑账户", box => {
        const f = {};
        const field = (label, el) => box.append(h("label", { cls: "mny-field" }, [h("span", { text: label }), el]));
        f.name = h("input", { cls: "mny-input", value: a.name, placeholder: "比如 某银行储蓄卡", disabled: !isNew }); field("名称", f.name);
        f.kind = h("select", { cls: "mny-select" }, ["资金", "信用"].map(k => h("option", { value: k, text: k === "信用" ? "信用账户（信用卡、花呗、月付）" : "资金账户（储蓄卡、钱包、余额宝）", selected: a.kind === k }))); field("类型", f.kind);
        f.currency = h("select", { cls: "mny-select" }, ["CNY", "USD"].map(k => h("option", { value: k, text: k, selected: a.currency === k }))); field("币种", f.currency);
        f.icon = h("input", { cls: "mny-input", value: a.icon, placeholder: "一个字或 emoji" }); field("图标", f.icon);
        f.color = h("input", { cls: "mny-input", type: "color", value: a.color }); field("颜色", f.color);
        f.statement_day = h("input", { cls: "mny-input", inputmode: "numeric", value: a.statement_day || "", placeholder: "1–31，信用账户用" }); field("出账日", f.statement_day);
        f.due_day = h("input", { cls: "mny-input", inputmode: "numeric", value: a.due_day || "", placeholder: "1–31，信用账户用" }); field("还款日", f.due_day);
        f.credit_limit = h("input", { cls: "mny-input", inputmode: "decimal", value: a.credit_limit || "" }); field("额度", f.credit_limit);
        f.order = h("input", { cls: "mny-input", inputmode: "numeric", value: a.order || "" }); field("排序", f.order);
        f.note = h("input", { cls: "mny-input", value: a.note || "" }); field("备注", f.note);
        return [{ label: "保存", primary: true, run: async () => {
            const name = safeName(f.name.value);
            if (!f.name.value.trim()) { toast("请填写名称"); return false; }
            const data = { kind: f.kind.value, currency: f.currency.value, icon: f.icon.value || name.slice(0, 1), color: f.color.value,
                statement_day: num(f.statement_day.value) || null, due_day: num(f.due_day.value) || null, credit_limit: num(f.credit_limit.value) || null,
                order: num(f.order.value) || 99, note: f.note.value };
            if (isNew) {
                const path = `${P.acc}/${name}.md`;
                if (getFile(path)) { toast("已经有同名账户"); return false; }
                await ensureFolder(P.acc);
                const file = await app.vault.create(path, '\n```dataviewjs\nawait dv.view("System & Attachments/Scripts/money", { account: dv.current().file.name })\n```\n');
                await app.fileManager.processFrontMatter(file, fm => Object.assign(fm, data, { balance: 0, balance_date: moment().format("YYYY-MM-DDTHH:mm:ss") }));
                toast("账户已添加，记得设置余额");
            } else await updateAccount(a.path, data);
            rerender(500);
        } }];
    });
}

// ───────────────────────── tab: 预算 ─────────────────────────
function renderBudget(el) {
    const kind = W.budgetPeriod;
    el.append(seg([["week", "周预算"], ["month", "月预算"], ["year", "年预算"]], kind, v => { W.budgetPeriod = v; renderAll(); }, "wide"));
    const [a, b] = periodRange(kind, moment());
    const list = TX.filter(t => inRange(t, a, b));
    const used = list.reduce((s, t) => s + spendOf(t), 0);
    const B = S.budgets[kind];
    const total = num(B.total);
    const daysLeft = Math.max(1, b.diff(moment().startOf("day"), "days"));
    const card = h("div", { cls: "mny-card mny-hero" }, [
        h("div", { cls: "mny-hero-label", text: `${periodLabel(kind, a)} · 总预算` }),
        h("div", { cls: "mny-hero-num", text: total > 0 ? money(total - used) : "未设置" }),
        h("div", { cls: "mny-hero-row small" }, [
            h("span", { text: `已用 ${money(used)}` }),
            total > 0 ? h("span", { text: total - used >= 0 ? `日均可用 ${money((total - used) / daysLeft)}` : `超支 ${money(used - total)}` }) : null,
        ]),
    ]);
    if (total > 0) card.append(progress(used, total));
    const inp = h("input", { cls: "mny-input", inputmode: "decimal", placeholder: "总预算金额（人民币）", value: total || "" });
    card.append(h("div", { cls: "mny-row-flex" }, [inp, h("button", { cls: "mny-btn", text: "保存", onclick: async () => { const v = calc(inp.value) || 0; await saveSettings({ budgets: x => { x = x || {}; x[kind] = Object.assign({ cats: {} }, x[kind] || {}, { total: v }); return x; } }); toast("预算已保存"); rerender(500); } })]));
    el.append(card);

    const byCat = {};
    for (const t of list) byCat[catOf(t)] = (byCat[catOf(t)] || 0) + spendOf(t);
    const cc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "分类预算" })]);
    const cats = Object.entries(B.cats || {});
    if (!cats.length) cc.append(h("div", { cls: "mny-empty", text: "还没有分类预算。在下面选一个分类加上。" }));
    for (const [c, v] of cats) {
        const u = byCat[c] || 0, ci = catInfo("支出", c);
        cc.append(h("div", { cls: "mny-rank" }, [
            icon(ci.icon, catColor("支出", c)),
            h("div", { cls: "mny-rank-main" }, [
                h("div", { cls: "mny-rank-top" }, [h("span", { text: c }), h("span", { cls: "pct", text: u > v ? `超支 ${money(u - v)}` : `剩 ${money(v - u)}` }), h("span", { cls: "mny-rank-amt", text: `${money(u)} / ${money(v)}` })]),
                progress(u, v),
            ]),
            h("button", { cls: "mny-x", text: "×", title: "删除", onclick: async e => { e.stopPropagation(); await saveSettings({ budgets: x => { delete x[kind].cats[c]; return x; } }); rerender(500); } }),
        ]));
    }
    const sel = h("select", { cls: "mny-select" }, S.expense_categories.map(c => h("option", { value: c.name, text: `${c.icon} ${c.name}` })));
    const amt = h("input", { cls: "mny-input", inputmode: "decimal", placeholder: "金额" });
    cc.append(h("div", { cls: "mny-row-flex" }, [sel, amt, h("button", { cls: "mny-btn", text: "添加", onclick: async () => { const v = calc(amt.value); if (!(v > 0)) { toast("请输入金额"); return; } await saveSettings({ budgets: x => { x = x || {}; x[kind] = x[kind] || { total: 0, cats: {} }; x[kind].cats = x[kind].cats || {}; x[kind].cats[sel.value] = v; return x; } }); rerender(500); } })]));
    el.append(cc);
}

// ───────────────────────── tab: 生意 ─────────────────────────
function bizSum(list) {
    let cost = 0, rev = 0;
    for (const t of list) {
        if (t.exclude) continue;
        if (t.category === BIZ_EXP) cost += t.type === "退款" ? -t.cny : t.type === "支出" ? t.cny : 0;
        if (t.category === BIZ_INC) rev += t.type === "收入" ? t.cny : t.type === "退款" ? 0 : t.type === "支出" ? -t.cny : 0;
    }
    return { cost, rev, profit: rev - cost };
}
const recvOf = p => num((S.biz_receivable || {})[p]);
function renderBiz(el) {
    const all = TX.filter(isBiz);
    const tot = bizSum(all);
    const projs = [...new Set(all.map(t => t.project).filter(Boolean))];
    const owed = projs.map(p => [p, recvOf(p) - bizSum(all.filter(t => t.project === p)).rev]).filter(([p, v]) => recvOf(p) > 0 && v > 0.5);
    const month = bizSum(all.filter(t => t.ym === moment().format("YYYY-MM")));
    el.append(h("div", { cls: "mny-card mny-hero" }, [
        h("div", { cls: "mny-hero-label", text: "累计利润（回款 − 成本）" }),
        h("div", { cls: "mny-hero-num" + (tot.profit < 0 ? " neg" : ""), text: money(tot.profit) }),
        h("div", { cls: "mny-hero-row" }, [
            h("div", {}, [h("span", { text: "回款 " }), h("b", { text: money(tot.rev) })]),
            h("div", {}, [h("span", { text: "成本 " }), h("b", { text: money(tot.cost) })]),
            h("div", {}, [h("span", { text: "本月利润 " }), h("b", { text: money(month.profit) })]),
            h("div", {}, [h("span", { text: "待收回 " }), h("b", { text: money(owed.reduce((a, [, v]) => a + v, 0)) })]),
        ]),
        h("div", { cls: "mny-hero-foot", text: "生意的成本和回款不算进个人收支、统计和预算；账户余额照常变动。" }),
    ]));
    if (!all.length) { el.append(h("div", { cls: "mny-empty", text: "还没有生意记录。记一笔时选「生意成本」或「生意回款」分类，并填上项目。" })); return; }
    if (owed.length) {
        const oc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "待收回" })]);
        owed.forEach(([p, v]) => oc.append(h("div", { cls: "mny-subrow" }, [h("span", { text: p }), h("span", { cls: "mny-badge warn", text: `应收 ${money(recvOf(p))}` }), h("b", { text: money(v) })])));
        oc.append(h("div", { cls: "mny-hint", text: "收到钱后记一笔收入「生意回款」，项目选这家店，待收会自动减掉。" }));
        el.append(oc);
    }
    // by project
    const groups = {};
    for (const t of all) (groups[t.project || ""] = groups[t.project || ""] || []).push(t);
    const keys = Object.keys(groups).sort((a, b) => (a === "") - (b === "") || Math.max(...groups[b].map(x => x.ts)) - Math.max(...groups[a].map(x => x.ts)));
    const pc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "按项目" })]);
    for (const k of keys) {
        const g = groups[k], s = bizSum(g), open = W.openProj === k;
        const last = moment(Math.max(...g.map(x => x.ts)));
        pc.append(h("div", { cls: "mny-rank" + (open ? " open" : ""), onclick: () => { W.openProj = open ? null : k; renderAll(); } }, [
            icon(k ? "💼" : "❔", k ? "#2a78d6" : "#8a8a8a"),
            h("div", { cls: "mny-rank-main" }, [
                h("div", { cls: "mny-rank-top" }, [h("span", { text: k || "未指定项目" }), h("span", { cls: "pct", text: `${g.length} 笔 · 最近 ${last.format("M/D")}` }), h("span", { cls: "mny-rank-amt" + (s.profit < 0 ? " neg" : " pos"), text: (s.profit >= 0 ? "+" : "") + money(s.profit) })]),
                h("div", { cls: "mny-row-sub", text: `回款 ${money(s.rev)} · 成本 ${money(s.cost)}${s.rev > 0 ? ` · 利润率 ${(s.profit / s.rev * 100).toFixed(0)}%` : ""}${recvOf(k) > 0 ? (recvOf(k) - s.rev > 0.5 ? ` · 待收 ${money(recvOf(k) - s.rev)}（收齐后利润 ${money(recvOf(k) - s.cost)}）` : " · 已收齐") : s.rev === 0 && s.cost > 0 ? " · 还没回款" : ""}` }),
            ]),
        ]));
        if (open) {
            const box = h("div", { cls: "mny-rank-detail" });
            if (!k) box.append(h("div", { cls: "mny-hint", text: "这些还没填项目。点开一笔，在「生意 · 项目」里选或填一个项目名。" }));
            else {
                const inp = h("input", { cls: "mny-input", inputmode: "decimal", placeholder: "买家总共应付多少", value: recvOf(k) || "" });
                inp.addEventListener("click", e => e.stopPropagation());
                box.append(h("div", { cls: "mny-row-flex" }, [h("span", { cls: "mny-label", text: "应收金额" }), inp, h("button", { cls: "mny-btn small", text: "保存", onclick: async e => { e.stopPropagation(); const v = calc(inp.value) || 0; await saveSettings({ biz_receivable: x => { x = x && typeof x === "object" ? x : {}; if (v) x[k] = v; else delete x[k]; return x; } }); toast("已保存"); rerender(400); } })]));
            }
            g.forEach(t => box.append(txRow(t)));
            pc.append(box);
        }
    }
    el.append(pc);
    // by month
    const months = [...new Set(all.map(t => t.ym))].sort().reverse();
    const mc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "按月" })]);
    mc.append(h("div", { cls: "mny-subrow head" }, [h("span", { text: "月份" }), h("span", { cls: "num", text: "回款" }), h("span", { cls: "num", text: "成本" }), h("span", { cls: "num", text: "利润" })]));
    for (const m of months) {
        const s = bizSum(all.filter(t => t.ym === m));
        mc.append(h("div", { cls: "mny-subrow" }, [h("span", { text: moment(m + "-01").format("YYYY年M月") }), h("span", { cls: "num", text: money(s.rev) }), h("span", { cls: "num", text: money(s.cost) }), h("b", { cls: "num" + (s.profit < 0 ? " neg" : ""), text: money(s.profit) })]));
    }
    el.append(mc);
    el.append(h("div", { cls: "mny-hint", text: "记法：付给供应商 → 支出「生意成本」；买家打款 → 收入「生意回款」。同一单的成本和回款填同一个项目名，就能看到这一单赚了多少。" }));
}

// ───────────────────────── tab: 设置 ─────────────────────────
function renderSettings(el) {
    // exchange rate
    const rc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "汇率与币种" })]);
    const rInp = h("input", { cls: "mny-input", inputmode: "decimal", value: String(rate()) });
    rc.append(h("div", { cls: "mny-hint", text: `1 USD = ? CNY。用来把美元账户和美元消费折算成人民币。${S.rate_updated ? `上次更新：${S.rate_updated}。` : ""}${S.auto_rate !== false ? "每天打开时自动更新。" : ""}换汇转账用的是每笔自己记的汇率，不受这里影响。` }));
    rc.append(h("div", { cls: "mny-row-flex" }, [
        rInp,
        h("button", { cls: "mny-btn", text: "保存", onclick: async () => { const v = calc(rInp.value); if (!(v > 0)) return toast("请输入汇率"); await saveSettings({ usd_cny: v, rate_updated: moment().format("YYYY-MM-DD") }); toast("汇率已保存"); rerender(500); } }),
        h("button", { cls: "mny-btn ghost", text: "获取最新汇率", onclick: () => refreshRate(true) }),
    ]));
    rc.append(h("div", { cls: "mny-row-flex" }, [
        h("span", { cls: "mny-label", text: "显示币种" }),
        seg([["CNY", "人民币 ¥"], ["USD", "美元 $"]], BASE(), async v => { await saveSettings({ base_currency: v }); rerender(400); }),
        h("label", { cls: "mny-check" }, [h("input", { type: "checkbox", checked: S.auto_rate !== false, onchange: async e => { await saveSettings({ auto_rate: e.target.checked }); rerender(400); } }), "每天自动更新汇率"]),
    ]));
    el.append(rc);

    // categories
    for (const [key, title, type] of [["expense_categories", "支出分类", "支出"], ["income_categories", "收入分类", "收入"]]) {
        const cc = h("details", { cls: "mny-card" }, [h("summary", { cls: "mny-card-title", text: `${title}（${(S[key] || []).length}）` })]);
        (S[key] || []).forEach((c, ci) => {
            const subs = h("div", { cls: "mny-chips" }, (c.subs || []).map((sb, si) => h("span", { cls: "mny-chip static" }, [sb, h("button", { cls: "mny-x", text: "×", title: "删除子分类", onclick: async () => { await saveSettings({ [key]: l => { l[ci].subs.splice(si, 1); return l; } }); rerender(400); } })])));
            const add = h("input", { cls: "mny-input small", placeholder: "＋ 子分类" });
            add.addEventListener("keydown", async e => { if (e.key === "Enter" && add.value.trim()) { const v = add.value.trim(); await saveSettings({ [key]: l => { l[ci].subs = l[ci].subs || []; l[ci].subs.push(v); return l; } }); rerender(400); } });
            subs.append(add);
            cc.append(h("div", { cls: "mny-catedit" }, [
                icon(c.icon, catColor(type, c.name)),
                h("div", { cls: "grow" }, [h("div", { cls: "mny-row-title", text: c.name }), subs]),
                h("button", { cls: "mny-x", text: "×", title: "删除分类（已有账单不受影响）", onclick: async () => { await saveSettings({ [key]: l => { l.splice(ci, 1); return l; } }); rerender(400); } }),
            ]));
        });
        const nIcon = h("input", { cls: "mny-input small", placeholder: "图标", style: { width: "4.5em" } });
        const nName = h("input", { cls: "mny-input small", placeholder: "新分类名称" });
        cc.append(h("div", { cls: "mny-row-flex" }, [nIcon, nName, h("button", { cls: "mny-btn", text: "添加分类", onclick: async () => { if (!nName.value.trim()) return; await saveSettings({ [key]: l => { l = l || []; l.push({ name: nName.value.trim(), icon: nIcon.value.trim() || "•", subs: [] }); return l; } }); rerender(400); } })]));
        el.append(cc);
    }

    // templates & recurring
    const tc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "记账模板" })]);
    if (!S.templates.length) tc.append(h("div", { cls: "mny-hint", text: "在记一笔的窗口里点「存为模板」，以后一点就能填好。" }));
    S.templates.forEach((tp, i) => tc.append(h("div", { cls: "mny-subrow" }, [h("span", { cls: "grow", text: `${tp.name} · ${tp.data.type} ${tp.data.amount ? fmt(tp.data.amount, tp.data.currency || "CNY") : ""} · ${tp.data.account || ""}` }), h("button", { cls: "mny-x", text: "×", onclick: async () => { await saveSettings({ templates: l => { l.splice(i, 1); return l; } }); rerender(400); } })])));
    el.append(tc);
    const pc = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "周期记账（每月自动记入）" })]);
    if (!S.recurring.length) pc.append(h("div", { cls: "mny-hint", text: "打开一笔账单，点「设为每月周期」，比如宠物医保、会员订阅。到日子打开这个页面时会自动记一笔。" }));
    S.recurring.forEach((r, i) => pc.append(h("div", { cls: "mny-subrow" }, [h("span", { cls: "grow", text: `每月${r.day}日 · ${r.name} · ${fmt(r.data.amount, r.data.currency || "CNY")} · ${r.data.account}` }), h("button", { cls: "mny-x", text: "×", onclick: async () => { await saveSettings({ recurring: l => { l.splice(i, 1); return l; } }); rerender(400); } })])));
    el.append(pc);

    // export
    const ec = h("div", { cls: "mny-card" }, [h("div", { cls: "mny-card-title", text: "导出与表格" })]);
    ec.append(h("div", { cls: "mny-hint", text: "导出全部账单为 CSV（Excel 可直接打开），保存在 50 Money/Personal/导出。也可以打开「账单.base」用表格方式批量修改。" }));
    ec.append(h("div", { cls: "mny-row-flex" }, [
        h("button", { cls: "mny-btn", text: "导出 CSV", onclick: exportCSV }),
        h("button", { cls: "mny-btn ghost", text: "打开账单表格", onclick: () => openNote(`${ROOT}/账单.base`) }),
        h("button", { cls: "mny-btn ghost", text: "打开设置笔记", onclick: () => openNote(P.settings) }),
    ]));
    el.append(ec);
}
async function exportCSV() {
    const cols = ["日期", "类型", "金额", "币种", "折合人民币", "分类", "子分类", "账户", "转入账户", "转入金额", "转入币种", "汇率", "手续费", "商家", "商品", "备注", "待确认", "来源", "笔记"];
    const q = v => { const s = String(v ?? ""); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const rows = [...TX].sort((a, b) => a.ts - b.ts).map(t => [t.m.format("YYYY-MM-DD HH:mm"), t.type, t.amount, t.currency, r2(t.cny), t.category, t.sub, t.account, t.to_account, t.to_amount ?? "", t.to_currency || "", t.rate || "", t.fee || "", t.merchant, t.item, t.note, t.review ? "是" : "", t.source, t.name].map(q).join(","));
    await ensureFolder(P.exp);
    const path = `${P.exp}/账单-${moment().format("YYYYMMDD-HHmm")}.csv`;
    await app.vault.create(path, "﻿" + [cols.join(","), ...rows].join("\n"));
    toast(`已导出 ${rows.length} 笔 → ${path}`);
}

// ───────────────────────── modal + editor ─────────────────────────
function modal(title, build) {
    const ov = h("div", { cls: "mny-overlay" });
    const box = h("div", { cls: "mny mny-modal", role: "dialog", "aria-label": title });
    const close = () => { ov.remove(); document.removeEventListener("keydown", onKey, true); };
    const onKey = e => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
    document.addEventListener("keydown", onKey, true);
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    box.append(h("div", { cls: "mny-modal-head" }, [h("div", { cls: "mny-modal-title", text: title }), h("button", { cls: "mny-x big", text: "×", onclick: close, "aria-label": "关闭" })]));
    const body = h("div", { cls: "mny-modal-body" });
    box.append(body);
    const actions = build(body, close) || [];
    if (actions.length) {
        const foot = h("div", { cls: "mny-modal-foot" });
        for (const act of actions) {
            const btn = h("button", { cls: "mny-btn" + (act.primary ? "" : act.danger ? " danger" : " ghost"), text: act.label });
            btn.addEventListener("click", async () => {
                btn.disabled = true;
                try { const r = await act.run(); if (r !== false && !act.keepOpen) close(); }
                catch (e) { console.error(e); toast("出错了：" + e.message); }
                btn.disabled = false;
            });
            foot.append(btn);
        }
        box.append(foot);
    }
    ov.append(box);
    document.body.append(ov);
    return close;
}

function openEditor(t, preset = {}) {
    const isNew = !t;
    const st = isNew ? Object.assign({
        type: "支出", amount: "", currency: "CNY", category: "", sub: "", account: W.acct || (ACCS.find(a => !a.archived && !a.hidden) || {}).name || "",
        to_account: "", to_amount: "", rate: "", fee: "", merchant: "", note: "", date: moment().format("YYYY-MM-DDTHH:mm"), exclude: false, reimburse: "", review: false,
    }, preset) : {
        type: t.type, amount: t.amount, currency: t.currency, category: t.category, sub: t.sub, account: t.account, to_account: t.to_account,
        to_amount: t.to_amount ?? "", rate: t.rate || "", fee: t.fee || "", merchant: t.merchant, item: t.item, note: t.note,
        date: t.m.format("YYYY-MM-DDTHH:mm"), exclude: t.exclude, reimburse: t.reimburse, review: t.review, refund_of: t.raw.refund_of,
        aa: t.aa, aa_expect: t.aa_expect || "", aa_with: t.aa_with, project: t.project, origType: t.type, origCategory: t.category, origSub: t.sub,
    };
    const title = isNew ? "记一笔" : t.type === "退款" ? (t.aa ? "AA 收款" : "退款") : t.type === "转账" ? (t.merchant && t.merchant.startsWith("换汇") ? "换汇 / 转账" : "转账") : "账单详情";
    modal(title, (body, close) => {
        const draw = () => {
            body.empty ? body.empty() : (body.innerHTML = "");
            if (isNew && S.templates.length) body.append(h("div", { cls: "mny-chips tpl" }, S.templates.map(tp => h("button", { cls: "mny-chip", text: "⚡ " + tp.name, onclick: () => { Object.assign(st, tp.data, { date: st.date }); draw(); } }))));
            if (st.type !== "退款") body.append(seg([["支出", "支出"], ["收入", "收入"], ["转账", "转账"]], st.type, v => { st.type = v; if (v !== "转账") { const cl = catList(v); if (!cl.find(c => c.name === st.category)) { st.category = ""; st.sub = ""; } } draw(); }, "wide"));
            // amount
            const accA = accByName(st.account);
            if (st.type === "转账" && accA) st.currency = accA.currency;
            const amt = h("input", { cls: "mny-input big", inputmode: "decimal", placeholder: "0.00", value: st.amount === "" ? "" : String(st.amount) });
            amt.addEventListener("input", () => { st.amount = amt.value; syncTo(); });
            amt.addEventListener("blur", () => { const v = calc(amt.value); if (!isNaN(v)) { st.amount = v; amt.value = String(v); syncTo(); } });
            const cur = h("select", { cls: "mny-select cur", disabled: st.type === "转账" }, ["CNY", "USD"].map(c => h("option", { value: c, text: c === "CNY" ? "¥ CNY" : "$ USD", selected: st.currency === c })));
            cur.addEventListener("change", () => { st.currency = cur.value; draw(); });
            body.append(h("div", { cls: "mny-amount" }, [amt, cur]));
            if (st.currency === "USD" && st.type !== "转账") body.append(h("div", { cls: "mny-hint", text: `≈ ${fmt(toCNY(calc(st.amount) || 0, "USD"), "CNY")}（按 ${rate()}）` }));

            if (st.type === "转账") {
                const accSel = (val, on) => { const s = h("select", { cls: "mny-select" }, [h("option", { value: "", text: "选择账户" }), ...ACCS.filter(a => !a.archived || a.name === val).map(a => h("option", { value: a.name, text: `${a.name}（${a.currency}）`, selected: a.name === val }))]); s.addEventListener("change", () => on(s.value)); return s; };
                body.append(h("div", { cls: "mny-transfer" }, [
                    h("label", { cls: "mny-field" }, [h("span", { text: "从" }), accSel(st.account, v => { st.account = v; draw(); })]),
                    h("div", { cls: "mny-arrow", text: "→" }),
                    h("label", { cls: "mny-field" }, [h("span", { text: "到" }), accSel(st.to_account, v => { st.to_account = v; draw(); })]),
                ]));
                const accB = accByName(st.to_account);
                const fx = accA && accB && accA.currency !== accB.currency;
                const toInp = h("input", { cls: "mny-input", inputmode: "decimal", value: st.to_amount === "" ? "" : String(st.to_amount), placeholder: fx ? `到账金额（${accB.currency}）` : "到账金额（默认同上）" });
                const rInp = h("input", { cls: "mny-input", inputmode: "decimal", value: st.rate ? String(st.rate) : "", placeholder: String(rate()) });
                var syncTo = () => {
                    if (!fx) return;
                    const a = calc(st.amount), r = num(st.rate) || rate();
                    if (isNaN(a)) return;
                    st.to_amount = r2(accA.currency === "USD" ? a * r : a / r);
                    toInp.value = String(st.to_amount);
                };
                toInp.addEventListener("input", () => { st.to_amount = toInp.value; });
                toInp.addEventListener("blur", () => { // typing the received amount recalculates the rate
                    const a = calc(st.amount), b = calc(toInp.value);
                    if (fx && a > 0 && b > 0) { st.rate = Math.round((accA.currency === "USD" ? b / a : a / b) * 10000) / 10000; rInp.value = String(st.rate); }
                });
                rInp.addEventListener("input", () => { st.rate = rInp.value; syncTo(); });
                body.append(h("label", { cls: "mny-field" }, [h("span", { text: "到账金额" }), toInp]));
                if (fx) {
                    body.append(h("label", { cls: "mny-field" }, [h("span", { text: "汇率" }), h("div", { cls: "mny-row-flex tight" }, [h("span", { cls: "mny-label", text: "1 USD =" }), rInp, h("span", { cls: "mny-label", text: "CNY" }), h("button", { cls: "mny-btn ghost small", text: "用当前汇率", onclick: () => { st.rate = rate(); rInp.value = String(st.rate); syncTo(); } })])]));
                    body.append(h("div", { cls: "mny-hint", text: "改汇率会重算到账金额；直接改到账金额会反推汇率。" }));
                }
                const fee = h("input", { cls: "mny-input", inputmode: "decimal", value: st.fee || "", placeholder: "0" });
                fee.addEventListener("input", () => (st.fee = fee.value));
                body.append(h("label", { cls: "mny-field" }, [h("span", { text: "手续费" }), fee]));
            } else {
                var syncTo = () => { };
                // category grid
                const type = st.type === "退款" ? "支出" : st.type;
                const cl = catList(type);
                body.append(h("div", { cls: "mny-catgrid" }, cl.map(c => h("button", { cls: "mny-cat" + (st.category === c.name ? " on" : ""), onclick: () => { st.category = c.name; if (!(c.subs || []).includes(st.sub)) st.sub = ""; draw(); } }, [icon(c.icon, catColor(type, c.name)), h("span", { text: c.name })]))));
                const ci = cl.find(c => c.name === st.category);
                if (ci && (ci.subs || []).length) body.append(h("div", { cls: "mny-chips" }, ci.subs.map(sb => h("button", { cls: "mny-chip" + (st.sub === sb ? " on" : ""), text: sb, onclick: () => { st.sub = st.sub === sb ? "" : sb; draw(); } }))));
                const accSel = h("select", { cls: "mny-select" }, [h("option", { value: "", text: "选择账户" }), ...ACCS.filter(a => !a.archived || a.name === st.account).map(a => h("option", { value: a.name, text: `${a.name}（${a.currency}）`, selected: a.name === st.account }))]);
                accSel.addEventListener("change", () => { st.account = accSel.value; const a = accByName(st.account); if (a && a.currency !== st.currency) { st.currency = a.currency; draw(); } });
                body.append(h("label", { cls: "mny-field" }, [h("span", { text: "账户" }), accSel]));
                if (st.category === BIZ_EXP || st.category === BIZ_INC) body.append(projectBox());
                else if (st.type === "支出") body.append(aaBox());
                if (st.type === "收入" || (st.type === "退款" && st.aa)) body.append(aaLinkBox());
            }
            const dt = h("input", { cls: "mny-input", type: "datetime-local", value: st.date });
            dt.addEventListener("change", () => (st.date = dt.value));
            body.append(h("label", { cls: "mny-field" }, [h("span", { text: "时间" }), dt]));
            const mer = h("input", { cls: "mny-input", value: st.merchant || "", placeholder: st.type === "转账" ? "比如 换汇 · 某某" : "商家（可选）" });
            mer.addEventListener("input", () => (st.merchant = mer.value));
            body.append(h("label", { cls: "mny-field" }, [h("span", { text: st.type === "转账" ? "名称" : "商家" }), mer]));
            if (st.item) body.append(h("div", { cls: "mny-hint", text: "商品：" + st.item }));
            const note = h("textarea", { cls: "mny-input", rows: 2, placeholder: "备注" });
            note.value = st.note || "";
            note.addEventListener("input", () => (st.note = note.value));
            body.append(h("label", { cls: "mny-field" }, [h("span", { text: "备注" }), note]));
            const opts = h("div", { cls: "mny-row-flex wrap" });
            if (st.type !== "转账") {
                opts.append(h("label", { cls: "mny-check" }, [h("input", { type: "checkbox", checked: !!st.exclude, onchange: e => (st.exclude = e.target.checked) }), "不计入收支"]));
                if (st.type === "支出") {
                    const rb = h("select", { cls: "mny-select small" }, [["", "不报销"], ["待报销", "待报销"], ["已报销", "已报销"]].map(([v, l]) => h("option", { value: v, text: l, selected: st.reimburse === v })));
                    rb.addEventListener("change", () => (st.reimburse = rb.value));
                    opts.append(rb);
                }
            }
            if (!isNew) opts.append(h("label", { cls: "mny-check" }, [h("input", { type: "checkbox", checked: !!st.review, onchange: e => (st.review = e.target.checked) }), "待确认"]));
            body.append(opts);
            if (!isNew) {
                const more = h("div", { cls: "mny-row-flex wrap" });
                if (t.refund_of) more.append(h("button", { cls: "mny-btn ghost small", text: "查看原账单", onclick: () => { const o = TX.find(x => x.path === t.refund_of); if (o) { close(); openEditor(o); } } }));
                if (t.type === "支出") {
                    const refunds = TX.filter(x => x.refund_of === t.path);
                    if (refunds.length) more.append(h("span", { cls: "mny-label", text: `已退款 ${refunds.length} 笔，共 ${fmt(refunds.reduce((s, x) => s + x.amount, 0), t.currency)}` }));
                    more.append(h("button", { cls: "mny-btn ghost small", text: "＋ 退款", onclick: () => { close(); openEditor(null, { type: "退款", category: t.category, sub: t.sub, account: t.account, currency: t.currency, merchant: t.merchant, amount: r2(t.amount - (REFUNDED[t.path] || 0) / (t.cny / t.amount || 1)), refund_of: `[[${t.name}]]` }); } }));
                }
                more.append(h("button", { cls: "mny-btn ghost small", text: "复制一笔", onclick: () => { close(); openEditor(null, Object.assign({}, st, { date: moment().format("YYYY-MM-DDTHH:mm"), review: false, refund_of: undefined })); } }));
                more.append(h("button", { cls: "mny-btn ghost small", text: "打开笔记", onclick: () => { close(); openNote(t.path); } }));
                body.append(more);
            }
            const tools = h("div", { cls: "mny-row-flex wrap" }, [
                h("button", { cls: "mny-btn ghost small", text: "存为模板", onclick: async () => { const name = (st.merchant || st.sub || st.category || st.type).trim(); await saveSettings({ templates: l => { l = Array.isArray(l) ? l : []; l.push({ name, data: dataOf(true) }); return l; } }); toast(`已存为模板「${name}」`); } }),
                h("button", { cls: "mny-btn ghost small", text: "设为每月周期", onclick: async () => { const d = moment(st.date).date(); const name = (st.merchant || st.sub || st.category || st.type).trim(); await saveSettings({ recurring: l => { l = Array.isArray(l) ? l : []; l.push({ id: Date.now().toString(36), name, day: d, start: moment().add(1, "month").format("YYYY-MM"), data: dataOf(true) }); return l; } }); toast(`每月${d}日会自动记「${name}」，从下个月开始`); } }),
            ]);
            body.append(tools);
            setTimeout(() => { if (isNew && !st.amount) amt.focus(); }, 30);
        };
        function projectBox() {
            const box = h("div", { cls: "mny-aa" });
            const inp = h("input", { cls: "mny-input", placeholder: "项目名，比如 软木板、陶罐", value: st.project || "" });
            inp.addEventListener("input", () => (st.project = inp.value));
            const known = [...new Set(TX.filter(x => isBiz(x) && x.project).map(x => x.project))];
            box.append(h("div", { cls: "mny-aa-head" }, [h("span", { text: "生意 · 项目" }), h("span", { cls: "mny-label", text: "不算进个人收支和预算，在「生意」页看利润" })]));
            if (known.length) box.append(h("div", { cls: "mny-chips" }, known.map(p => h("button", { cls: "mny-chip" + (st.project === p ? " on" : ""), text: p, onclick: () => { st.project = p; draw(); } }))));
            box.append(inp);
            return box;
        }
        function aaBox() { // I paid for everyone; how much should friends pay back?
            const box = h("div", { cls: "mny-aa" });
            const total = () => calc(st.amount) || 0;
            const inp = h("input", { cls: "mny-input", inputmode: "decimal", placeholder: "0", value: st.aa_expect ? String(st.aa_expect) : "" });
            inp.addEventListener("input", () => (st.aa_expect = inp.value));
            const who = h("input", { cls: "mny-input", placeholder: "和谁（可选）", value: st.aa_with || "" });
            who.addEventListener("input", () => (st.aa_with = who.value));
            box.append(h("div", { cls: "mny-aa-head" }, [h("span", { text: "AA · 别人应还" }), h("span", { cls: "mny-label", text: "先垫付、之后朋友转回来的，填这里" })]));
            box.append(h("div", { cls: "mny-chips" }, [2, 3, 4, 5].map(n => h("button", { cls: "mny-chip", text: `${n}人平分`, onclick: () => { st.aa_expect = r2(total() * (n - 1) / n); inp.value = String(st.aa_expect); } })).concat([h("button", { cls: "mny-chip", text: "清除", onclick: () => { st.aa_expect = ""; inp.value = ""; } })])));
            box.append(h("div", { cls: "mny-row-flex tight" }, [inp, who]));
            if (!isNew && t.aa_expect) {
                const got = AARECV[t.path] || 0, left = aaLeft(t);
                const recs = TX.filter(x => x.aa && x.refund_ofs.includes(t.path));
                box.append(h("div", { cls: "mny-hint", text: `已收回 ${money(got)}${recs.length ? `（${recs.map(x => x.merchant || x.m.format("M/D")).join("、")}）` : ""} · ${left > 0.5 ? `还差 ${money(left)}` : "已收齐"} · 我实际付 ${money(t.cny - got)}` }));
            }
            return box;
        }
        function aaLinkBox() { // this money is a friend paying me back
            const box = h("div", { cls: "mny-aa" });
            const links = [].concat(st.refund_of || []).map(x => String(x).replace(/^\[\[|\]\]$/g, ""));
            if (st.aa && links.length) {
                const names = links.map(n => { const o = TX.find(x => x.name === n); return o ? `${o.m.format("M/D")} ${o.merchant || o.category} ${money(o.cny)}` : n; });
                box.append(h("div", { cls: "mny-aa-head" }, [h("span", { text: "AA 收款 · 抵扣" }), h("span", { cls: "mny-label", text: "这笔钱会从下面的支出里扣掉，只算你自己那份" })]));
                names.forEach(n => box.append(h("div", { cls: "mny-subrow" }, [h("span", { text: "↩ " + n })])));
                box.append(h("div", { cls: "mny-row-flex" }, [
                    h("button", { cls: "mny-btn ghost small", text: "改关联", onclick: () => pickAA(st, draw) }),
                    h("button", { cls: "mny-btn ghost small", text: "取消关联（改回收入）", onclick: () => { st.aa = false; st.refund_of = undefined; st.type = "收入"; st.category = st.origType === "收入" ? st.origCategory : "其他"; st.sub = st.origType === "收入" ? st.origSub : "个人转账"; draw(); } }),
                ]));
            } else {
                box.append(h("div", { cls: "mny-row-flex" }, [h("span", { cls: "mny-label", text: "朋友 AA 转给你的？" }), h("button", { cls: "mny-btn small", text: "关联到 AA 账单…", onclick: () => pickAA(st, draw) })]));
            }
            return box;
        }
        const dataOf = forTemplate => {
            const amount = calc(st.amount);
            const d = {
                type: st.type, amount, currency: st.currency,
                category: st.type === "转账" ? null : st.category || null, subcategory: st.type === "转账" ? null : st.sub || null,
                account: st.account || null, merchant: (st.merchant || "").trim() || null, note: (st.note || "").trim() || null,
                exclude: st.type !== "转账" && !!st.exclude, reimburse: st.type === "支出" ? st.reimburse || null : null,
            };
            if (st.type === "转账") {
                const a = accByName(st.account), b = accByName(st.to_account);
                d.to_account = st.to_account || null;
                d.to_amount = st.to_amount === "" || st.to_amount == null ? amount : calc(st.to_amount);
                if (a && b && a.currency !== b.currency) { d.to_currency = b.currency; d.rate = num(st.rate) || rate(); }
                else { d.to_currency = null; d.rate = null; }
                d.fee = calc(st.fee) || null;
            } else { d.to_account = d.to_amount = d.to_currency = d.rate = d.fee = null; }
            d.refund_of = st.refund_of && [].concat(st.refund_of).length ? (Array.isArray(st.refund_of) && st.refund_of.length === 1 ? st.refund_of[0] : st.refund_of) : null;
            d.aa = st.type === "退款" && st.aa ? true : null;
            d.aa_expect = st.type === "支出" ? (calc(st.aa_expect) || null) : null;
            d.aa_with = st.type === "支出" && d.aa_expect ? (st.aa_with || "").trim() || null : null;
            d.project = (st.category === BIZ_EXP || st.category === BIZ_INC) && st.type !== "转账" ? (st.project || "").trim() || null : null;
            if (d.project) { d.aa_expect = null; d.aa_with = null; }
            if (!forTemplate) { d.date = st.date; d.review = !!st.review; }
            return d;
        };
        const validate = d => {
            if (!(d.amount > 0)) { toast("请输入金额"); return false; }
            if (!d.account) { toast("请选择账户"); return false; }
            if (d.type === "转账" && !d.to_account) { toast("请选择转入账户"); return false; }
            if (d.type === "转账" && d.to_account === d.account) { toast("转出和转入不能是同一个账户"); return false; }
            if (d.type !== "转账" && !d.category) { toast("请选一个分类"); return false; }
            return true;
        };
        draw();
        const acts = [];
        if (!isNew) acts.push({ label: "删除", danger: true, run: async () => { if (!confirmInline(body)) return false; await deleteTx(t.path); toast("已删除（在系统回收站里）"); rerender(600); } });
        if (isNew) acts.push({ label: "再记一笔", keepOpen: true, run: async () => { const d = dataOf(); if (!validate(d)) return false; await createTx(d); toast("已记录"); st.amount = ""; st.note = ""; st.merchant = ""; st.to_amount = ""; draw(); rerender(800); } });
        if (!isNew && t.review) acts.push({ label: "确认", run: async () => { const d = dataOf(); if (!validate(d)) return false; d.review = false; await updateTx(t.path, d); toast("已确认"); rerender(500); } });
        acts.push({ label: "保存", primary: true, run: async () => { const d = dataOf(); if (!validate(d)) return false; if (isNew) await createTx(d); else await updateTx(t.path, d); toast(isNew ? "已记录" : "已保存"); rerender(600); } });
        return acts;
    });
}
// Pick which bill(s) a friend's transfer is paying back. One payment can cover several bills.
function pickAA(st, redraw) {
    const payment = calc(st.amount) || 0;
    const when = moment(st.date);
    const chosen = new Set([].concat(st.refund_of || []).map(x => String(x).replace(/^\[\[|\]\]$/g, "")));
    modal("这笔钱在还哪笔账？", (body, close) => {
        body.append(h("div", { cls: "mny-hint", text: `收到 ${fmt(payment, st.currency)}。勾选它对应的支出（可以多选，比如几晚酒店一起转的），会按各笔「别人应还」的比例分摊；没填的按金额分摊。` }));
        const q = h("input", { cls: "mny-input", type: "search", placeholder: "搜索商家 / 分类" });
        body.append(q);
        const sumEl = h("div", { cls: "mny-hint" });
        const listEl = h("div", {});
        body.append(listEl, sumEl);
        const pool = TX.filter(x => x.type === "支出" && x.ts <= when.valueOf() + 864e5 && when.diff(x.m, "days") <= 120);
        const score = x => { // owed AA bills first, then bills close in time to the payment, then amounts that fit
            const left = aaLeft(x);
            if (left > 0.5) return Math.abs(left - payment) / Math.max(payment, 1) * 0.5;
            const days = Math.abs(when.diff(x.m, "hours")) / 24;
            const near = Math.min(...[2, 3, 4].map(n => Math.abs(x.cny * (n - 1) / n - payment))) / Math.max(payment, 1);
            return 1 + days / 7 + Math.min(near, 1) * 0.6 + (x.cny < payment * 0.3 ? 1 : 0);
        };
        const draw = () => {
            listEl.innerHTML = "";
            const k = q.value.trim().toLowerCase();
            let rows = pool.filter(x => !k || [x.merchant, x.item, x.category, x.sub, x.note].join(" ").toLowerCase().includes(k));
            rows = rows.sort((a, b) => (chosen.has(b.name) - chosen.has(a.name)) || score(a) - score(b)).slice(0, 40);
            for (const x of rows) {
                const left = aaLeft(x);
                const cb = h("input", { type: "checkbox", checked: chosen.has(x.name), onchange: e => { e.target.checked ? chosen.add(x.name) : chosen.delete(x.name); sum(); } });
                const ci = catInfo("支出", x.category);
                listEl.append(h("label", { cls: "mny-pick" }, [cb, icon(ci.icon, catColor("支出", x.category)),
                    h("div", { cls: "mny-row-main" }, [h("div", { cls: "mny-row-title" }, [`${x.sub || x.category} · ${x.merchant || ""}`, left > 0.5 ? h("span", { cls: "mny-badge warn", text: `待收 ${money(left)}` }) : null]), h("div", { cls: "mny-row-sub", text: `${x.m.format("M月D日 HH:mm")} · ${x.account}` })]),
                    h("div", { cls: "mny-row-amt", text: fmt(-x.amount, x.currency) })]));
            }
        };
        const sum = () => {
            const sel = pool.filter(x => chosen.has(x.name));
            const tot = sel.reduce((s, x) => s + x.cny, 0);
            sumEl.textContent = sel.length ? `已选 ${sel.length} 笔，合计 ${money(tot)}；对方转 ${money(toCNY(payment, st.currency))}，约占 ${(toCNY(payment, st.currency) / tot * 100).toFixed(0)}%` : "还没选";
        };
        q.addEventListener("input", draw);
        draw(); sum();
        return [{ label: "确定", primary: true, run: async () => {
            const sel = pool.filter(x => chosen.has(x.name)).sort((a, b) => a.ts - b.ts);
            if (!sel.length) { toast("请至少选一笔"); return false; }
            st.type = "退款"; st.aa = true; st.review = false;
            st.refund_of = sel.map(x => `[[${x.name}]]`);
            st.category = sel[0].category; st.sub = sel[0].sub;
            redraw();
        } }];
    });
}
function confirmInline(body) {
    if (body.dataset.confirmDelete) return true;
    body.dataset.confirmDelete = "1";
    toast("再点一次「删除」确认");
    setTimeout(() => delete body.dataset.confirmDelete, 4000);
    return false;
}

// ───────────────────────── shell ─────────────────────────
const root = dv.container.createDiv({ cls: "mny" + (ACCOUNT_MODE ? " mny-accmode" : "") });
const TABS = [["ledger", "账本", "📒"], ["stats", "统计", "📊"], ["calendar", "日历", "📅"], ["assets", "资产", "💳"], ["budget", "预算", "🎯"], ["biz", "生意", "💼"], ["settings", "设置", "⚙️"]];
function renderAll() {
    reload();
    root.empty ? root.empty() : (root.innerHTML = "");
    if (ACCOUNT_MODE) { renderAccountPage(root, input.account); return; }
    const head = h("div", { cls: "mny-top" }, [
        h("div", { cls: "mny-brand" }, [h("div", { cls: "mny-title", text: "记账" }), h("div", { cls: "mny-subtitle", text: `${TX.length} 笔 · 1 USD = ${rate()} CNY` })]),
        h("button", { cls: "mny-btn add", text: "＋ 记一笔", onclick: () => openEditor(null) }),
    ]);
    root.append(head);
    root.append(h("div", { cls: "mny-tabs", role: "tablist" }, TABS.map(([k, l, ic]) => h("button", { cls: "mny-tab" + (W.tab === k ? " on" : ""), role: "tab", onclick: () => { W.tab = k; renderAll(); } }, [h("span", { cls: "ti", text: ic }), h("span", { text: l })]))));
    const main = h("div", { cls: "mny-main" });
    root.append(main);
    ({ ledger: renderLedger, stats: renderStats, calendar: renderCalendar, assets: renderAssets, budget: renderBudget, biz: renderBiz, settings: renderSettings }[W.tab] || renderLedger)(main);
    root.append(h("button", { cls: "mny-fab", text: "＋", title: "记一笔", "aria-label": "记一笔", onclick: () => openEditor(null) }));
}
renderAll();
if (!ACCOUNT_MODE) {
    if (S.auto_rate !== false && S.rate_updated !== moment().format("YYYY-MM-DD") && W.rateTried !== moment().format("YYYY-MM-DD")) { W.rateTried = moment().format("YYYY-MM-DD"); refreshRate(false); }
    runRecurring();
}
