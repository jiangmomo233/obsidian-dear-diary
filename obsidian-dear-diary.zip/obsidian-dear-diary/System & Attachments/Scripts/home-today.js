// Home: "Today" button card (opens today's daily page, creating it if needed) + 7-day habit rings.
const DAILY = "01 Daily", JOURNAL = "90 Journaling";
const TEMPLATE = "System & Attachments/Templates/Dear Diary.md";
const COLORS = { language: "#F0B87E", study: "#F0B87E", diet: "#7A9F8E", sleep: "#E8A0A0", default: "#607D8B" };
const todayM = moment(), todayStr = todayM.format("YYYY-MM-DD");
const todayPath = `${DAILY}/${todayStr}.md`;

const section = (text, head) => {
    const out = []; let on = false;
    for (const l of text.split("\n")) {
        if (l.includes(head)) { on = true; continue; }
        if (on) { if (/^#{1,6}\s/.test(l.trim())) break; if (l.trim() && l.trim() !== "---") out.push(l.trim()); }
    }
    return out.slice(0, 4).join("\n");
};
let preview = "";
const jf = app.vault.getAbstractFileByPath(`${JOURNAL}/${todayStr}.md`);
if (jf) preview = section(await app.vault.cachedRead(jf), "One Moment Today");
const df = app.vault.getAbstractFileByPath(todayPath);
const dp = dv.page(todayPath);
const bits = [];
if (dp) {
    const moods = { great: "😄", good: "🙂", okay: "😐", low: "😔", rough: "😣" };
    if (dp.mood) bits.push(moods[dp.mood] || dp.mood);
    if (dp.sleep_hours) bits.push(`😴 ${dp.sleep_hours}h`);
    const open = dp.file.tasks.where(t => !t.completed && !(t.tags || []).some(x => x.startsWith("#habit"))).length;
    if (open) bits.push(`${open} open task${open > 1 ? "s" : ""}`);
}

// 7-day habit summary (only habits currently in the template)
const TPL_KEYS = new Set();
try { for (const m of (await app.vault.adapter.read("System & Attachments/Templates/Dear Diary.md")).matchAll(/#habit\/([^\s\/#]+)/g)) TPL_KEYS.add(m[1]); } catch (e) {}
const start = todayM.clone().subtract(6, "days");
const rec = {}; const keys = new Set();
for (const p of dv.pages(`"${DAILY}"`)) {
    const m = moment(p.file.name, "YYYY-MM-DD", true);
    if (!m.isValid() || m.isBefore(start, "day") || m.isAfter(todayM, "day")) continue;
    for (const t of p.file.tasks) for (const tag of (t.tags || [])) {
        const mm = tag.match(/^#habit\/([^\/\s#]+)/); if (!mm) continue;
        const k = mm[1].replace(/-\d+$/, ""); if (!TPL_KEYS.has(k)) continue; keys.add(k);
        if (t.completed) { rec[k] = rec[k] || new Set(); rec[k].add(p.file.name); }
    }
}
if (typeof Chart === "undefined") {
    try { const code = await app.vault.adapter.read("System & Attachments/Scripts/chart.umd.js"); new Function("module", "exports", "define", code)(); } catch (e) {}
}

const root = dv.container.createDiv({ cls: "ht" });
root.createEl("style", { text: `
.ht{display:flex;gap:8px;margin:6px 10px;font-family:'Figtree',BlinkMacSystemFont,sans-serif;}
.ht-today{flex:1;background:#FFFFFF;border-radius:10px;padding:10px 14px;cursor:pointer;border:none;text-align:left;transition:transform .08s, box-shadow .15s;}
.ht-today:hover{box-shadow:0 2px 10px #D9A3AD33;transform:translateY(-1px);}
.ht-row{display:flex;align-items:baseline;gap:10px;}
.ht-t{font-weight:600;color:#D9A3AD;font-size:0.95em;}
.ht-d{font-size:0.75em;color:#999;}
.ht-go{margin-left:auto;font-size:0.8em;color:#B0707D;background:#FFF9FA;border:1px solid #F3DDE1;border-radius:12px;padding:2px 10px;white-space:nowrap;}
.ht-p{font-size:0.82em;line-height:1.45;color:var(--text-normal);margin-top:4px;white-space:pre-line;max-height:70px;overflow:hidden;}
.ht-e{font-size:0.82em;color:#999;font-style:italic;margin-top:4px;}
.ht-bits{font-size:0.78em;color:#6B6478;margin-top:4px;}
.ht-habits{flex:0 0 auto;padding:4px 8px;min-width:110px;}
.ht-hi{display:flex;align-items:center;gap:5px;margin:4px 0;}
.ht-hl{font-size:0.75em;color:#D9A3AD;font-weight:500;text-transform:capitalize;}
` });
const card = root.createDiv({ cls: "ht-today" });
card.setAttr("role", "button"); card.setAttr("tabindex", "0");
const r = card.createDiv({ cls: "ht-row" });
r.createSpan({ cls: "ht-t", text: "Today" });
r.createSpan({ cls: "ht-d", text: todayM.format("dddd, MMM D") });
r.createSpan({ cls: "ht-go", text: df ? "Open today →" : "+ Start today" });
if (preview) card.createDiv({ cls: "ht-p", text: preview });
else card.createDiv({ cls: "ht-e", text: df ? "No journal entry yet." : "(How was today?)" });
if (bits.length) card.createDiv({ cls: "ht-bits", text: bits.join("  ·  ") });
const open = async () => {
    let f = app.vault.getAbstractFileByPath(todayPath);
    if (!f) { const t = app.vault.getAbstractFileByPath(TEMPLATE); f = await app.vault.create(todayPath, t ? await app.vault.read(t) : ""); }
    app.workspace.getLeaf(false).openFile(f);
};
card.onclick = open;
card.onkeydown = e => { if (e.key === "Enter") open(); };

const hb = root.createDiv({ cls: "ht-habits" });
hb.createDiv({ cls: "ht-t", text: "Habits" });
const todayDone = [...keys].filter(k => rec[k] && rec[k].has(todayM.format("YYYY-MM-DD"))).length;
let weekDone = 0; for (const k of keys) weekDone += rec[k] ? rec[k].size : 0;
const rings = [];
for (const [lab, val, color] of [[`Today ${todayDone}/${keys.size}`, keys.size ? todayDone / keys.size : 0, "#D9A3AD"], [`7 days ${Math.round(keys.size ? weekDone / (keys.size * 7) * 100 : 0)}%`, keys.size ? weekDone / (keys.size * 7) : 0, "#829EBE"]]) {
    const it = hb.createDiv({ cls: "ht-hi" });
    const cv = it.createEl("canvas", { attr: { width: 48, height: 48 } }); cv.style.width = cv.style.height = "24px";
    it.createSpan({ cls: "ht-hl", text: lab });
    rings.push([cv, Math.round(val * 100), color]);
}
if (!keys.size) hb.createDiv({ cls: "ht-e", text: "No habits yet" });
setTimeout(() => {
    if (typeof Chart === "undefined") return;
    for (const [cv, rate, color] of rings) new Chart(cv.getContext("2d"), { type: "doughnut", data: { datasets: [{ data: [rate, 100 - rate], backgroundColor: [color, "#E0E0E0"], borderWidth: 0 }] }, options: { responsive: false, cutout: "65%", plugins: { legend: { display: false }, tooltip: { enabled: false } } } });
}, 100);
