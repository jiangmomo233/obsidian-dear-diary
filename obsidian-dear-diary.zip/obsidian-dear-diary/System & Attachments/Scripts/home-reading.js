// Reading sources panel — reads links from "80 Library/Reading Sources/Magazines & Articles.md"
const SRC = "80 Library/Reading Sources/Magazines & Articles.md";
const G = "Garamond,'EB Garamond','Cormorant Garamond','Songti SC',serif";
const B = "Baskerville,'Libre Baskerville','Songti SC',serif";
const host = dv.container;
host.addClass("home-bottom");
const box = host.createDiv({ cls: "rs" });
box.createEl("style", { text: `
.home-bottom{display:grid;grid-template-columns:minmax(0,1fr) minmax(220px,280px);gap:32px;align-items:start;}
.home-bottom>.hb{order:0;min-width:0;} .home-bottom>.rs{order:1;}
.rs{background:#FFF9FA;border:1px solid #F7E6E9;border-radius:14px;padding:18px 22px 20px;margin:8px 10px 16px 0;}
.rs-h{font-family:${G};font-style:italic;font-size:1.7em;color:#D9A3AD;line-height:1.1;cursor:pointer;}
.rs-c{font-family:${G};font-variant:small-caps;letter-spacing:2.5px;font-size:.95em;color:#D9A3AD;margin:14px 0 4px;}
.rs-l{display:flex;flex-direction:column;gap:4px;}
.rs a.rs-a{font-family:${B};font-size:.95em;color:#7a5c62 !important;text-decoration:none !important;transition:color .15s;}
.rs a.rs-a:hover{color:#D9A3AD !important;}
.rs a.rs-a{display:inline-flex;align-items:center;align-self:flex-start;}
.rs-hrt{width:.62em;height:.62em;margin:.08em 0 0 .28em;flex:none;fill:transparent;stroke:#D9A3AD;stroke-width:1.8;stroke-linejoin:round;transition:fill .15s,stroke .15s;}
.rs a.rs-a:hover .rs-hrt{fill:#D9A3AD;stroke:#D9A3AD;}
@media (max-width:900px){.home-bottom{grid-template-columns:1fr;} .rs{margin-right:10px;}}
` });
const h = box.createDiv({ cls: "rs-h", text: "Reading", attr: { title: "Open source list" } });
h.onclick = () => app.workspace.openLinkText(SRC, "", false);
const f = app.vault.getAbstractFileByPath(SRC);
if (!f) box.createDiv({ cls: "rs-c", text: "source note not found" });
else {
    const text = await app.vault.cachedRead(f);
    let list = null;
    for (const line of text.split("\n")) {
        const l = line.trim(); if (!l) continue;
        const links = [...l.matchAll(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g)];
        if (links.length) {
            if (!list) list = box.createDiv({ cls: "rs-l" });
            for (const [, name, url] of links) { const a = list.createEl("a", { cls: "rs-a", text: name, attr: { href: url, target: "_blank", rel: "noopener" } }); a.insertAdjacentHTML("beforeend", '<svg class="rs-hrt" viewBox="0 0 24 22" aria-hidden="true"><path d="M12 20.5S2 14.2 2 7.4A5 5 0 0 1 12 5a5 5 0 0 1 10 2.4C22 14.2 12 20.5 12 20.5z"/></svg>'); }
        } else {
            const name = l.replace(/[=*#:：_]/g, "").trim();
            if (!name) continue;
            box.createDiv({ cls: "rs-c", text: name });
            list = box.createDiv({ cls: "rs-l" });
        }
    }
}
