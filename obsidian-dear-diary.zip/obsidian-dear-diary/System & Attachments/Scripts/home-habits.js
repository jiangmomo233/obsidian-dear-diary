// Monthly habit tracker. Habits come from the #habit/<key> tasks in the Dear Diary template;
// tick them in each daily note. ‹ › switch months.
const DAILY = "01 Daily";
const TEMPLATE = "System & Attachments/Templates/Dear Diary.md";
// one-line description under each title, and weekly/monthly targets (default: daily)
const INFO = {
  news:       ["One world source + one local source"],
  calendar:   ["Know what today and tomorrow look like"],
  email:      ["Late morning & late afternoon · clear to zero or flag"],
  language:   ["Vocab/grammar + listening (podcast, show, news)"],
  read:       ["Alternate a work book and a fun book"],
  write:      ["Journal or what I learned today"],
  exercise:   ["Strength, running or swimming · walk on other days", "week", 4],
  move:       ["Easy to sit all day otherwise"],
  walk:       ["A break from screens and thinking"],
  sleep:      ["Consistent bedtime and wake time"],
  longread:   ["Something deeper than headlines", "week", 1],
  grow:       ["A talk, podcast, course module or book", "week", 1],
  notes:      ["20 min · revisit the week's notes, link ideas", "week", 1],
  reflect:    ["What I learned, what next, which habits are sticking", "month", 1],
  new:        ["A skill, a tool or a topic", "month", 1],
};
const PALETTE = ["#D9A3AD", "#829EBE", "#D7B26A", "#7FB3A8", "#C9A0C8", "#9B8EC4", "#8FB58A", "#C98B6B", "#DB8797", "#7A9F8E"];
const EMPTY = "#EEF0F1";
const todayStr = moment().format("YYYY-MM-DD");

const labels = {}; const order = [];
try {
  const t = await app.vault.adapter.read(TEMPLATE);
  for (const line of t.split("\n")) {
    const m = line.match(/#habit\/([^\s\/#]+)/); if (!m) continue;
    const k = m[1];
    if (!labels[k]) { labels[k] = line.replace(/^[>\s]*[-*+]\s*\[.\]\s*/, "").replace(/#\S+/g, "").trim(); order.push(k); }
  }
} catch (e) {}

const done = {};
for (const p of dv.pages(`"${DAILY}"`)) {
  const m = moment(p.file.name, "YYYY-MM-DD", true); if (!m.isValid()) continue;
  for (const t of p.file.tasks) if (t.completed) for (const tag of (t.tags || [])) {
    const mm = tag.match(/^#habit\/([^\/\s#]+)/); if (!mm || !labels[mm[1]]) continue;
    (done[mm[1]] = done[mm[1]] || new Set()).add(m.format("YYYY-MM-DD"));
  }
}

const cur = window._hhMonth ? moment(window._hhMonth, "YYYY-MM") : moment().startOf("month");
const root = dv.container.createDiv({ cls: "hm" });
root.createEl("style", { text: `
.hm{font-family:'Figtree',BlinkMacSystemFont,sans-serif;padding:8px 16px;}
.hm-top{display:flex;align-items:center;gap:6px;margin-bottom:10px;}
.hm-title{font-size:1.35em;font-weight:600;letter-spacing:-.2px;color:#D9A3AD;min-width:9em;text-align:center;}
.hm button{box-shadow:none !important;cursor:pointer;background:transparent !important;border:1px solid #D9A3AD55 !important;color:#D9A3AD !important;border-radius:10px !important;padding:0 9px !important;height:24px !important;font-size:14px;}
.hm button.hm-now{font-size:11px;}
.hm-scroll{overflow-x:auto;}
.hm table{border-collapse:separate;border-spacing:2px;width:100%;table-layout:fixed;}
.hm th,.hm td{padding:0;border:none !important;background:none !important;}
.hm col.hm-lab{width:17em;} .hm col.hm-st{width:3em;}
.hm th{font-size:9px;color:#BBB;font-weight:400;text-align:center;white-space:nowrap;overflow:visible;letter-spacing:-.3px;}
.hm th.wk{color:#D9A3AD;}
.hm-sec td{font-size:10.5px;color:#D9A3AD;letter-spacing:1.5px;text-transform:uppercase;padding-top:10px !important;}
.hm-lt{vertical-align:top;padding:7px 14px 7px 0 !important;}
.hm-n{font-size:0.85em;font-weight:600;color:#4A5A62;line-height:1.3;white-space:normal;word-break:normal;}
.hm-ds{font-size:10.5px;color:#9AA3A8;line-height:1.35;margin-top:2px;white-space:normal;}
.hm td.hm-cell{vertical-align:middle;}
.hm-c{height:14px;border-radius:3px;}
.hm-c.fut{opacity:.35;} .hm-c.today{outline:1.5px solid #D9A3AD;outline-offset:1px;}
.hm td.hm-s{font-family:'Cormorant Garamond','EB Garamond',Garamond,serif;font-style:italic;font-size:13px;color:#B8A5AA;text-align:right;white-space:nowrap;vertical-align:middle;padding-left:8px !important;font-variant-numeric:oldstyle-nums;}
.hm td.hm-s.ok{color:#7A9F8E;}
.hm-empty{font-size:0.85em;color:#999;font-style:italic;}
` });
const rerender = m => { window._hhMonth = m; root.remove(); dv.view("System & Attachments/Scripts/home-habits"); };
const top = root.createDiv({ cls: "hm-top" });
top.createEl("button", { text: "‹" }).onclick = () => rerender(cur.clone().subtract(1, "month").format("YYYY-MM"));
top.createSpan({ cls: "hm-title", text: cur.format("MMMM YYYY") });
top.createEl("button", { text: "›" }).onclick = () => rerender(cur.clone().add(1, "month").format("YYYY-MM"));
if (!cur.isSame(moment(), "month")) top.createEl("button", { cls: "hm-now", text: "Today" }).onclick = () => rerender(null);
if (!order.length) { root.createDiv({ cls: "hm-empty", text: "Add tasks like “- [ ] 📖 Read #habit/read” to the Dear Diary template." }); return; }

const n = cur.daysInMonth();
const days = [...Array(n)].map((_, i) => cur.clone().date(i + 1));
const elapsed = cur.isSame(moment(), "month") ? moment().date() : (cur.isBefore(moment(), "month") ? n : 0);
const sc = root.createDiv({ cls: "hm-scroll" });
const tb = sc.createEl("table");
const cg = tb.createEl("colgroup"); cg.createEl("col", { cls: "hm-lab" }); days.forEach(() => cg.createEl("col")); cg.createEl("col", { cls: "hm-st" });
const hr = tb.createEl("tr"); hr.createEl("th");
for (const d of days) hr.createEl("th", { cls: d.day() === 1 ? "wk" : "", text: String(d.date()), attr: { title: d.format("ddd D MMM") } });
hr.createEl("th");

let section = null;
const isDaily = k => !INFO[k] || !INFO[k][1] || INFO[k][1] === "day";
const sorted = [...order.filter(isDaily), ...order.filter(k => !isDaily(k))];
sorted.forEach((k, idx) => {
  const [desc = "", per = "day", target = 1] = INFO[k] || [];
  const sec = per === "day" ? "Daily" : "Weekly & monthly";
  if (sec !== section) { section = sec; const r = tb.createEl("tr", { cls: "hm-sec" }); r.createEl("td", { text: sec, attr: { colspan: n + 2 } }); }
  const set = done[k] || new Set();
  const color = PALETTE[order.indexOf(k) % PALETTE.length];
  const r = tb.createEl("tr");
  const lab = r.createEl("td", { cls: "hm-lt" });
  lab.createDiv({ cls: "hm-n", text: labels[k] });
  if (desc) lab.createDiv({ cls: "hm-ds", text: desc, attr: { title: desc } });
  let cnt = 0;
  for (const d of days) {
    const ds = d.format("YYYY-MM-DD"); const hit = set.has(ds); if (hit) cnt++;
    const c = r.createEl("td", { cls: "hm-cell" }).createDiv({ cls: "hm-c" + (ds > todayStr ? " fut" : "") + (ds === todayStr ? " today" : "") });
    c.style.background = hit ? color : EMPTY; c.title = `${d.format("ddd D MMM")} · ${hit ? "✓" : "–"}`;
  }
  let goal = per === "day" ? elapsed : per === "week" ? Math.ceil(elapsed / 7) * target : (elapsed ? target : 0);
  const st = r.createEl("td", { cls: "hm-s" + (goal && cnt >= goal ? " ok" : "") });
  st.setText(per === "day" ? `${cnt}/${elapsed}` : per === "week" ? `${cnt}/${goal}` : `${cnt}/${target}`);
  st.title = per === "day" ? "days done / days so far" : per === "week" ? `done / target (${target}× a week)` : "done / target this month";
});
